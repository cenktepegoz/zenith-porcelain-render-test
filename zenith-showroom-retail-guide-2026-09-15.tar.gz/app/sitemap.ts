import type { MetadataRoute } from "next";
import { solutions } from "./site-data";
import { legalDocuments } from "./legal-data";
import { knowledgeArticles } from "./bilgi-merkezi/article-data";
import { recoveredGuides } from "./en/guides/guide-data";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://zenithporcelain.com";
  const lastModified = new Date("2026-09-15");
  const pages = ["", "/cozumler", "/projeler", "/koleksiyonlar", "/collections/endustriyel-beton", "/collections/statuario-mermer", "/collections/antrasit-tas", "/profesyoneller", "/uretim-teknolojileri", "/yesil-enerji-ve-su-donusumu", "/bilgi-merkezi", "/hakkimizda", "/iletisim"];
  const projectPages = ["/projeler/otel-cafe-restoran-porselen-projesi"];
  const all = [...pages, ...solutions.map((solution) => `/cozumler/${solution.slug}`)];
  const locales = ["en", "es", "de", "ar", "it"];
  const languages = (path: string) => ({
    "x-default": `${base}${path}`,
    "tr-TR": `${base}${path}`,
    ...Object.fromEntries(locales.map((locale) => [locale, `${base}/${locale}${path}`])),
  });
  return [
    ...recoveredGuides.map(({ slug }) => ({ url: `${base}/en/guides/${slug}`, lastModified: new Date("2026-09-09"), changeFrequency: "monthly" as const, priority: .8 })),
    ...all.map((path, index) => ({ url: `${base}${path}`, lastModified, changeFrequency: index === 0 ? "weekly" as const : "monthly" as const, priority: index === 0 ? 1 : .8, alternates: { languages: languages(path) } })),
    ...locales.flatMap((locale) => all.map((path) => ({ url: `${base}/${locale}${path}`, lastModified, changeFrequency: "monthly" as const, priority: .7, alternates: { languages: languages(path) } }))),
    ...projectPages.map((path) => ({ url: `${base}${path}`, lastModified, changeFrequency: "monthly" as const, priority: .8 })),
    ...knowledgeArticles.map(({ slug, updated }) => ({ url: `${base}/bilgi-merkezi/${slug}`, lastModified: new Date(updated), changeFrequency: "monthly" as const, priority: .8 })),
    ...legalDocuments.map(({ slug }) => ({ url: `${base}/hukuki/${slug}`, lastModified, changeFrequency: "yearly" as const, priority: .3 })),
  ];
}
