import type { Metadata } from "next";
import { notFound } from "next/navigation";
import SubpageShell from "../../components/subpage-shell";
import ResilientImage from "../../components/resilient-image";
import { breadcrumbSchema } from "../../seo";
import { knowledgeArticleBySlug, knowledgeArticles } from "../article-data";

const scoreLabels: Record<number, string> = {
  1: "Sınırlı",
  2: "İyi",
  3: "Mükemmel",
};

export function generateStaticParams() {
  return knowledgeArticles.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = knowledgeArticleBySlug(slug);
  if (!article) return {};
  return {
    title: article.seoTitle || article.title,
    description: article.description,
    keywords: article.keywords,
    alternates: { canonical: `/bilgi-merkezi/${slug}` },
    openGraph: {
      type: "article",
      title: article.title,
      description: article.description,
      publishedTime: article.published,
      modifiedTime: article.updated,
      images: [{ url: article.image || "/images/zenith-hero-kitchen-1800.jpg", alt: article.imageAlt || article.title }],
    },
    twitter: { card: "summary_large_image", title: article.title, description: article.description, images: [article.image || "/images/zenith-hero-kitchen-1800.jpg"] },
  };
}

export default async function KnowledgeArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = knowledgeArticleBySlug(slug);
  if (!article) notFound();

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: article.title,
    description: article.description,
    datePublished: article.published,
    dateModified: article.updated,
    inLanguage: "tr-TR",
    mainEntityOfPage: `https://zenithporcelain.com/bilgi-merkezi/${article.slug}`,
    image: article.image ? [
      article.image,
      ...(article.gallery?.map((item) => item.src) || []),
      ...article.sections.flatMap((section) => section.image ? [section.image.src] : []),
    ].map((src) => `https://zenithporcelain.com${src}`) : undefined,
    citation: article.references?.map((reference) => reference.url),
    author: { "@id": "https://zenithporcelain.com/#organization" },
    publisher: { "@id": "https://zenithporcelain.com/#organization" },
  };
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: article.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  };
  const breadcrumb = breadcrumbSchema([
    { name: "Ana Sayfa", path: "/" },
    { name: "Bilgi Merkezi", path: "/bilgi-merkezi" },
    { name: article.title, path: `/bilgi-merkezi/${article.slug}` },
  ]);
  const publishedDate = new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${article.published}T00:00:00Z`));

  return (
    <SubpageShell>
      <article className="knowledge-article">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify([articleSchema, faqSchema, breadcrumb]) }} />
        <header className="sub-hero section-shell">
          <p className="eyebrow">{article.eyebrow}</p>
          <h1>{article.title}</h1>
          <p>{article.intro}</p>
          <small>Yayın: {publishedDate} · Teknik editör: Zenith Porcelain</small>
        </header>
        {article.image && <figure className={`knowledge-visual section-shell${article.surfaceComparison ? " knowledge-visual-document" : ""}`}><ResilientImage src={article.image} alt={article.imageAlt || article.title} loading={article.surfaceComparison ? "lazy" : "eager"} fetchPriority={article.surfaceComparison ? "auto" : "high"} /><figcaption>{article.imageCaption || article.imageAlt}</figcaption></figure>}
        {article.gallery && <section className="knowledge-gallery section-shell" aria-label={`${article.title} görselleri`}>{article.gallery.map((item) => <figure key={item.src}><ResilientImage src={item.src} alt={item.alt} loading="lazy" /><figcaption>{item.caption}</figcaption></figure>)}</section>}
        {article.surfaceComparison && <section className="surface-comparison section-shell" aria-labelledby="surface-comparison-heading">
          <div className="surface-comparison-heading">
            <div><p className="eyebrow">Karar tablosu</p><h2 id="surface-comparison-heading">14 ölçütte 7 tezgâh yüzeyi.</h2></div>
            <p>Puanları tek başına bir sonuç olarak değil, kullanım senaryonuz için hangi teknik föyleri ve detayları incelemeniz gerektiğini gösteren başlangıç noktası olarak değerlendirin.</p>
          </div>
          <div className="surface-comparison-scroll" tabIndex={0} role="region" aria-label="Tezgâh malzemeleri karşılaştırma tablosu, yatay kaydırılabilir">
            <table className="surface-score-table">
              <caption>Porselen, kuvars, laminat, solid surface, doğal taş ve çelik tezgâhların genel performans karşılaştırması</caption>
              <thead><tr><th scope="col">Özellik</th>{article.surfaceComparison.columns.map((column, index) => <th scope="col" className={index < 2 ? "is-porcelain" : undefined} key={column}>{column}</th>)}</tr></thead>
              <tbody>
                {article.surfaceComparison.rows.map((row) => <tr key={row.criterion}>
                  <th scope="row">{row.criterion}</th>
                  {row.scores.map((score, index) => <td className={index < 2 ? "is-porcelain" : undefined} key={`${row.criterion}-${article.surfaceComparison?.columns[index]}`}>
                    <span className="surface-score" aria-label={scoreLabels[score]} title={scoreLabels[score]}>
                      {[1, 2, 3].map((dot) => <i className={dot <= score ? "is-active" : undefined} aria-hidden="true" key={dot} />)}
                      <span className="surface-score-text">{scoreLabels[score]}</span>
                    </span>
                  </td>)}
                </tr>)}
              </tbody>
            </table>
          </div>
          <div className="surface-score-legend" aria-label="Puan açıklaması">
            {[3, 2, 1].map((score) => <span key={score}><span className="surface-score" aria-hidden="true">{[1, 2, 3].map((dot) => <i className={dot <= score ? "is-active" : undefined} key={dot} />)}</span>{scoreLabels[score]}</span>)}
          </div>
          <p className="surface-comparison-note">{article.surfaceComparison.note}</p>
        </section>}
        <div className="knowledge-body section-shell">
          {article.sections.map((section) => (
            <section key={section.heading}>
              <h2>{section.heading}</h2>
              {section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              {section.bullets && <ul>{section.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>}
              {section.image && <figure className="knowledge-section-visual"><ResilientImage src={section.image.src} alt={section.image.alt} loading="lazy" /><figcaption>{section.image.caption}</figcaption></figure>}
            </section>
          ))}
        </div>
        {article.comparison && <section className="knowledge-comparison section-shell" aria-labelledby="comparison-heading">
          <div className="section-heading"><div><p className="eyebrow">Hızlı karşılaştırma</p><h2 id="comparison-heading">Cam destek ve ahşap altlık.</h2></div><p>Sonuç; seçilen ürün, ölçü, üretim toleransı ve bağlantı tasarımına bağlıdır.</p></div>
          <div className="comparison-table" role="table" aria-label="Cam destekli ve ahşap altlıklı porselen masa karşılaştırması">
            <div className="comparison-row comparison-head" role="row"><strong role="columnheader">Karar noktası</strong><strong role="columnheader">Cam destekli porselen</strong><strong role="columnheader">Ahşap altlıklı porselen</strong></div>
            {article.comparison.map((row) => <div className="comparison-row" role="row" key={row.criterion}><strong role="cell">{row.criterion}</strong><span role="cell">{row.glass}</span><span role="cell">{row.wood}</span></div>)}
          </div>
        </section>}
        {(article.relatedLinks || article.references) && <section className="knowledge-resources section-shell">
          {article.relatedLinks && <div><p className="eyebrow">İlgili içerikler</p><h2>Kararı tamamlayan sayfalar.</h2><ul>{article.relatedLinks.map((link) => <li key={link.url}><a href={link.url}>{link.label} ↗</a></li>)}</ul></div>}
          {article.references && <div><p className="eyebrow">Teknik kaynaklar</p><h2>İfadelerin dayanağı.</h2><p>Kaynaklar genel mühendislik ilkelerini açıklar; nihai ürün performansı proje özelinde numune ve testle doğrulanmalıdır.</p><ul>{article.references.map((reference) => <li key={reference.url}><a href={reference.url} target="_blank" rel="noreferrer">{reference.label} ↗</a></li>)}</ul></div>}
        </section>}
        <section className="faq section-shell">
          <div><p className="eyebrow">Sık sorulanlar</p><h2>Karar vermeden önce.</h2></div>
          <div>{article.faqs.map((faq) => <details key={faq.question}><summary>{faq.question}<span>+</span></summary><p>{faq.answer}</p></details>)}</div>
        </section>
        <section className="sub-cta"><div><p className="eyebrow light">Projenize özel değerlendirme</p><h2>Çiziminizi, ölçünüzü veya fikrinizi teknik ekiple paylaşın.</h2></div><a className="button button-light" href="/#quote">Projenizi Gönderin</a></section>
      </article>
    </SubpageShell>
  );
}
