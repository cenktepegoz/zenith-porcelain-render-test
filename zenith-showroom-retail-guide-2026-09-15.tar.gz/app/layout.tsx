import type { Metadata } from "next";
import { headers } from "next/headers";
import AnalyticsConsent from "./components/analytics-consent";
import { MessageCircle } from "lucide-react";
import ConversionTracking from "./components/conversion-tracking";
import MobileDock from "./components/mobile-dock";
import "./globals.css";
import "./zenith-premium.css";
import "./mobile-app.css";
import "./knowledge-editorial.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://zenithporcelain.com"),
  title: { default: "Zenith Porcelain | Porselen Yüzey Mühendisliği", template: "%s | Zenith Porcelain" },
  description: "Porselen mutfak ve banyo tezgâhı, masa, lavabo, mimari yüzey, CNC, su jeti ve cam-porselen laminasyonu. Dijital ölçümden montaja tek teknik ekip.",
  keywords: ["porselen tezgah", "porselen masa", "porselen lavabo", "porselen kesim", "cam porselen laminasyon", "Eskişehir"],
  authors: [{ name: "Zenith Porcelain", url: "https://zenithporcelain.com" }],
  creator: "Zenith Porcelain",
  publisher: "Zenith Porcelain",
  category: "Porselen yüzey işleme ve mimari üretim",
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 } },
  openGraph: { title: "Zenith Porcelain | Porselen Yüzey Mühendisliği", description: "Dijital ölçümden CNC ve su jeti kesime, özel üretimden montaja: porselen yüzeyleri gerçek mekânlar için çalışan ürünlere dönüştürüyoruz.", type: "website", locale: "tr_TR", siteName: "Zenith Porcelain", images: [{url:"/images/zenith-hero-kitchen-1800.jpg",width:1200,height:630,alt:"Zenith Porcelain porselen mutfak adası uygulaması"}] },
  twitter: { card: "summary_large_image", title: "Zenith Porcelain | Porselen Yüzey Mühendisliği", description: "Porselen tezgâh, lavabo, masa ve mimari yüzeylerde ölçümden montaja entegre üretim.", images: ["/images/zenith-hero-kitchen-1800.jpg"] },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://zenithporcelain.com/#organization",
      name: "Zenith Porcelain",
      legalName: "ZENITH PORCELAIN MOBİLYA SANAYİ TİCARET ANONİM ŞİRKETİ",
      taxID: "0997189034500001",
      foundingDate: "2023-12-19",
      url: "https://zenithporcelain.com",
      logo: "https://zenithporcelain.com/images/zenith-porcelain-logo-clean.png",
      telephone: "+90 222 255 54 00",
      email: "info@zenithporcelain.com",
      sameAs: [
        "https://www.instagram.com/zenith_porcelain/",
        "https://www.linkedin.com/company/zenith-porcelain",
      ],
      contactPoint: [{ "@type": "ContactPoint", telephone: "+90 850 242 59 00", contactType: "customer service", availableLanguage: ["tr", "en"] }],
      location: [
        { "@id": "https://zenithporcelain.com/#istanbul-office" },
        { "@id": "https://zenithporcelain.com/#eskisehir-factory" },
        { "@id": "https://zenithporcelain.com/#ankara-showroom" },
        { "@id": "https://zenithporcelain.com/#eskisehir-showroom" },
      ],
    },
    {
      "@type": "LocalBusiness",
      "@id": "https://zenithporcelain.com/#istanbul-office",
      name: "Zenith Porcelain İstanbul Merkez Ofis",
      parentOrganization: { "@id": "https://zenithporcelain.com/#organization" },
      url: "https://zenithporcelain.com/iletisim",
      telephone: "+90 222 255 54 00",
      address: { "@type": "PostalAddress", streetAddress: "Esentepe Mah. Büyükdere Cad. Levent 199 No: 199 İç Kapı No: 6", addressLocality: "Şişli", addressRegion: "İstanbul", addressCountry: "TR" },
    },
    {
      "@type": "LocalBusiness",
      "@id": "https://zenithporcelain.com/#eskisehir-factory",
      name: "Zenith Porcelain Eskişehir Fabrika",
      parentOrganization: { "@id": "https://zenithporcelain.com/#organization" },
      url: "https://zenithporcelain.com/iletisim",
      telephone: "+90 222 255 54 00",
      address: { "@type": "PostalAddress", streetAddress: "75. Yıl OSB, Osmangazi Caddesi No: 48", addressLocality: "Odunpazarı", addressRegion: "Eskişehir", addressCountry: "TR" },
    },
    {
      "@type": "LocalBusiness",
      "@id": "https://zenithporcelain.com/#ankara-showroom",
      name: "Zenith Porcelain Ankara Showroom",
      parentOrganization: { "@id": "https://zenithporcelain.com/#organization" },
      url: "https://zenithporcelain.com/iletisim",
      telephone: "+90 222 255 54 00",
      address: { "@type": "PostalAddress", streetAddress: "Siteler, Koçak Sk. No: 4", postalCode: "06160", addressLocality: "Altındağ", addressRegion: "Ankara", addressCountry: "TR" },
    },
    {
      "@type": "LocalBusiness",
      "@id": "https://zenithporcelain.com/#eskisehir-showroom",
      name: "Zenith Porcelain Eskişehir Showroom",
      parentOrganization: { "@id": "https://zenithporcelain.com/#organization" },
      url: "https://zenithporcelain.com/iletisim",
      telephone: "+90 222 255 54 00",
      address: { "@type": "PostalAddress", streetAddress: "Bülent Ecevit Blv. No: 16, Batıkent", postalCode: "26180", addressLocality: "Tepebaşı", addressRegion: "Eskişehir", addressCountry: "TR" },
    },
  ],
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const pathname = (await headers()).get("x-zenith-pathname") || "/";
  const locale = pathname.split("/").filter(Boolean)[0];
  const language = ["en", "es", "de", "ar", "it"].includes(locale) ? locale : "tr";
  const direction = language === "ar" ? "rtl" : "ltr";
  const whatsappLabel = language === "ar" ? "تواصل مع Zenith Porcelain عبر واتساب" : "Zenith Porcelain ile WhatsApp'tan görüşün";
  return (
    <html lang={language} dir={direction}>
      <body className="antialiased">
        <AnalyticsConsent />
        <ConversionTracking />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
        {children}
        <MobileDock />
        <a
          className="zp-whatsapp-float"
          href="https://wa.me/908502425900?text=Merhaba%20Zenith%20Porcelain%2C%20projem%20hakk%C4%B1nda%20bilgi%20almak%20istiyorum."
          target="_blank"
          rel="noreferrer"
          aria-label={whatsappLabel}
        >
          <span className="zp-whatsapp-status" aria-hidden="true" />
          <MessageCircle size={20} strokeWidth={1.7} aria-hidden="true" />
          <span className="zp-whatsapp-label"><strong>WhatsApp</strong><small>Projenizi konuşalım</small></span>
        </a>
      </body>
    </html>
  );
}
