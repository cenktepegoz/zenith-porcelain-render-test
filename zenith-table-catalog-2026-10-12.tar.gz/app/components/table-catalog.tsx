import './table-catalog.css';

export default function TableCatalog({ locale = 'tr' }: { locale?: 'tr' | 'en' }) {
  const en = locale === 'en';
  const image = '/images/zenith-porselen-masa-katalog-render.jpg';
  const caption = en
    ? 'Catalogue visualisation, not a completed-project photograph. Dimensions, surface and base options are confirmed when ordering.'
    : 'Katalog görselleştirmesi; tamamlanmış proje fotoğrafı değildir. Ölçü, yüzey ve ayak seçenekleri sipariş sırasında netleştirilir.';
  const alt = en
    ? 'Catalogue rendering of an elongated porcelain dining table with rounded corners and warm-toned veining'
    : 'Yuvarlatılmış köşeleri ve sıcak tonlu damarlarıyla uzun porselen yemek masasının katalog renderı';
  return <section className="table-catalog" aria-labelledby={`table-catalog-${locale}`}>
    <figure>
      <img src={image} alt={alt} width={810} height={1080} loading="lazy" decoding="async" />
      <figcaption>{caption}</figcaption>
    </figure>
    <div className="table-catalog-copy">
      <p className="table-catalog-eyebrow">{en ? 'Catalogue concept · Available for production review' : 'Katalog tasarımı · Üretim için değerlendirin'}</p>
      <h2 id={`table-catalog-${locale}`}>{en ? 'A surface that defines the dining space.' : 'Mekânın odağında, malzemenin karakteri.'}</h2>
      <p>{en ? 'Warm-toned veining and rounded corners give this elongated tabletop a distinctive visual character. Zenith can produce the table design shown; the finished specification is agreed for your order.' : 'Sıcak tonlu damarlar ve yuvarlatılmış köşeler, uzun masa tablasına güçlü bir görsel karakter kazandırıyor. Görseldeki masa tasarımı Zenith tarafından üretilebilir; bitmiş ürünün detayları siparişinize göre birlikte netleştirilir.'}</p>
      <p>{en ? 'Use this visual as the starting point for a complete table or a tabletop-only enquiry. Share the required dimensions, quantity, base preference and delivery destination. The rendering does not specify a slab brand, model, thickness or extendable mechanism.' : 'Bu görseli tamamlanmış masa veya yalnızca tabla talebinizin başlangıç noktası olarak kullanabilirsiniz. İstenen ölçüyü, adedi, ayak tercihini ve teslimat yerini paylaşın. Görsel; plaka markası, model, kalınlık veya açılır mekanizma özelliği tanımlamaz.'}</p>
      <p>{en ? 'Pattern placement and colour appearance should be reviewed against the selected material sample or slab before production.' : 'Desen yerleşimi ve renk görünümü, üretim öncesinde seçilen malzemenin numunesi veya plakası üzerinden değerlendirilmelidir.'}</p>
      <a className="table-catalog-cta" href={en ? '/en/export-oem#export-inquiry' : '/#quote'}>{en ? 'Discuss this table design →' : 'Bu tasarım için teklif isteyin →'}</a>
    </div>
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify({
      '@context': 'https://schema.org', '@type': 'ImageObject',
      contentUrl: `https://zenithporcelain.com${image}`, name: alt, caption,
      description: caption, width: 810, height: 1080, inLanguage: en ? 'en' : 'tr',
    }).replace(/</g, '\\u003c')}} />
  </section>;
}
