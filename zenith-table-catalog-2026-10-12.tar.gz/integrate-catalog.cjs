const fs=require('node:fs'),path=require('node:path');
const root=process.argv[2]||process.cwd();
function edit(file,steps){const p=path.join(root,file);let s=fs.readFileSync(p,'utf8');for(const [a,b] of steps){if(s.includes(b))continue;if(!s.includes(a))throw Error('Expected source missing: '+file);s=s.replace(a,b);}fs.writeFileSync(p,s);}
edit('app/cozumler/[slug]/page.tsx',[
 ['import type { Metadata } from "next";', 'import type { Metadata } from "next";\nimport TableCatalog from "../../components/table-catalog";'],
 ['    <section className="detail-section section-shell">','    {slug === "porselen-masa-ve-sehpalar" && <TableCatalog />}\n    <section className="detail-section section-shell">'],
]);
edit('app/components/english-export-site.tsx',[
 ["import type { ReactNode } from 'react';", "import type { ReactNode } from 'react';\nimport TableCatalog from './table-catalog';"],
 ['    <section className="export-section"><div className="export-copy-grid">','    {pageKey === "cozumler/porselen-masa-ve-sehpalar" && <TableCatalog locale="en" />}\n    <section className="export-section"><div className="export-copy-grid">'],
]);
console.log('Catalog render integrated with explicit TR/EN provenance captions.');
