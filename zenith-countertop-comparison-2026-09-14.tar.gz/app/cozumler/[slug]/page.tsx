import type { Metadata } from "next";
import { notFound } from "next/navigation";
import SubpageShell from "../../components/subpage-shell";
import ResilientImage from "../../components/resilient-image";
import { solutions } from "../../site-data";
import { solutionMedia } from "../../project-media";
import { localizedAlternates, breadcrumbSchema } from "../../seo";

export function generateStaticParams() {
  return solutions.map((solution) => ({ slug: solution.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const solution = solutions.find((item) => item.slug === slug);
  if (!solution) return {};
  const title = solution.seo?.title ?? solution.title;
  const description = solution.seo?.description ?? solution.intro.slice(0, 158);
  return {
    title,
    description,
    keywords: solution.seo?.keywords,
    alternates: localizedAlternates(`/cozumler/${solution.slug}`),
    openGraph: {
      title,
      description,
      type: "website",
      url: `/cozumler/${solution.slug}`,
      images: [{ url: solution.image, alt: solution.imageAlt ?? `${solution.title} uygulaması` }],
    },
    twitter: { card: "summary_large_image", title, description, images: [solution.image] },
  };
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const solution = solutions.find((item) => item.slug === slug);
  if (!solution) notFound();
  const media = solutionMedia[slug] || [];
  const decisions = solution.decisions ?? [
    { number: "01", title: "Ölçü ve altyapı", text: "Net ölçüler, taşıyıcı veya mobilya durumu, duvar gönye ve kotları birlikte kontrol edilir." },
    { number: "02", title: "Yüzey ve desen", text: "Plaka ebadı, damar yönü, birleşim ve kitap eşleme ihtiyacı üretim çizimine aktarılır." },
    { number: "03", title: "Donanım ve kesiler", text: "Evye, armatür, ocak, priz, gider, mekanizma ve bağlantı detayları üretimden önce sabitlenir." },
    { number: "04", title: "Sevkiyat ve montaj", text: "Parça ölçüsü; giriş, asansör, kat, taşıma ve montaj sırasına göre planlanır." },
  ];
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: solution.title,
    description: solution.seo?.description ?? solution.intro,
    url: `https://zenithporcelain.com/cozumler/${solution.slug}`,
    image: `https://zenithporcelain.com${solution.image}`,
    provider: { "@id": "https://zenithporcelain.com/#organization" },
    audience: solution.slug === "3-mm-porselen-mobilya-kaplama" ? [
      { "@type": "Audience", audienceType: "Mobilya üreticileri" },
      { "@type": "Audience", audienceType: "Mimarlar ve tasarımcılar" },
      { "@type": "Audience", audienceType: "Proje firmaları" },
    ] : undefined,
    areaServed: ["Türkiye", "Europe", "Middle East"],
    serviceType: solution.eyebrow,
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: `${solution.title} uygulama alanları`,
      itemListElement: solution.applications.map((name) => ({ "@type": "Offer", itemOffered: { "@type": "Service", name } })),
    },
  };
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: solution.faqs.map((item) => ({ "@type": "Question", name: item.q, acceptedAnswer: { "@type": "Answer", text: item.a } })),
  };
  const breadcrumb = breadcrumbSchema([
    { name: "Ana Sayfa", path: "/" },
    { name: "Çözümler", path: "/cozumler" },
    { name: solution.title, path: `/cozumler/${solution.slug}` },
  ]);
  const videoSchema = solution.video ? {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name: solution.video.title,
    description: solution.video.description,
    thumbnailUrl: `https://zenithporcelain.com${solution.video.poster}`,
    contentUrl: `https://zenithporcelain.com${solution.video.src}`,
    embedUrl: `https://zenithporcelain.com/cozumler/${solution.slug}#uygulama-videosu`,
    uploadDate: "2026-08-31",
    duration: "PT1M32S",
    inLanguage: "tr-TR",
    publisher: { "@id": "https://zenithporcelain.com/#organization" },
  } : null;

  return <SubpageShell><article>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify([schema, faqSchema, breadcrumb, videoSchema].filter(Boolean)) }} />
    <section className="detail-hero">
      <ResilientImage src={solution.image} alt={solution.imageAlt ?? `${solution.title} uygulaması`} loading="eager" fetchPriority="high" />
      <div className="detail-overlay" />
      <div><p className="eyebrow light">{solution.eyebrow}</p><h1>{solution.title}</h1><p>{solution.intro}</p><a className="button button-light" href="/#quote">Projenizi teknik ekiple değerlendirin</a></div>
    </section>
    <section className="detail-section section-shell">
      <div className="section-heading"><div><p className="eyebrow">Neden bu çözüm?</p><h2>Güzel görünen değil,<br />doğru çalışan detaylar.</h2></div><p>Malzemeyi tek başına değil; kullanım alışkanlığı, taşıyıcı sistem, donanım, üretim ve montaj koşullarıyla birlikte değerlendiriyoruz.</p></div>
      <div className="benefit-grid">{solution.benefits.map((benefit, index) => <div key={benefit.title}><span>0{index + 1}</span><h2>{benefit.title}</h2><p>{benefit.text}</p></div>)}</div>
    </section>
    {solution.video && <section className="solution-video section-shell" id="uygulama-videosu" aria-labelledby="solution-video-title">
      <div className="section-heading"><div><p className="eyebrow">Uygulama videosu</p><h2 id="solution-video-title">{solution.video.title}</h2></div><p>{solution.video.description}</p></div>
      <figure>
        <video controls playsInline preload="metadata" poster={solution.video.poster} aria-label={solution.video.title}>
          <source src={solution.video.src} type="video/mp4" />
          <track kind="captions" srcLang="tr" label="Türkçe" src={solution.video.captions} default />
          Tarayıcınız videoyu oynatamıyor. <a href={solution.video.src}>Videoyu indirin.</a>
        </video>
        <figcaption>Marmox taşıyıcı altyapının porselen lavabo ve tezgâh sistemine katkıları: sürekli destek, yük dağılımı, rijitlik, hafiflik ve ıslak hacim uyumu.</figcaption>
      </figure>
      <p className="solution-video-note"><strong>Teknik not:</strong> Marmox porseleni kırılmaz hâle getirmez. Doğru projelendirilmiş sürekli destek; boşluk ve esnemeyi azaltarak sistemin darbe ve kullanım yükleri karşısındaki dayanımını artırmaya yardımcı olur.</p>
    </section>}
    {slug === "cam-porselen-laminasyonu" && <section className="related-guide section-shell"><a href="/bilgi-merkezi/cam-laminasyonlu-porselen-ve-ahsap-altlik-farklari"><div><p className="eyebrow">Yeni teknik rehber</p><h2>Cam laminasyonlu porselen ile ahşap altlık arasındaki farkları inceleyin.</h2></div><span>Rehberi okuyun ↗</span></a></section>}
    {slug === "mutfak-tezgahlari" && <section className="related-guide section-shell"><a href="/bilgi-merkezi/porselen-tezgah-mi-kuvars-mi"><div><p className="eyebrow">Malzeme seçim rehberi</p><h2>Porselen, kuvars, doğal taş ve diğer tezgâh yüzeylerini 14 ölçütte karşılaştırın.</h2></div><span>Karşılaştırmayı açın ↗</span></a></section>}
    <section className="application-band"><div className="section-shell two-col"><div><p className="eyebrow light">Uygulama alanları</p><h2>Tek çözüm,<br />farklı kullanım senaryoları.</h2></div><ul>{solution.applications.map((item) => <li key={item}>{item}</li>)}</ul></div></section>
    {solution.sections && solution.sections.length > 0 && <section className="solution-story section-shell" aria-label={`${solution.title} hakkında teknik bilgiler`}>
      <div className="solution-story-intro"><p className="eyebrow">Teknik rehber</p><h2>Malzeme, tasarım ve üretim aynı kararda buluşur.</h2></div>
      <div className="solution-story-list">{solution.sections.map((section, index) => <article key={section.title}>
        <header><span>{String(index + 1).padStart(2, "0")}</span>{section.eyebrow && <p className="eyebrow">{section.eyebrow}</p>}<h2>{section.title}</h2></header>
        <div className="solution-story-copy">{section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}{section.items && <ul>{section.items.map((item) => <li key={item}>{item}</li>)}</ul>}</div>
      </article>)}</div>
    </section>}
    {media.length > 0 && <section className="detail-section section-shell"><div className="section-heading"><div><p className="eyebrow">Uygulama galerisi</p><h2>Malzemenin mekândaki karşılığı.</h2></div><p>Farklı kullanım senaryoları; desen, birleşim ve uygulama kararlarının mekândaki etkisini gösterir.</p></div><div className={`project-grid solution-gallery ${solution.slug === "3-mm-porselen-mobilya-kaplama" ? "solution-gallery--furniture" : ""}`}>{media.map((item) => <figure key={item.src}><ResilientImage src={item.src} alt={`${item.title} — ${item.use}`} loading="lazy" /><figcaption><strong>{item.title}</strong><span>{item.description}</span></figcaption></figure>)}</div></section>}
    <section className="detail-section section-shell"><div className="section-heading"><div><p className="eyebrow">Teknik karar noktaları</p><h2>Tekliften önce netleşmesi gerekenler.</h2></div></div><div className="decision-grid">{decisions.map((decision) => <article key={decision.number}><span>{decision.number}</span><h3>{decision.title}</h3><p>{decision.text}</p></article>)}</div></section>
    <section className="detail-section section-shell"><div className="section-heading"><div><p className="eyebrow">Üretim yolu</p><h2>Projeniz kontrollü adımlarla ilerler.</h2></div></div><ol className="detail-process">{solution.process.map((item, index) => <li key={item}><span>{String(index + 1).padStart(2, "0")}</span><p>{item}</p></li>)}</ol></section>
    {solution.relatedLinks && solution.relatedLinks.length > 0 && <section className="related-solutions section-shell">
      <div><p className="eyebrow">İlgili çözümler</p><h2>Üretim detayını tamamlayan hizmetler.</h2></div>
      <div className="related-solution-grid">{solution.relatedLinks.map((link) => <a href={link.href} key={link.href}><h3>{link.title}</h3><p>{link.description}</p><span>İnceleyin ↗</span></a>)}</div>
    </section>}
    <section className="faq section-shell"><div><p className="eyebrow">Sık sorulanlar</p><h2>Karar vermeden önce.</h2></div><div>{solution.faqs.map((item) => <details key={item.q}><summary>{item.q}<span>+</span></summary><p>{item.a}</p></details>)}</div></section>
    <section className="sub-cta solution-final-cta"><div><p className="eyebrow light">{solution.slug === "3-mm-porselen-mobilya-kaplama" ? "Mobilya projeniz için" : "Projeniz için ilk adım"}</p><h2>{solution.slug === "3-mm-porselen-mobilya-kaplama" ? "3 mm porselen ve cam laminasyon seçeneğini birlikte değerlendirelim." : `${solution.title} için teknik ihtiyaçları birlikte netleştirelim.`}</h2></div><a className="button button-light" href="/#quote">Projenizi Gönderin</a></section>
  </article></SubpageShell>;
}
