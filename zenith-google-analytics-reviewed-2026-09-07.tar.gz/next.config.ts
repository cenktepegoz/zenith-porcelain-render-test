import type { NextConfig } from "next";

const scriptPolicy = process.env.NODE_ENV === "development"
  ? "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com"
  : "script-src 'self' 'unsafe-inline' https://www.googletagmanager.com";

const nextConfig: NextConfig = {
  // Standalone çıktı yalnızca cPanel / Phusion Passenger paketi hazırlanırken
  // gerekir. Render normal Next.js sunucusunu çalıştırır.
  ...(process.env.CPANEL_BUILD === "1" ? { output: "standalone" as const } : {}),
  experimental: { webpackBuildWorker: false },
  allowedDevOrigins: ["127.0.0.1", "localhost"],
  // Kaynak paket daha önce tip denetiminden geçti. GoDaddy'nin sınırlı
  // derleme süresinde aynı denetimi yeniden çalıştırmayarak zaman aşımını önler.
  typescript: { ignoreBuildErrors: true },
  distDir: process.env.CPANEL_BUILD === "1" ? ".cpanel-next" : ".next",
  poweredByHeader: false,
  // Proxy, eski URL'leri ve sondaki eğik çizgileri tek adımda kanonik
  // hedefe yönlendirir. Next.js'in otomatik yönlendirmesi kapatılmazsa
  // /contact/ -> /contact -> /iletisim şeklinde iki sıçrama oluşur.
  skipTrailingSlashRedirect: true,
  // Proxy'nin gelen URL'yi eğik çizgileriyle birlikte görmesini sağlar;
  // böylece /hakkimizda/ gibi varyantlar kendi üzerine yönlenmez.
  skipMiddlewareUrlNormalize: true,
  async redirects() {
    return [
      // Arama motorlarında kalan eski www WordPress adreslerini doğrudan
      // nihai kanonik hedefe gönder. Böylece www -> kök alan adı -> yeni
      // sayfa biçimindeki iki adımlı yönlendirme zinciri oluşmaz.
      { source: "/about", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/hakkimizda", permanent: true },
      { source: "/contact", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/iletisim", permanent: true },
      { source: "/services", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/cozumler", permanent: true },
      { source: "/category/:path*", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/bilgi-merkezi", permanent: true },
      { source: "/tag/:path*", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/bilgi-merkezi", permanent: true },
      { source: "/author/:path*", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/bilgi-merkezi", permanent: true },
      { source: "/portfolio/:path*", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/koleksiyonlar", permanent: true },
      { source: "/portfolio-category/:path*", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/projeler", permanent: true },
      { source: "/cam-laminasyonlu-porselen-masa-nedir-teknolojinin-estetikle-bulusmasi", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/bilgi-merkezi/3-mm-porselenden-mobilyaya", permanent: true },
      { source: "/porselen-banyo-ve-mutfak-tezgahi-kullanmanin-10-avantaji-nedir", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/cozumler/mutfak-tezgahlari", permanent: true },
      { source: "/porselen-yemek-masasi-alirken-dikkat-edilmesi-gereken-7-onemli-kriter", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/cozumler/porselen-masa-ve-sehpalar", permanent: true },
      { source: "/porselen-masa-nedir-ahsap-ve-mermer-masalara-gore-avantajlari-nelerdir", has: [{ type: "host", value: "www.zenithporcelain.com" }], destination: "https://zenithporcelain.com/cozumler/porselen-masa-ve-sehpalar", permanent: true },
      {
        source: "/:path*",
        has: [{ type: "host", value: "www.zenithporcelain.com" }],
        destination: "https://zenithporcelain.com/:path*",
        permanent: true,
      },
      { source: "/about", destination: "/hakkimizda", permanent: true },
      { source: "/services", destination: "/cozumler", permanent: true },
      { source: "/contact", destination: "/iletisim", permanent: true },
      { source: "/index.html", destination: "/", permanent: true },
      { source: "/category/:path*", destination: "/bilgi-merkezi", permanent: true },
      { source: "/tag/:path*", destination: "/bilgi-merkezi", permanent: true },
      { source: "/author/:path*", destination: "/bilgi-merkezi", permanent: true },
      { source: "/portfolio/:path*", destination: "/koleksiyonlar", permanent: true },
      { source: "/portfolio-category/:path*", destination: "/projeler", permanent: true },
      { source: "/project/:path*", destination: "/projeler", permanent: true },
      { source: "/blog", destination: "/bilgi-merkezi", permanent: true },
      { source: "/blog/:path*", destination: "/bilgi-merkezi", permanent: true },
      { source: "/zenith_app/:path*", destination: "/#quote", permanent: true },
      {
        source: "/porselen-banyo-ve-mutfak-tezgahi-kullanmanin-10-avantaji-nedir",
        destination: "/cozumler/mutfak-tezgahlari",
        permanent: true,
      },
      {
        source: "/porselen-yemek-masasi-alirken-dikkat-edilmesi-gereken-7-onemli-kriter",
        destination: "/cozumler/porselen-masa-ve-sehpalar",
        permanent: true,
      },
      {
        source: "/cam-laminasyonlu-porselen-masa-nedir-teknolojinin-estetikle-bulusmasi",
        destination: "/bilgi-merkezi/3-mm-porselenden-mobilyaya",
        permanent: true,
      },
      {
        source: "/porselen-masa-nedir-ahsap-ve-mermer-masalara-gore-avantajlari-nelerdir",
        destination: "/cozumler/porselen-masa-ve-sehpalar",
        permanent: true,
      },
      {
        source: "/porselen-mutfak-tezgahi-modelleri-ile-mutfaklarda-yeni-nesil-mimari",
        destination: "/cozumler/mutfak-tezgahlari",
        permanent: true,
      },
      {
        source: "/porselen-masa-modelleri-ile-yasam-alanlarinda-estetik-ve-fonksiyonellik",
        destination: "/cozumler/porselen-masa-ve-sehpalar",
        permanent: true,
      },
      {
        source: "/cam-laminasyonlu-porselen-masa-modelleri",
        destination: "/cozumler/porselen-masa-ve-sehpalar",
        permanent: true,
      },
    ];
  },
  async headers() {
    const securityHeaders = [
      { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains; preload" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "X-Frame-Options", value: "SAMEORIGIN" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
      {
        key: "Content-Security-Policy",
        value: `default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self' https://wa.me; img-src 'self' data: blob: https:; font-src 'self' data:; style-src 'self' 'unsafe-inline'; ${scriptPolicy}; connect-src 'self' https://*.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com; upgrade-insecure-requests`,
      },
    ];
    return [
      { source: "/:path*", headers: securityHeaders },
      {
        source: "/images/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=86400, stale-while-revalidate=604800" }],
      },
      { source: "/api/health", headers: [{ key: "Cache-Control", value: "no-store" }] },
    ];
  },
};

export default nextConfig;
