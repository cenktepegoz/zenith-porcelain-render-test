export const MEASUREMENT_ID = "G-2GRQYNBCQQ";
export const CONSENT_KEY = "zenith-analytics-consent-v1";
const MAX_AGE = 180 * 24 * 60 * 60 * 1000;
type Choice = "accepted" | "rejected";
declare global {
  interface Window {
    dataLayer: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}
let choice: Choice | null = null;
let initialized = false;
let lastPage = "";

export function readConsent(): Choice | null {
  try {
    const saved = JSON.parse(localStorage.getItem(CONSENT_KEY) || "null");
    choice = saved && Date.now() - saved.time < MAX_AGE && ["accepted", "rejected"].includes(saved.choice) ? saved.choice : null;
  } catch { choice = null; }
  return choice;
}

export function saveConsent(value: Choice) {
  choice = value;
  try { localStorage.setItem(CONSENT_KEY, JSON.stringify({ choice: value, time: Date.now() })); } catch { /* Session-only preference when storage is unavailable. */ }
  if (value === "rejected") {
    (window as unknown as Record<string, unknown>)[`ga-disable-${MEASUREMENT_ID}`] = true;
    for (const cookie of document.cookie.split(";")) {
      const name = cookie.trim().split("=")[0];
      if (!/^_ga(?:_|$)/.test(name)) continue;
      for (const domain of ["", location.hostname, "." + location.hostname]) {
        document.cookie = `${name}=; Max-Age=0; Path=/;${domain ? ` Domain=${domain};` : ""} SameSite=Lax; Secure`;
      }
    }
    if (initialized) location.reload();
  }
}

export function enableAnalytics() {
  if (choice !== "accepted" || initialized) return;
  initialized = true;
  (window as unknown as Record<string, unknown>)[`ga-disable-${MEASUREMENT_ID}`] = false;
  window.dataLayer = window.dataLayer || [];
  window.gtag = function () { window.dataLayer.push(arguments); };
  window.gtag("consent", "default", { analytics_storage: "granted", ad_storage: "denied", ad_user_data: "denied", ad_personalization: "denied" });
  window.gtag("js", new Date());
  window.gtag("config", MEASUREMENT_ID, {
    send_page_view: false,
    allow_google_signals: false,
    allow_ad_personalization_signals: false,
    cookie_expires: 15552000,
    cookie_update: false,
    page_location: location.origin + location.pathname,
    page_referrer: safeReferrer(),
    ...campaignParameters(),
  });
  const script = document.createElement("script");
  script.id = "zenith-ga4";
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${MEASUREMENT_ID}`;
  document.head.appendChild(script);
}

function safeReferrer() {
  try { const url = new URL(document.referrer); return url.origin + url.pathname; } catch { return ""; }
}

function campaignParameters(): Record<string, string> {
  const search = new URLSearchParams(location.search);
  const result: Record<string, string> = {};
  for (const [query, parameter] of [["utm_source", "campaign_source"], ["utm_medium", "campaign_medium"], ["utm_campaign", "campaign_name"], ["utm_id", "campaign_id"], ["utm_content", "campaign_content"]]) {
    const value = search.get(query);
    if (value && /^[a-zA-Z][a-zA-Z0-9_-]{0,79}$/.test(value)) result[parameter] = value;
  }
  return result;
}

export function trackPage(pathname: string) {
  if (choice !== "accepted" || !initialized || lastPage === pathname) return;
  const previous = lastPage;
  lastPage = pathname;
  window.gtag?.("set", { page_location: location.origin + pathname, page_referrer: previous ? location.origin + previous : safeReferrer() });
  trackEvent("page_view", { page_title: document.title });
}

export function trackEvent(name: string, parameters: Record<string, string> = {}, callback?: () => void) {
  if (choice !== "accepted" || !window.gtag) { callback?.(); return; }
  try {
    window.gtag("event", name, {
      ...parameters,
      send_to: MEASUREMENT_ID,
      page_location: location.origin + location.pathname,
      page_path: location.pathname,
      ...(callback ? { event_callback: callback, event_timeout: 700 } : {}),
    });
  } catch { callback?.(); }
}
