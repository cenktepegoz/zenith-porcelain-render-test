"use client";

import { FormEvent, useRef, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { trackEvent as track } from "../lib/analytics";

const WHATSAPP_NUMBER = "908502425900";

export default function ContactForm() {
  const [feedback, setFeedback] = useState("");
  const started = useRef(false);
  const submitting = useRef(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    const element = event.currentTarget;
    const form = new FormData(element);
    const name = String(form.get("name") || "").trim();
    const company = String(form.get("company") || "").trim();
    const phone = String(form.get("phone") || "").trim();
    const projectType = String(form.get("projectType") || "").trim();
    const location = String(form.get("location") || "").trim();
    const details = String(form.get("details") || "").trim();
    const privacyNotice = form.get("privacyNotice") === "accepted";
    if (!name || !projectType) {
      setFeedback("Lütfen adınızı ve proje tipini girin."); return;
    }
    if (!privacyNotice) {
      setFeedback("Lütfen KVKK Aydınlatma Metni’ni okuduğunuzu onaylayın."); return;
    }
    const message = [
      "Merhaba Zenith Porcelain, projem için teknik değerlendirme rica ediyorum.",
      "",
      `Ad-Soyad: ${name}`,
      `Firma: ${company || "Belirtilmedi"}`,
      `Telefon: ${phone || "WhatsApp üzerinden iletişim"}`,
      `Proje tipi: ${projectType}`,
      `Proje konumu: ${location || "Belirtilmedi"}`,
      `Proje notu: ${details || "Belirtilmedi"}`,
      "",
      "Çizim ve görsellerimi bu WhatsApp görüşmesine ekleyeceğim.",
    ].join("\n");
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    setFeedback("WhatsApp görüşmesi açılıyor… Çizim ve dosyalarınızı görüşme ekranından ekleyebilirsiniz.");
    submitting.current = true;
    // A validated WhatsApp handoff is an intent, not a confirmed lead or sale.
    let navigated = false;
    const navigate = () => {
      if (navigated) return;
      navigated = true;
      submitting.current = false;
      window.location.assign(whatsappUrl);
    };
    const timeout = window.setTimeout(navigate, 800);
    track("project_form_submit", { channel: "whatsapp" }, () => {
      window.clearTimeout(timeout);
      navigate();
    });
  }

  return <section className="zp-contact" id="quote">
    <div className="zp-contact-copy" id="contact">
      <p className="zp-kicker">Projenizi gönderin</p><h2>Teknik değerlendirmeyi<br /><em>birlikte başlatalım.</em></h2>
      <p>İhtiyacınızı kısaca anlatın; form, proje özetinizi hazır bir WhatsApp mesajına dönüştürsün. Çizim ve teknik dosyalarınızı açılan görüşmeye doğrudan ekleyin.</p>
      <div className="zp-contact-direct"><span>Doğrudan iletişim</span><a href="tel:+902222555400">+90 222 255 54 00</a><a href="https://wa.me/908502425900?text=Merhaba%20Zenith%20Porcelain%2C%20projem%20hakk%C4%B1nda%20bilgi%20almak%20istiyorum.">WhatsApp: +90 850 242 59 00</a></div>
    </div>
    <form className="zp-contact-form" onSubmit={handleSubmit} onFocus={() => { if (!started.current) { started.current = true; track("project_form_start"); } }} noValidate>
      <div className="zp-form-row"><label>Ad-Soyad<input required name="name" autoComplete="name" placeholder="Adınız ve soyadınız" /></label><label>Kurum / Firma — isteğe bağlı<input name="company" autoComplete="organization" placeholder="Firma adı" /></label></div>
      <div className="zp-form-row"><label>Telefon — isteğe bağlı<input type="tel" name="phone" autoComplete="tel" placeholder="+90" /></label><label>İletişim kanalı<input value="WhatsApp" readOnly aria-label="İletişim kanalı" /></label></div>
      <div className="zp-form-row"><label>Proje Tipi<select required name="projectType" defaultValue=""><option value="" disabled>Seçiniz</option><option>Mutfak tezgâhı</option><option>Banyo ve lavabo</option><option>Masa ve mobilya</option><option>Duvar ve zemin kaplama</option><option>Fason CNC / su jeti</option><option>HORECA / ticari proje</option><option>OEM / ihracat</option><option>Diğer</option></select></label><label>Proje konumu — isteğe bağlı<input name="location" autoComplete="address-level2" placeholder="İl / ilçe veya ülke" /></label></div>
      <label>Proje Notu — isteğe bağlı<textarea name="details" rows={4} placeholder="Yaklaşık ölçü, yüzey tercihi, proje konumu veya teslim hedefi…" /></label>
      <p className="zp-file-label">PDF, DWG, DXF, JPG, PNG ve ZIP dosyalarınızı açılan WhatsApp görüşmesine ekleyebilirsiniz.</p>
      <label className="zp-consent"><input required type="checkbox" name="privacyNotice" value="accepted" /><span><a href="/hukuki/kvkk-aydinlatma-metni" target="_blank">KVKK Aydınlatma Metni</a>’ni okudum ve proje talebim kapsamında kişisel verilerimin işlenmesi hakkında bilgilendirildim.</span></label>
      <div className="zp-form-submit"><p role="status" aria-live="polite">{feedback || "Bilgileriniz e-postayla gönderilmez; yalnızca sizin başlatacağınız WhatsApp görüşmesine aktarılır."}</p><button type="submit">WhatsApp’ta Projeyi Başlatın <ArrowUpRight size={16} /></button></div>
    </form>
  </section>;
}
