"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { enableAnalytics, readConsent, saveConsent, trackPage } from "../lib/analytics";
import "./analytics-consent.css";

export default function AnalyticsConsent() {
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  const [accepted, setAccepted] = useState(false);
  useEffect(() => {
    const choice = readConsent();
    setAccepted(choice === "accepted");
    setOpen(choice === null);
    setReady(true);
  }, []);
  useEffect(() => {
    if (accepted) {
      enableAnalytics();
      trackPage(pathname);
    }
  }, [accepted, pathname]);
  function choose(value: "accepted" | "rejected") {
    saveConsent(value);
    setAccepted(value === "accepted");
    setOpen(false);
  }
  if (!ready) return null;
  return <>
    <button type="button" className="zp-cookie-settings" onClick={() => setOpen(true)} aria-expanded={open}>Çerez tercihleri</button>
    {open && <section className="zp-cookie-banner" role="region" aria-label="Analiz çerezleri tercihi">
      <p>İzninizle ziyaret ve etkileşim istatistiklerini Google Analytics ile ölçüyoruz. Formdaki ad, telefon ve proje notları Analytics’e gönderilmez. Tercihinizi daha sonra değiştirebilirsiniz. <a href="/hukuki/cerez-politikasi">Çerez politikası</a></p>
      <div><button type="button" onClick={() => choose("rejected")}>Reddet</button><button type="button" onClick={() => choose("accepted")}>Kabul et</button></div>
    </section>}
  </>;
}
