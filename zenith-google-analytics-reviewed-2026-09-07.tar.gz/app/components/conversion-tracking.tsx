"use client";

import { useEffect } from "react";
import { trackEvent } from "../lib/analytics";

export default function ConversionTracking() {
  useEffect(() => {
    const click = (event: MouseEvent) => {
      const anchor = event.target instanceof Element ? event.target.closest("a") : null;
      if (!anchor) return;
      const url = new URL(anchor.href, window.location.origin);
      let name = "";
      if (["wa.me", "api.whatsapp.com", "web.whatsapp.com"].includes(url.hostname)) name = "whatsapp_click";
      else if (url.protocol === "tel:") name = "phone_click";
      else if (url.protocol === "mailto:") name = "email_click";
      else if (url.origin === location.origin && ["#contact", "#quote"].includes(url.hash)) name = "project_cta_click";
      else if (["google.com", "www.google.com", "maps.google.com"].includes(url.hostname) && url.pathname.startsWith("/maps")) name = "location_map_click";
      if (name) trackEvent(name, { source: "site_link" });
    };
    document.addEventListener("click", click);
    return () => document.removeEventListener("click", click);
  }, []);
  return null;
}
