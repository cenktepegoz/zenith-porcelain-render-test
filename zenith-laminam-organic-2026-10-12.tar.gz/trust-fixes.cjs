// Guarded, idempotent source overlay. Usage: node trust-fixes.cjs /path/to/source
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(process.argv[2] || '.');
const pending = new Map();
function replace(file, before, after) {
  const source = pending.has(file) ? pending.get(file) : fs.readFileSync(path.join(root, file), 'utf8');
  const count = source.split(before).length - 1;
  if (count === 0 && source.includes(after)) { pending.set(file, source); return; }
  if (count !== 1) throw new Error(`${file}: expected one anchor, found ${count}: ${before.slice(0, 100)}`);
  pending.set(file, source.replace(before, after));
}
replace('app/profesyoneller/page.tsx',
 'Mimarlar, proje ekipleri ve üreticiler için porselen teknik detayları, üretilebilirlik desteği, numune, DWG, BIM ve PDF kaynakları.',
 'Mimarlar, proje ekipleri ve üreticiler için porselen malzeme seçimi, numune desteği, özel ölçü üretim ve projeye özel teknik değerlendirme.');
const collection = 'app/collections/[slug]/page.tsx';
replace(collection, 'image: "/images/legacy/eskisehir-factory.webp", tone: "#8e877c"', 'image: null, tone: "#8e877c"');
replace(collection, 'image: `https://zenithporcelain.com${item.image}`, description: item.philosophy,', '...(item.image ? { image: `https://zenithporcelain.com${item.image}` } : {}), description: item.philosophy,');
replace(collection,
 '<img src={item.image} alt={`${item.name} porselen yüzey uygulaması`} /><div className="zp-collection-hero-overlay" />',
 '{item.image && <img src={item.image} alt={`${item.name} porselen yüzey uygulaması`} />}<div className="zp-collection-hero-overlay" />');
replace(collection,
 '<span>Yüzeyi keşfedin <ArrowDown size={16} /></span>',
 '<span>{item.image ? <>Yüzeyi keşfedin <ArrowDown size={16} /></> : "Yüzey fotoğrafı güncelleniyor"}</span>');
replace(collection,
 '<section className="zp-collection-application"><img src={item.image} alt={`${item.name} yüzey detayı`} /><div>',
 '<section className="zp-collection-application">{item.image ? <img src={item.image} alt={`${item.name} yüzey detayı`} /> : <div style={{ backgroundColor: item.tone, color: "#fff", padding: "3rem", display: "flex", alignItems: "center" }}><p>Bu seriye ait doğrulanmış yüzey fotoğrafı güncelleniyor. Renk ve dokuyu değerlendirmek için fiziksel numune talep edebilirsiniz.</p></div>}<div>');
const sitemap = 'app/sitemap.ts';
replace(sitemap,
 'const projectPages = ["/projeler/otel-cafe-restoran-porselen-projesi"];',
 'const projectPages = ["/projeler/otel-cafe-restoran-porselen-projesi", "/projeler/laminam-porselen-uygulamalari"];\n  // Only substantively updated Turkish routes; do not date-bump translations.\n  const organicUpdatedPaths = new Set(["", "/bolge", "/projeler", "/profesyoneller", "/collections/endustriyel-beton", "/projeler/laminam-porselen-uygulamalari", "/cozumler/mutfak-tezgahlari", "/cozumler/porselen-lavabo-cozumleri", "/cozumler/porselen-masa-ve-sehpalar", "/cozumler/cam-porselen-laminasyonu"]);\n  const organicModified = new Date("2026-10-12");');
replace(sitemap,
 'lastModified: path === "/bilgi-merkezi" ? new Date("2026-10-06") : lastModified,',
 'lastModified: organicUpdatedPaths.has(path) ? organicModified : path === "/bilgi-merkezi" ? new Date("2026-10-06") : lastModified,');
replace(sitemap,
 '...projectPages.map((path) => ({ url: `${base}${path}`, lastModified,',
 '...projectPages.map((path) => ({ url: `${base}${path}`, lastModified: organicUpdatedPaths.has(path) ? organicModified : lastModified,');
replace(sitemap,
 'lastModified: new Date("2026-09-21"), changeFrequency: "monthly" as const, priority: .8 })),',
 'lastModified: organicUpdatedPaths.has(path) ? organicModified : new Date("2026-09-21"), changeFrequency: "monthly" as const, priority: .8 })),');
// All anchors above are validated before any write occurs.
for (const [file, content] of pending) {
  if (fs.readFileSync(path.join(root, file), 'utf8') !== content) fs.writeFileSync(path.join(root, file), content);
  console.log(`Verified trust overlay: ${file}`);
}
