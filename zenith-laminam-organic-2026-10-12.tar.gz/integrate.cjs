const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(process.argv[2]||'.');
const pending=new Map();
function replace(file,before,after){const source=pending.get(file)??fs.readFileSync(path.join(root,file),'utf8');if(source.includes(after))return; if(source.split(before).length!==2)throw Error('Anchor mismatch '+file);pending.set(file,source.replace(before,after));}
const href='/projeler/laminam-porselen-uygulamalari';
const card='<section className="related-guide section-shell"><a href="'+href+'"><div><p className="eyebrow">Laminam uygulama seçkisi</p><h2>Mutfak, lavabo ve mobilyada malzemeden detaya.</h2><p>Zenith Porcelain’in üretim ve uygulama çalışmalarını gerçek fotoğraflarla inceleyin.</p></div><span>Uygulamaları inceleyin ↗</span></a></section>';
replace('app/projeler/page.tsx','<section className="project-feature section-shell">',card+'<section className="project-feature section-shell">');
replace('app/profesyoneller/page.tsx','<InstallationServiceCard/>',card+'<InstallationServiceCard/>');
replace('app/cozumler/[slug]/page.tsx','<section className="application-band">','{["mutfak-tezgahlari","porselen-lavabo-cozumleri","3-mm-porselen-mobilya-kaplama","mimari-ve-ozel-projeler"].includes(slug) && '+card+'}<section className="application-band">');
replace('app/components/brand-pages.tsx','<Faq locale={locale} brand={brand} />','{!en && brand.id === "laminam" && <section className="brand-wrap brand-section"><h2>Laminam ile mimari uygulamalar</h2><p>Zenith Porcelain’in mutfak, lavabo ve mobilya yüzeyi çalışmalarını fotoğraf ve detaylarıyla inceleyin.</p><a href="'+href+'">Laminam uygulama seçkisini açın →</a></section>}<Faq locale={locale} brand={brand} />');
for(const[file,content]of pending)fs.writeFileSync(path.join(root,file),content);
console.log('Four internal-link locations updated.');
