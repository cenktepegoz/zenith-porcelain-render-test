import type { Metadata } from "next";
import Link from "next/link";
import SubpageShell from "../../components/subpage-shell";
import styles from "./showcase.module.css";

const origin = "https://zenithporcelain.com";
const route = "/projeler/laminam-porselen-uygulamalari";
const title = "Laminam Porselen Uygulamaları | Zenith Porcelain";
const description = "Zenith Porcelain’in Laminam porselen uygulamalarını inceleyin: mutfak tezgâhı, lavabo ve mobilya yüzeylerinde mimari bütünlük ve üretim detayları.";
const images = [
  { stem: "zenith-laminam-banyo-genel", width: 1600, height: 1200, alt: "Gri damarlı Laminam yüzeylerle lavabo, dolap önleri, duvar ve zeminin bir arada görüldüğü banyo", caption: "Banyoda porselen yüzeylerin bütüncül kullanımı." },
  { stem: "zenith-laminam-banyo-yuzey-detay", width: 1600, height: 1200, alt: "Ahşap yüzeyler ve cam duş bölümüyle birlikte görülen damarlı porselen banyo zemini ve lavabo detayı", caption: "Farklı malzemeler ve yüzeyler arasındaki ilişki." },
  { stem: "zenith-laminam-porselen-lavabo-geometri", width: 1200, height: 1600, alt: "Açık damarlı porselen lavabo haznesi, tezgâhı ve krom armatürlerin yakın görünümü", caption: "Lavabo haznesi, tezgâh ve düşey yüzey arasındaki geometrik ilişki." },
  { stem: "zenith-laminam-lavabo-yan-gorunum", width: 1200, height: 1600, alt: "Ahşap duvar önünde damarlı porselen lavabonun tezgâh ve ön yüz detayı", caption: "Ahşap ve porselenin bir arada kullanıldığı lavabo uygulaması." },
  { stem: "zenith-laminam-mutfak-tezgahi", width: 1280, height: 1920, alt: "Ocak çevresinde açık damarlı porselen mutfak tezgâhı ve tezgâh arası yüzey", caption: "Tezgâh ve tezgâh arası yüzeylerde ortak bir malzeme dili." },
  { stem: "zenith-laminam-evye-cevresi", width: 1280, height: 1920, alt: "Pencere önündeki evye çevresinde porselen tezgâh ve düşey kaplama yüzeyleri", caption: "Evye çevresinde yatay ve düşey porselen yüzey ilişkisi." },
  { stem: "zenith-laminam-ada-yuzeyi", width: 1280, height: 1920, alt: "Mavi cam aksesuarların bulunduğu açık damarlı porselen mutfak adası yüzeyi", caption: "Ada yüzeyinden yakın plan." },
  { stem: "zenith-laminam-ada-kenar-detayi", width: 1280, height: 1920, alt: "Porselen mutfak adasının koyu renk alt gövde üzerindeki kenar görünümü", caption: "Ada yüzeyinin kenar ve alt gövdeyle kurduğu ilişki." },
  { stem: "zenith-laminam-mobilya-on-yuz", width: 840, height: 630, alt: "Damarlı porselen mobilya ön yüzleri, tezgâh ve açık renk duvar yüzeyi bulunan mutfak", caption: "Farklı bir mutfak görünümünde porselenin mobilya ön yüzlerinde kullanımı." },
];
const src = (stem: string) => `/images/zenith-laminam/${stem}.jpg`;

export const metadata: Metadata = {
  title: { absolute: title }, description,
  alternates: { canonical: route },
  openGraph: { title, description, url: route, type: "website", locale: "tr_TR", images: [{ url: src(images[0].stem), width: 1600, height: 1200, alt: images[0].alt }] },
  twitter: { card: "summary_large_image", title, description, images: [src(images[0].stem)] },
};

function Photo({ index, hero = false }: { index: number; hero?: boolean }) {
  const image = images[index];
  return <figure className={styles.figure}>
    {/* Original project photographs, intentionally not generatively altered. */}
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src={src(image.stem)} alt={image.alt} width={image.width} height={image.height} loading={hero ? "eager" : "lazy"} fetchPriority={hero ? "high" : "auto"} decoding="async" />
    <figcaption>{image.caption}</figcaption>
  </figure>;
}

export default function LaminamProjectShowcase() {
  const schema = {
    "@context": "https://schema.org", "@graph": [
      { "@type": "CollectionPage", "@id": `${origin}${route}#webpage`, url: `${origin}${route}`, name: title, description, inLanguage: "tr-TR", publisher: { "@id": `${origin}/#organization` }, primaryImageOfPage: { "@id": `${origin}${route}#image-1` }, about: [{ "@type": "Thing", name: "Laminam porselen uygulamaları" }, { "@id": `${origin}/#organization` }], hasPart: images.map((_, index) => ({ "@id": `${origin}${route}#image-${index + 1}` })) },
      ...images.map((image, index) => ({ "@type": "ImageObject", "@id": `${origin}${route}#image-${index + 1}`, contentUrl: `${origin}${src(image.stem)}`, url: `${origin}${src(image.stem)}`, name: image.alt, caption: image.caption, width: image.width, height: image.height })),
      { "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Ana Sayfa", item: origin }, { "@type": "ListItem", position: 2, name: "Laminam Porselen Uygulamaları", item: `${origin}${route}` }] },
    ],
  };
  return <SubpageShell><article className={styles.showcase}>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema).replace(/</g, "\\u003c") }} />
    <header className={styles.header}>
      <nav className={styles.breadcrumb} aria-label="İçerik yolu"><Link href="/">Ana Sayfa</Link><span aria-hidden="true"> / </span><span>Uygulama seçkisi</span></nav>
      <p className={styles.eyebrow}>Zenith Porcelain · Uygulama seçkisi</p>
      <h1>Laminam porselen uygulamaları:<br />mekândan detaya.</h1>
      <p className={styles.lead}>Mimari fikri, üretilebilir detaylara dönüştüren porselen çözümleri.</p>
      <p>Mutfak, banyo ve mobilya yüzeylerinde malzemenin karakteri kadar, onu mekâna bağlayan detaylar da önemlidir. Bu seçki, Zenith Porcelain’in Laminam ile gerçekleştirdiği üretim ve uygulama çalışmalarını bir araya getiriyor.</p>
      <dl className={styles.facts}><div><dt>Malzeme markası</dt><dd>Laminam</dd></div><div><dt>Üretim ve uygulama</dt><dd>Zenith Porcelain</dd></div><div><dt>Odak</dt><dd>Mutfak · Banyo · Mobilya</dd></div></dl>
    </header>
    <div className={styles.hero}><Photo index={0} hero /></div>
    <div className={styles.content}>
      <p className={styles.note}>Farklı uygulamalardan derlenen bu seçki, tek bir projenin hikâyesi olarak sunulmamaktadır. Genel görünümler ve yakın planlar, porselenin farklı mimari elemanlardaki kullanımını birlikte gösterir.</p>
      <section className={styles.section} aria-labelledby="banyo-baslik"><div className={styles.sectionIntro}><p className={styles.eyebrow}>01 / Mekân</p><h2 id="banyo-baslik">Banyoda yüzeyler arasında ortak bir dil</h2><p>Gri damarlı açık renk yüzeyler; lavabo, dolap önleri, duvarlar ve zeminde devam eden bir malzeme dili oluşturuyor. Ahşap yüzeyler ve koyu renk armatürler, porselenin desenini çevreleyen doku ve renk katmanları olarak okunuyor.</p><p>Lavabo ön yüzünün yüksekliği, dolap kapaklarının bölünmesi ve duvar yüzeylerinin yerleşimi, malzeme seçimiyle birlikte ele alınan tasarım kararlarıdır.</p></div><Photo index={1} /></section>
      <section className={styles.section} aria-labelledby="lavabo-baslik"><div className={styles.sectionIntro}><p className={styles.eyebrow}>02 / Geometri</p><h2 id="lavabo-baslik">Porselen lavaboda biçim ve birleşim</h2><p>Lavabo yakın planları; hazne geometrisini, armatür yerleşimini ve tezgâhın düşey yüzeylerle ilişkisini öne çıkarıyor. Açık renk porselen, ahşap ve metal elemanlarla birlikte mekânın bütününe katılıyor.</p><p>Hazne ölçüsü, gider konumu, bağlantı biçimi ve mevcut mobilyayla uyum her proje için ayrıca değerlendirilir. Görseller, sabit ölçülü bir ürün vaadi değil, tamamlanmış uygulama örnekleridir.</p><Link className={styles.textLink} href="/cozumler/porselen-lavabo-cozumleri">Porselen lavabo çözümlerini inceleyin →</Link></div><div className={styles.grid}><Photo index={2} /><Photo index={3} /></div></section>
      <section className={styles.section} aria-labelledby="mutfak-baslik"><div className={styles.sectionIntro}><p className={styles.eyebrow}>03 / Yüzey</p><h2 id="mutfak-baslik">Mutfakta yatay ve düşey yüzey ilişkisi</h2><p>Ocak ve evye çevresindeki görünümler, tezgâh ile tezgâh arası yüzeyin birlikte ele alınmasını gösteriyor. Ada yakın planları ise malzemenin kenar ve hacim ilişkisine odaklanıyor.</p><p>Açık porselen yüzeylerin ahşap dolaplarla buluşması, tek bir malzemeyi öne çıkarmaktan çok bütünün dengesi üzerine düşünmeye imkân veriyor.</p><Link className={styles.textLink} href="/cozumler/mutfak-tezgahlari">Mutfak tezgâhı çözümlerini inceleyin →</Link></div><div className={styles.grid}><Photo index={4} /><Photo index={5} /><Photo index={6} /><Photo index={7} /></div></section>
      <section className={styles.section} aria-labelledby="mobilya-baslik"><div className={styles.sectionIntro}><p className={styles.eyebrow}>04 / Mobilya</p><h2 id="mobilya-baslik">Porselenin mobilyadaki karşılığı</h2><p>Farklı bir mutfak görünümünde porselen, mobilya ön yüzlerine taşınıyor. Bu kullanım; kapak bölünmeleri, yüzey yerleşimi ve çevresindeki mimari elemanlarla birlikte değerlendiriliyor.</p><p>Seçkinin ortak konusu tek bir mekân değil, porselenin farklı tasarım kararları içinde üstlenebildiği roller.</p></div><div className={styles.compactPhoto}><Photo index={8} /></div></section>
      <section className={styles.partnership} aria-labelledby="isbirligi-baslik"><p className={styles.eyebrow}>Mimarlar için üretim ortaklığı</p><h2 id="isbirligi-baslik">Çizimden uygulamaya, detayları birlikte konuşalım.</h2><p>Proje görüşmesinin başlangıç noktası; mimari çizimler, yaklaşık ölçüler, malzeme seçimi ve uygulama kapsamıdır. Üretim ve montaj sorumlulukları, destek gereksinimleri, birleşimler ve teslimat koşulları proje özelinde netleştirilir.</p><p>Buradaki uygulamalar yeni bir proje için ölçü, termin veya teknik performans taahhüdü yerine geçmez. Laminam malzeme markasıdır; bu seçkideki üretim ve uygulama çalışmaları Zenith Porcelain’e aittir.</p><div className={styles.links}><Link href="/markalar">İşlediğimiz markalar</Link><Link href="/cozumler/porselen-masa-ve-sehpalar">Masa ve sehpa çözümleri</Link></div></section>
      <section className={styles.cta} aria-labelledby="proje-baslik"><p className={styles.eyebrow}>Bir sonraki proje</p><h2 id="proje-baslik">Mimari projenizi paylaşın.</h2><p>Çiziminizi, yaklaşık ölçülerinizi ve ihtiyaç duyduğunuz uygulama kapsamını iletin; malzeme, üretim ve uygulama başlıklarını birlikte değerlendirelim.</p><Link href="/iletisim" className={styles.button}>Projenizi görüşelim</Link><a className={styles.phone} href="tel:+908502425900">+90 850 242 59 00</a></section>
    </div>
  </article></SubpageShell>;
}
