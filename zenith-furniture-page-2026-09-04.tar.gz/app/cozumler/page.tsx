import type { Metadata } from "next";
import SubpageShell from "../components/subpage-shell";
import { solutions } from "../site-data";
import { localizedAlternates } from "../seo";

export const metadata: Metadata = {
  title: "Porselen Çözümleri",
  description:
    "Mutfak ve banyo tezgâhı, 3 mm porselen mobilya kaplama, masa, lavabo, CNC, su jeti ve cam-porselen laminasyon çözümleri.",
  alternates: localizedAlternates("/cozumler"),
};

export default function Page() {
  return (
    <SubpageShell>
      <section className="sub-hero section-shell">
        <p className="eyebrow">Ürün ve hizmetler</p>
        <h1>
          Fikirden bitmiş ürüne
          <br />
          porselen çözümleri.
        </h1>
        <p>
          Projenize yalnızca malzeme değil; ölçüm, teknik detay, kontrollü üretim
          ve gerektiğinde profesyonel uygulama sunuyoruz.
        </p>
      </section>

      <section className="sub-grid section-shell">
        {solutions.map((solution) => (
          <a className="sub-card" href={`/cozumler/${solution.slug}`} key={solution.slug}>
            <img
              src={solution.image}
              alt={solution.imageAlt ?? `${solution.title} uygulaması`}
              loading="lazy"
              decoding="async"
            />
            <div>
              <p className="eyebrow">{solution.eyebrow}</p>
              <h2>{solution.title}</h2>
              <p>{solution.intro}</p>
              <span>Çözümü inceleyin ↗</span>
            </div>
          </a>
        ))}
      </section>

      <section className="sub-cta">
        <div>
          <p className="eyebrow light">Projeniz için ilk adım</p>
          <h2>Hangi çözümden başlayacağınızı birlikte belirleyelim.</h2>
        </div>
        <a className="button button-light" href="/#quote">
          Projenizi Gönderin
        </a>
      </section>
    </SubpageShell>
  );
}
