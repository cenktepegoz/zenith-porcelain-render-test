"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";

const primaryLinks = [
  { label: "Projeler", href: "/projeler" },
  { label: "Koleksiyonlar", href: "/koleksiyonlar" },
  { label: "Üretim", href: "/uretim-teknolojileri" },
  { label: "Profesyoneller", href: "/profesyoneller" },
];

const applicationGroups = [
  {
    title: "Yaşam Alanları",
    links: [
      ["Mutfak Tezgâhları", "/cozumler/mutfak-tezgahlari"],
      ["Banyo & Lavabo", "/cozumler/porselen-lavabo-cozumleri"],
      ["Marmox Destekli Tezgâhlar", "/cozumler/marmox-destekli-porselen-lavabo-ve-tezgahlar"],
      ["Masa & Sehpa", "/cozumler/porselen-masa-ve-sehpalar"],
      ["3 mm Porselen Mobilya", "/cozumler/3-mm-porselen-mobilya-kaplama"],
    ],
  },
  {
    title: "Üretim Yetkinlikleri",
    links: [
      ["CNC & Su Jeti", "/cozumler/cnc-su-jeti-fason-uretim"],
      ["Cam–Porselen Laminasyonu", "/cozumler/cam-porselen-laminasyonu"],
      ["Mimari Özel Projeler", "/cozumler/mimari-ve-ozel-projeler"],
    ],
  },
  {title:"Keşif & Kurumsal",links:[["Proje Galerisi","/projeler"],["Yeşil Enerji & Su","/yesil-enerji-ve-su-donusumu"],["Bilgi Merkezi","/bilgi-merkezi"],["Hakkımızda","/hakkimizda"],["İletişim","/iletisim"]]},
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const mobileDialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 36);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    if (!mobileOpen) return () => { document.body.style.overflow = ""; };

    const dialog = mobileDialogRef.current;
    const focusable = dialog?.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), summary, [tabindex]:not([tabindex="-1"])',
    );
    focusable?.[0]?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMobileOpen(false);
        return;
      }
      if (event.key !== "Tab" || !focusable?.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKeyDown);
      menuButtonRef.current?.focus();
    };
  }, [mobileOpen]);

  return (
    <header className={`zp-nav ${scrolled ? "is-scrolled" : ""} ${mobileOpen ? "is-mobile-open" : ""}`}>
      <a className="zp-logo" href="/" aria-label="Zenith Porcelain ana sayfa">
        <img src="/images/zenith-porcelain-logo-clean.png" alt="Zenith Porcelain" />
      </a>

      <nav className="zp-nav-links" aria-label="Ana menü">
        <div className="zp-mega-trigger" onMouseEnter={() => setMegaOpen(true)} onMouseLeave={() => setMegaOpen(false)}>
          <button type="button" aria-expanded={megaOpen} onFocus={() => setMegaOpen(true)} onClick={() => setMegaOpen((value) => !value)}>
            Uygulamalarımız <ChevronDown size={13} strokeWidth={1.5} />
          </button>
          <AnimatePresence>
            {megaOpen && (
              <motion.div className="zp-mega" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}>
                <div className="zp-mega-copy">
                  <p className="zp-kicker">Plakadan ürüne</p>
                  <h2>Hassas üretim,<br />mekâna özel sonuç.</h2>
                  <a href="/cozumler">Tüm uygulamaları görün <ArrowUpRight size={15} /></a>
                </div>
                {applicationGroups.map((group) => (
                  <div className="zp-mega-group" key={group.title}>
                    <p>{group.title}</p>
                    {group.links.map(([label, href]) => <a key={label} href={href}>{label}<ArrowUpRight size={14} /></a>)}
                  </div>
                ))}
                <a className="zp-mega-image" href="/projeler">
                  <img src="/images/projects/calacatta-hermitage-table.webp" alt="Oval porselen masa uygulaması" />
                  <span>Yeni proje galerisini keşfedin <ArrowUpRight size={14} /></span>
                </a>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {primaryLinks.map((link) => <a key={link.label} href={link.href}>{link.label}</a>)}
      </nav>

      <div className="zp-nav-actions"><details className="zp-language-menu"><summary>TR</summary><div><a href="/en">EN</a><a href="/es">ES</a><a href="/de">DE</a><a href="/ar">AR</a><a href="/it">IT</a></div></details><a className="zp-nav-cta" href="/#contact">Projenizi Anlatın <ArrowUpRight size={15} /></a></div>
      <button ref={menuButtonRef} className="zp-menu-button" type="button" aria-label="Menüyü aç" aria-expanded={mobileOpen} aria-controls="zp-mobile-navigation" onClick={() => setMobileOpen(true)}><Menu aria-hidden="true" /></button>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div ref={mobileDialogRef} id="zp-mobile-navigation" className="zp-mobile-menu" role="dialog" aria-modal="true" aria-label="Mobil ana menü" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ duration: 0.42, ease: [0.22, 1, 0.36, 1] }}>
              <button type="button" aria-label="Menüyü kapat" onClick={() => setMobileOpen(false)}><X aria-hidden="true" /></button>
              <div className="zp-mobile-menu-head">
                <p className="zp-kicker">Menü</p>
                <nav className="zp-mobile-languages" aria-label="Dil seçenekleri">
                  <a className="is-active" href="/" lang="tr" aria-current="page">TR</a>
                  <a href="/en" lang="en">EN</a><a href="/es" lang="es">ES</a>
                  <a href="/de" lang="de">DE</a><a href="/ar" lang="ar">AR</a>
                  <a href="/it" lang="it">IT</a>
                </nav>
              </div>
              <div className="zp-mobile-menu-scroll">
                <a className="zp-mobile-primary" href="/cozumler" onClick={() => setMobileOpen(false)}>Tüm Uygulamalar</a>
                {applicationGroups.map((group) => <section className="zp-mobile-group" key={group.title}>
                  <h2>{group.title}</h2>
                  {group.links.map(([label,href])=><a className="zp-mobile-sub" key={label} href={href} onClick={()=>setMobileOpen(false)}>{label}<ArrowUpRight size={14}/></a>)}
                </section>)}
                <section className="zp-mobile-group zp-mobile-primary-links">
                  <h2>Ana Sayfalar</h2>
                  {primaryLinks.map((link) => <a key={link.label} href={link.href} onClick={() => setMobileOpen(false)}>{link.label}<ArrowUpRight size={14}/></a>)}
                </section>
              </div>
              <div className="zp-mobile-contact"><span>Proje ve teknik danışmanlık</span><a href="tel:+902222555400">+90 222 255 54 00</a><a href="https://wa.me/908502425900?text=Merhaba%20Zenith%20Porcelain%2C%20projem%20hakk%C4%B1nda%20bilgi%20almak%20istiyorum." target="_blank" rel="noreferrer">WhatsApp'tan yazın ↗</a></div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
