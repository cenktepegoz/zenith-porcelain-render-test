export type Solution = {
  slug: string; title: string; eyebrow: string; intro: string; image: string;
  benefits: { title: string; text: string }[]; applications: string[];
  process: string[]; faqs: { q: string; a: string }[];
  video?: { src: string; poster: string; captions: string; title: string; description: string };
  imageAlt?: string;
  seo?: { title: string; description: string; keywords?: string[] };
  sections?: {
    eyebrow?: string;
    title: string;
    paragraphs: string[];
    items?: string[];
  }[];
  relatedLinks?: { title: string; href: string; description: string }[];
  decisions?: { number: string; title: string; text: string }[];
};

export const solutions: Solution[] = [
{slug:"mutfak-tezgahlari",title:"Porselen mutfak tezgâhları",eyebrow:"Özel ölçü üretim ve montaj",image:"/images/zenith-hero-kitchen-1800.jpg",intro:"Mutfağı yalnızca bir yüzey olarak değil; dolap, evye, ocak, armatür, duvar ve kullanım alışkanlıklarının birlikte çalıştığı teknik bir bütün olarak ele alıyoruz. Dijital ölçümden profesyonel montaja kadar tüm süreci tek ekip yönetiyor.",benefits:[{title:"Leica iCON iCS50 ile doğru başlangıç",text:"Duvar, gönye, kot, dolap ve sabit elemanları milimetrik 3D saha verisine dönüştürür; üretim çizimini gerçek mekân geometrisine göre hazırlarız."},{title:"Evye ve ankastre detayları",text:"Alttan veya üstten evye, ocak kesimi, armatür, priz ve süpürgelik ilişkisini üretim çiziminde çözeriz."},{title:"Kontrollü kenar ve birleşim",text:"Pah, rodaj, kalınlaştırılmış ön alın ve köşe birleşimlerini tasarım beklentisine göre üretiriz."}],applications:["Mutfak tezgâhı","Ada ve yarımada","Tezgâh arası yüzey","Süpürgelik ve duvar dönüşü","Evye ve ocak kesimleri","Özel kenar detayları"],process:["Ön bilgi ve proje değerlendirmesi","Leica iCON iCS50 ile 3D dijital saha ölçümü","Üretim çizimi ve müşteri onayı","Kesim, CNC ve kenar işleme","Kalite kontrol, sevkiyat ve montaj"],faqs:[{q:"Mevcut mutfağa porselen tezgâh uygulanabilir mi?",a:"Evet. Mevcut dolapların taşıma, terazi ve ölçü durumu keşifte değerlendirilir; uygun detay buna göre projelendirilir."},{q:"Montaj sırasında evde kesim yapılır mı?",a:"Leica iCON iCS50 ölçüm verisi ve onaylanmış üretim çizimiyle parçaları tesiste tamamlayarak, uygun saha koşullarında montaj sırasında kesim ihtiyacını ortadan kaldırmayı hedefliyoruz."}]},
  {slug:"banyo-tezgahlari-ve-lavabolar",title:"Banyo tezgâhları ve lavabo yüzeyleri",eyebrow:"Hijyenik ve bütünleşik çözümler",image:"/images/zenith-porcelain-bathroom-1400.jpg",intro:"Banyo tezgâhını lavabo, armatür, gider, mobilya ve su akışıyla birlikte projelendiriyoruz. Böylece estetik kadar kullanım konforu ve mobilya güvenliği de üretimin parçası oluyor.",benefits:[{title:"Gözeneksiz ve kolay temizlenen yüzey",text:"Porselen yüzeyler su ve neme karşı kararlı yapısıyla banyo kullanımında hijyenik bir çözüm sunar."},{title:"Lavaboyla bütünleşen tasarım",text:"Lavabo formu, eğim, gider ve armatür konumunu tezgâh ve mobilyayla birlikte çözeriz."},{title:"Teknik ekip kontrolü",text:"Su akışını ve kullanım ergonomisini etkileyen kritik detaylar üretimden önce teknik çizimde doğrulanır."}],applications:["Banyo tezgâhı","Bütünleşik porselen lavabo","Çift lavabolu tezgâh","Duvardan duvara yüzey","Niş ve raf","Otel ve toplu konut banyoları"],process:["Mobilya ve armatür bilgilerinin alınması","Ölçü ve kullanım senaryosu","Lavabo, eğim ve gider detayının çizimi","Üretim ve su akış kontrolü","Sevkiyat ve profesyonel montaj"],faqs:[{q:"Porselen lavabo ölçüye özel üretilebilir mi?",a:"Evet. Genişlik, derinlik, lavabo formu ve armatür konumu proje koşullarına göre belirlenebilir."},{q:"Armatür konumu neden üretimden önce netleşmeli?",a:"Armatürün suyu doğru noktaya vermesi, sıçramayı azaltması ve mobilyayı koruması için lavabo geometrisiyle birlikte değerlendirilmesi gerekir."}]},
  {slug:"porselen-masa-ve-sehpalar",title:"Porselen masa ve sehpa tablaları",eyebrow:"Cam-porselen laminasyon teknolojisi",image:"/images/zenith-porcelain-table-1400.jpg",intro:"İnce porseleni camla lamine ederek hafif, güçlü ve modern masa tablaları üretiyoruz. Mobilya markalarına prototipten seri üretime; mimari projelere ise ölçü ve forma özel çözümler sunuyoruz.",benefits:[{title:"İnce ve güçlü yapı",text:"Cam laminasyon, ince porselenin taşıma ve kullanım güvenliğini artırırken zarif görünümü korur."},{title:"Forma ve mekanizmaya uyum",text:"Dikdörtgen, oval, yuvarlak ve özel formlar; ayak ve açılır mekanizma detaylarına göre hazırlanır."},{title:"Seri üretimde tekrarlanabilirlik",text:"Model, ölçü, kenar ve bağlantı detaylarını standardize ederek mobilya markalarına düzenli üretim sağlarız."}],applications:["Yemek masası","Kafe ve restoran masası","Orta ve yan sehpa","Açılır-kapanır masa","Toplantı masası","Özel marka / OEM tabla"],process:["Model, ölçü ve adet briefi","Ayak veya mekanizma kontrolü","Numune ve üretim standardı","Laminasyon, kesim ve rodaj","Kalite, paketleme ve sevkiyat"],faqs:[{q:"Kendi masa ayağımıza uygun tabla üretebilir misiniz?",a:"Evet. Ayak, mekanizma ve bağlantı detayları teknik ekip tarafından incelenerek uygun ölçü ve bağlantı çözümü hazırlanır."},{q:"Mobilya markaları için adetli üretim yapıyor musunuz?",a:"Evet. Numune onayı sonrasında tekrarlanabilir model ve kalite standardıyla seri üretim planlanabilir."}]},
  {slug:"porselen-lavabo-cozumleri",title:"Projeye özel porselen lavabolar",eyebrow:"Form, eğim ve gider mühendisliği",image:"/images/zenith-porcelain-bathroom-1400.jpg",intro:"Tezgâhla bütünleşen veya bağımsız tasarlanan porselen lavaboları, yalnızca estetik bir obje olarak değil; doğru su akışı ve uzun süreli kullanım gerektiren teknik bir ürün olarak üretiyoruz.",benefits:[{title:"Tek parça görünüm",text:"Tezgâh ve lavabo aynı yüzey diliyle bütünleşir; mimari sadelik ve kolay bakım sağlanır."},{title:"Projeye özel geometri",text:"Lavabo ölçüsü, derinliği, taban eğimi ve gider noktası kullanım senaryosuna göre düzenlenir."},{title:"Mobilyayı koruyan detay",text:"Armatür menzili, taşma riski ve su akışı birlikte değerlendirilerek dolap üzerindeki risk azaltılır."}],applications:["Banyo dolabı lavabosu","Otel banyosu","Misafir WC","Çift lavabo","Duvar tipi lavabo","Özel tasarım lavabo"],process:["Tasarım ve armatür verileri","Teknik çizim ve su akışı çözümü","Numune veya mock-up değerlendirmesi","Kesim, birleştirme ve kalite kontrol","Paketleme ve uygulama"],faqs:[{q:"Her porselen deseninden lavabo yapılabilir mi?",a:"Plaka kalınlığı, desen yönü, ebat ve üretim detayı birlikte değerlendirilir; teknik olarak uygun yüzeyler önerilir."},{q:"Lavaboda su birikmemesi nasıl sağlanır?",a:"Taban eğimi, gider konumu ve armatür akışı üretim çiziminde birlikte hesaplanır ve üretimde kontrol edilir."}]},
  {slug:"marmox-destekli-porselen-lavabo-ve-tezgahlar",title:"Marmox destekli porselen lavabo ve tezgâhlar",eyebrow:"Hafif, rijit ve sürekli taşıyıcı altyapı",image:"/images/marmox-porselen-lavabo-tezgah-video.jpg",intro:"Porselen lavabo ve tezgâhların altında Marmox ile sürekli bir taşıyıcı gövde oluşturuyoruz. Boşlukları azaltan bu uygulama; yükün daha dengeli dağılmasına, yüzeydeki esnemenin sınırlanmasına ve sistemin darbelere karşı daha güvenli çalışmasına yardımcı olur.",video:{src:"/videos/marmox-porselen-lavabo-tezgah-guclendirme.mp4",poster:"/images/marmox-porselen-lavabo-tezgah-video.jpg",captions:"/videos/marmox-porselen-lavabo-tezgah-guclendirme-tr.vtt",title:"Marmox ile porselen lavabo ve tezgâh altyapısı",description:"Marmox tam dolgu ve taşıyıcı altyapının porselen lavabo ile tezgâh sistemlerinde yük dağılımı, rijitlik, yapışma, ağırlık ve ıslak hacim performansına katkısını anlatan uygulama videosu."},benefits:[{title:"Sürekli alt destek",text:"Porselenin altında mümkün olduğunca kesintisiz bir taşıyıcı yüzey oluşturularak noktasal yük ve boşluk kaynaklı gerilimlerin azaltılması hedeflenir."},{title:"Dengeli yük ve darbe dağılımı",text:"Rijit altyapı, kullanım yüklerinin ve darbelerin daha geniş bir alana aktarılmasına yardımcı olarak bütün sistemin dayanımını destekler."},{title:"Islak hacme uygun hafif gövde",text:"XPS çekirdekli Marmox levha, düşük ağırlıkla taşıyıcı bir gövde kurmaya imkân verir. Nihai su dayanımı; doğru yapıştırıcı, birleşim ve kenar yalıtımıyla birlikte sağlanır."}],applications:["Bütünleşik porselen lavabo","Banyo tezgâhı","Mutfak tezgâhı ve ada","Otel ve toplu konut banyoları","Özel ölçü lavabo gövdesi","Hafifletilmiş mobilya üstü yüzey"],process:["Proje, kullanım ve taşıyıcı mobilya analizi","Lavabo, gider ve donanım geometrisinin hazırlanması","Marmox gövde ve sürekli destek detayının oluşturulması","Uygun yapıştırıcıyla porselen kaplama ve birleşimlerin işlenmesi","Kenar, su yalıtımı ve nihai kalite kontrolü"],faqs:[{q:"Marmox porseleni kırılmaz hâle getirir mi?",a:"Hayır. Hiçbir altyapı porseleni kırılmaz yapmaz. Marmox ile oluşturulan sürekli ve rijit destek; esnemeyi, boşlukları ve noktasal gerilimleri azaltarak sistemin dayanımını artırmaya yardımcı olur."},{q:"Marmox kullanılan lavabo ve tezgâh tamamen su geçirmez midir?",a:"Levhanın XPS çekirdeği suya dayanıklıdır; ancak bitmiş sistemin su güvenliği, birleşimlerin, vida veya donanım geçişlerinin, kenarların ve yapıştırıcıların doğru detaylandırılmasına bağlıdır."}]},
  {slug:"mimari-ve-ozel-projeler",title:"Mimari yüzeyler ve özel projeler",eyebrow:"Tasarımdan uygulamaya teknik eşlik",image:"/images/cafe-restoran-projesi.jpeg",intro:"Standart ürünlerin yetmediği projelerde mimarın fikrini üretilebilir, sevk edilebilir ve uygulanabilir parçalar haline getiriyoruz. Detay çözümünden saha koordinasyonuna kadar teknik sorumluluk üstleniyoruz.",benefits:[{title:"Üretilebilirlik danışmanlığı",text:"Tasarım niyetini koruyarak plaka ölçüsü, birleşim, taşıyıcı ve montaj detaylarını optimize ederiz."},{title:"Hassas özel kesimler",text:"Su jeti ve CNC kabiliyetleriyle desen, delik, yazı, form ve birleşim gerektiren parçalar üretebiliriz."},{title:"Proje ve saha koordinasyonu",text:"Ölçüm, üretim sırası, paketleme ve montajı şantiye programıyla uyumlu planlarız."}],applications:["Duvar ve zemin","Merdiven ve basamak","Resepsiyon bankosu","Özel mobilya yüzeyi","Cosmati ve su jeti desen","Otel ve ticari alan"],process:["Mimari brief ve dosya inceleme","Malzeme, detay ve metraj analizi","Numune / mock-up / shopdrawing","Fazlı üretim ve kalite kontrol","Kodlu paketleme ve saha uygulaması"],faqs:[{q:"Mimarın çizimini üretim detayına dönüştürüyor musunuz?",a:"Evet. Uygulama ve üretim risklerini değerlendirerek shopdrawing ve detay önerileriyle proje ekibine destek veriyoruz."},{q:"Türkiye dışındaki projelere üretim yapılabilir mi?",a:"Proje, ebat, ambalaj ve teslim koşullarına göre ihracata uygun üretim ve paketleme modeli oluşturulabilir."}]},
  {slug:"cnc-su-jeti-fason-uretim",title:"CNC, su jeti ve fason üretim",eyebrow:"Teknik dosyadan tekrarlanabilir ürüne",image:"/images/waterjet-cutting-service.jpeg",intro:"Porselen, cam ve uygun yüzey malzemelerinde kesim, delik, kanal, rodaj ve özel form işlemlerini; müşteri malzemesi veya Zenith tedarikli modelle gerçekleştiriyoruz.",benefits:[{title:"Teknik dosyayla hızlı başlangıç",text:"DWG, DXF, PDF veya ölçü listesi üzerinden üretilebilirlik ve işleme kapsamını değerlendiririz."},{title:"Emanet malzemede izlenebilirlik",text:"Müşteriye ait malzemeyi kabul, üretim ve teslim adımlarında ayrıştırılmış şekilde yönetiriz."},{title:"Tekil parçadan seriye",text:"Prototip, yenileme parçası veya tekrar eden üretim ihtiyaçlarına uygun planlama yaparız."}],applications:["Su jeti kesim","CNC kenar işleme","Rodaj ve pah","Delik ve kanal","Özel geometrik kesim","Fason ve OEM üretim"],process:["Dosya ve malzeme kabulü","Üretilebilirlik / nesting kontrolü","İş emri ve parça kodlama","Kesim, işleme ve ölçü kontrolü","Paketleme ve teslim"],faqs:[{q:"Müşterinin kendi plakasını işliyor musunuz?",a:"Evet. Malzeme kabul koşulları ve işleme riski önceden değerlendirilerek müşteri malzemeli fason üretim yapılabilir."},{q:"Tek parça iş kabul ediyor musunuz?",a:"Makine ve operasyon uygunluğuna göre tekil parçalar da değerlendirilebilir; minimum hizmet bedeli teklif aşamasında belirtilir."}]},
  {slug:"cam-porselen-laminasyonu",title:"Cam-porselen laminasyonu",eyebrow:"İnce yüzeyde yüksek performans",image:"/images/zenith-porcelain-table-1400.jpg",intro:"İnce porselen ile camı kontrollü proses altında birleştirerek masa, sehpa, mobilya ve mimari panel uygulamalarına uygun kompozit yüzeyler üretiyoruz.",benefits:[{title:"Hafiflik ve mukavemet",text:"Doğru cam ve porselen kombinasyonu, ince görünümü korurken taşıma ve kullanım performansını güçlendirir."},{title:"Kontrollü endüstriyel proses",text:"Temizlik, EVA katmanı, kenar bandı, ısı ve çevrim parametreleri üretim standardı içinde yönetilir."},{title:"Tasarım esnekliği",text:"Farklı ölçü, form ve kenar çözümleriyle mobilya ve mimari ürün geliştirmeye imkân verir."}],applications:["Masa ve sehpa tablası","Mobilya paneli","Mimari cam panel","Özel ebatlı yüzey","Mekanizmalı masa","OEM ürün geliştirme"],process:["Cam ve porselen kombinasyonunun seçimi","Kesim ve yüzey hazırlığı","Yıkama ve katman yerleşimi","Kontrollü laminasyon çevrimi","Kenar işleme ve kalite kontrol"],faqs:[{q:"Laminasyon yalnızca masa için mi kullanılır?",a:"Hayır. Teknik uygunluğa göre mobilya paneli, dekoratif yüzey ve mimari cam uygulamalarında da değerlendirilebilir."},{q:"Farklı EVA katmanları uygulanabilir mi?",a:"Ürün yapısı ve performans beklentisine göre katman sayısı teknik ekip tarafından belirlenir."}]},
  {
    slug: "3-mm-porselen-mobilya-kaplama",
    title: "3 mm porselenden mobilyaya",
    eyebrow: "Porselen mobilya kaplama ve cam laminasyon",
    image: "/images/projects/3mm-porselen-mobilya-saloni.jpg",
    imageAlt: "Porselen yüzeyli TV ünitesi ve sehpalara sahip çağdaş Saloni yaşam alanı",
    intro: "3 mm porseleni projeye uygun camla lamine ederek masa, sehpa, TV ünitesi, konsol, komodin ve özel tasarım mobilyalar için ince görünümlü, dengeli ve üretilebilir yüzey bileşenlerine dönüştürüyoruz.",
    seo: {
      title: "3 mm Porselen Mobilya Kaplama",
      description: "3 mm porselenin camla laminasyonu ile masa, sehpa, TV ünitesi ve özel mobilyalara ince, güvenli ve projeye özel yüzey çözümleri.",
      keywords: [
        "3 mm porselen",
        "porselen mobilya kaplama",
        "cam porselen laminasyonu",
        "porselen TV ünitesi",
        "porselen masa tablası",
        "özel mobilya yüzeyi",
      ],
    },
    benefits: [
      {
        title: "İnce ve rafine oranlar",
        text: "3 mm kesit, geleneksel kalın plakaların ağır görüntüsü olmadan doğal taş, mermer veya beton etkisini mobilyaya taşır; zarif kenarlar ve kesintisiz yüzeyler oluşturur.",
      },
      {
        title: "Cam destekli dengeli yapı",
        text: "Projeye uygun camla kontrollü laminasyon, porselenin estetik yüzünü korurken yüzeye rijitlik ve ölçü kararlılığı kazandırmaya yardımcı olur.",
      },
      {
        title: "Tek üründen seri üretime",
        text: "Ölçü, damar yönü, kesim, delik ve bağlantı detayları dijital olarak planlanarak özel üretimden adetli mobilya koleksiyonlarına kadar tekrarlanabilir kalite hedeflenir.",
      },
    ],
    applications: [
      "Orta sehpa ve yan sehpa tablaları",
      "Yemek ve toplantı masaları",
      "TV ünitesi ve medya konsolu üstleri",
      "Konsol, şifonyer ve komodin yüzeyleri",
      "Dolap kapakları ve dekoratif paneller",
      "Otel, restoran ve mağaza sabit mobilyaları",
    ],
    sections: [
      {
        eyebrow: "Tasarım özgürlüğü",
        title: "3 mm porselen neden mobilya için önemli?",
        paragraphs: [
          "Mobilyada yüzey kalınlığı yalnızca teknik bir ölçü değildir; ürünün oranını ve görsel ağırlığını doğrudan belirler. 3 mm porselen, doğal taş karakterini çağdaş mobilyanın hafif çizgisiyle bir araya getirir.",
          "Geniş desen ve renk seçenekleri; ahşap, metal, cam ve lake yüzeylerle dengeli kombinasyonlar kurulmasına imkân verir. Aynı sistem, özel bir konut mobilyasında da yoğun kullanılan ticari mekân projelerinde de uygulanabilir.",
        ],
        items: [
          "İnce kenar ve yalın gövde detayları",
          "Damar yönü planlanmış kesintisiz yüzeyler",
          "Mobilya mekanizması ve bağlantılarına özel işleme",
          "Prototipten koleksiyon üretimine ölçeklenebilir süreç",
        ],
      },
      {
        eyebrow: "Taşıyıcı sistem",
        title: "Cam laminasyonu ne kazandırır?",
        paragraphs: [
          "3 mm porselenin mobilyada doğru performans göstermesi, yüzey seçimi kadar arkasındaki taşıyıcı sistemin de doğru tasarlanmasına bağlıdır. Zenith Porcelain’in çözümünde ince porselen, kullanım senaryosuna uygun camla kontrollü biçimde birleştirilir.",
          "Bağlantı noktaları, kenarlar ve taşıyıcı konstrüksiyon birlikte planlandığında daha güvenli ve dengeli bir mobilya bileşeni elde edilir. Bu mühendislik yaklaşımı özellikle geniş tablalar, ince kenar görünümü ve yoğun kullanım beklenen yüzeylerde belirleyicidir.",
          "Dijital olarak planlanan ölçü, kesim, delik ve bağlantı detayları; porselen yüzeyin mobilyanın diğer parçalarıyla daha kontrollü birleşmesini ve üretimde tekrarlanabilirliği destekler.",
        ],
      },
      {
        eyebrow: "Günlük performans",
        title: "Estetik kadar kullanım koşulları da önemli",
        paragraphs: [
          "Bir mobilya yalnızca ilk gün iyi görünmemeli; günlük yaşama da uyum sağlamalıdır. Seçilen porselenin teknik verileri ve kullanım koşullarına bağlı olarak yüzey; leke, ısı, UV ışığı ve günlük çizilme etkilerine karşı yüksek direnç sunabilir. Düşük bakım ihtiyacı ve kolay temizlenebilir yapı, masa ve sehpa gibi sık temas edilen mobilyalarda önemli bir avantajdır.",
          "Uzun ömürlü sonuç yalnızca malzemeye bağlı değildir. Doğru porselen seçimi, laminasyon tekniği, taşıyıcı tasarımı, kenar işçiliği ve montajın birlikte ele alınması gerekir.",
        ],
      },
      {
        eyebrow: "Saloni ürünleri",
        title: "Tasarımlarıyla sektöre yön veren bir mobilya dili",
        paragraphs: [
          "Bu sayfadaki yaşam alanı, TV ünitesi, konsol, sehpa ve yüzey detayı görsellerinde Saloni ürünleri yer alıyor. Tasarımlarıyla mobilya sektörüne yön veren Saloni; porseleni sonradan eklenmiş dekoratif bir parça olarak değil, ürünün çizgisine, oranına ve malzeme diline katılan bütüncül bir tasarım öğesi olarak kullanıyor.",
          "Saloni ürünlerindeki uzun yatay yüzeyler, ince kenar detayları ve birbiriyle uyumlu mobilya bileşenleri aynı malzeme dilini yaşam alanının tamamına taşıyor. Ortaya tek tek dikkat çekmeye çalışan parçalar yerine, birbiriyle konuşan ve çağdaş yaşam alanına dengeli biçimde yerleşen bir kompozisyon çıkıyor.",
        ],
      },
      {
        eyebrow: "Projeye özel üretim",
        title: "Zenith Porcelain ile fikirden bitmiş bileşene",
        paragraphs: [
          "Zenith Porcelain; 3 mm porseleni camla lamine ederek mobilya üreticileri, mimarlar ve tasarımcılar için projeye özel yüzey bileşenleri üretir. Süreç; malzeme seçimi, ölçülendirme, damar yönü, kesim, kenar işlemleri, delik ve bağlantı detayları ile laminasyonun birlikte değerlendirilmesini kapsar.",
          "İster tek bir özel üretim sehpa ister adetli bir mobilya koleksiyonu olsun, hedefimiz porselenin estetik gücünü kullanım senaryosuna uygun, güvenilir ve üretilebilir bir çözüme dönüştürmektir.",
        ],
      },
    ],
    process: [
      "Mobilya modeli, ölçü, adet ve kullanım senaryosunun değerlendirilmesi",
      "Porselen, cam, taşıyıcı ve bağlantı sisteminin birlikte seçilmesi",
      "Damar yönü, kesim, delik ve kenar detaylarının dijital planlanması",
      "Kesim, kenar işleme ve kontrollü cam-porselen laminasyonu",
      "Ölçü ve yüzey kontrolü, koruyucu paketleme ve teslim",
    ],
    decisions: [
      { number: "01", title: "Mobilya gövdesi ve kullanım", text: "Ürünün ölçüsü, hareketli parçaları, taşıma biçimi, kullanım yoğunluğu ve mevcut konstrüksiyonu birlikte değerlendirilir." },
      { number: "02", title: "Porselen ve cam seçimi", text: "Desen, plaka yönü, cam tipi ve toplam bileşen kalınlığı tasarım hedefi ile teknik gereksinimlere göre belirlenir." },
      { number: "03", title: "Kenar ve bağlantılar", text: "Delikler, metal bağlantılar, menteşeler, mekanizmalar ve kenar bitişleri üretim dosyasında ölçülendirilir." },
      { number: "04", title: "Paketleme ve montaj", text: "Parçanın ağırlığı, taşıma rotası, koruyucu ambalajı ve sahadaki montaj sırası üretimden önce planlanır." },
    ],
    faqs: [
      { q: "3 mm porselen doğrudan mobilyaya uygulanabilir mi?", a: "Uygulama; mobilyanın ölçüsü, taşıyıcı yapısı, bağlantıları ve kullanım senaryosuna göre değerlendirilmelidir. Geniş veya yoğun kullanılan yüzeylerde projeye uygun cam laminasyonu ve doğru konstrüksiyon önem taşır." },
      { q: "Hangi mobilyalara porselen kaplama yapılabilir?", a: "Masa ve sehpa tablaları, TV üniteleri, konsollar, komodinler, dolap kapakları ve sabit ticari mobilyalar teknik uygunluk değerlendirmesinin ardından üretilebilir." },
      { q: "Mobilya markaları için adetli üretim yapıyor musunuz?", a: "Evet. Prototip ve numune onayından sonra ölçü, kenar, delik ve bağlantı standartları tanımlanarak adetli veya OEM üretim planlanabilir." },
      { q: "Porselen deseninin yönü nasıl belirlenir?", a: "Damar yönü; mobilyanın formu, parça yerleşimi, devamlılık beklentisi ve plaka verimi birlikte değerlendirilerek üretim çiziminde onaya sunulur." },
    ],
    relatedLinks: [
      { title: "Cam-porselen laminasyonu", href: "/cozumler/cam-porselen-laminasyonu", description: "İnce porselen ile camı birleştirdiğimiz kontrollü üretim sürecini inceleyin." },
      { title: "Porselen masa ve sehpalar", href: "/cozumler/porselen-masa-ve-sehpalar", description: "Özel form, mekanizma ve adetli tabla üretimi olanaklarını keşfedin." },
      { title: "CNC, su jeti ve fason üretim", href: "/cozumler/cnc-su-jeti-fason-uretim", description: "Kesim, delik, kanal ve özel form işlemlerine yönelik üretim altyapımızı görün." },
    ],
  },
];

export const professionalGroups = [
  {title:"Mimarlar ve proje ofisleri",promise:"Tasarım fikrinizi üretilebilir ve uygulanabilir detaya dönüştüren teknik ekip.",points:["Malzeme ve numune desteği","Shopdrawing ve detay çözümü","Özel ölçü ve mock-up","Proje dosyasıyla hızlı değerlendirme"]},
  {title:"Müteahhitler ve proje firmaları",promise:"Ölçümden üretim ve montaja kadar tek teknik sorumluluk.",points:["Metraj ve faz planlama","Termin ve saha koordinasyonu","Toplu konut, otel ve ticari proje","Hakedişe uygun iş takibi"]},
  {title:"Mobilya, mutfak ve banyo üreticileri",promise:"Markanız için ölçeklenebilir porselen işleme ve ürünleştirme kapasitesi.",points:["Prototip ve numune","Seri masa tablası","Porselen lavabo ve tezgâh","OEM / özel marka üretim"]},
  {title:"Otel, restoran ve kafeler",promise:"Yoğun kullanım için tasarım, üretim ve uygulama bütünlüğü.",points:["Adetli masa ve sehpa","Servis ve bar tezgâhı","Otel banyo çözümleri","Yenileme ve özel proje"]},
  {title:"Ev sahipleri",promise:"Seçimden montaja kadar anlaşılır ve profesyonel süreç.",points:["Mutfak ve banyo keşfi","Yüzey ve renk yönlendirmesi","Özel ölçü üretim","Montaj ve kullanım desteği"]},
  {title:"İhracat ve OEM",promise:"Türkiye’de entegre üretim; uluslararası projeler için kontrollü teslimat.",points:["Teknik İngilizce iletişim","İhracat ambalajı","Özel marka üretim","Proje ve seri üretim"]},
];
