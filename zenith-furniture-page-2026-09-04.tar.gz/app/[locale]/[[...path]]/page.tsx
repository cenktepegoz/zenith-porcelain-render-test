import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ResilientImage from "../../components/resilient-image";

const locales = ["en", "es", "de", "ar", "it"] as const;
type Locale = typeof locales[number];
const openGraphLocales: Record<Locale, string> = {
  en: "en_GB",
  es: "es_ES",
  de: "de_DE",
  ar: "ar_AE",
  it: "it_IT",
};

const paths = [
  "", "cozumler", "projeler", "koleksiyonlar", "profesyoneller", "uretim-teknolojileri",
  "yesil-enerji-ve-su-donusumu", "bilgi-merkezi", "hakkimizda", "iletisim",
  "collections/endustriyel-beton", "collections/statuario-mermer", "collections/antrasit-tas",
  "cozumler/mutfak-tezgahlari", "cozumler/banyo-tezgahlari-ve-lavabolar",
  "cozumler/porselen-masa-ve-sehpalar", "cozumler/porselen-lavabo-cozumleri",
  "cozumler/mimari-ve-ozel-projeler", "cozumler/cnc-su-jeti-fason-uretim",
  "cozumler/cam-porselen-laminasyonu", "cozumler/marmox-destekli-porselen-lavabo-ve-tezgahlar",
  "cozumler/3-mm-porselen-mobilya-kaplama",
] as const;

const pageImages: Record<string, string> = {
  "": "/images/zenith-hero-kitchen-1800.jpg",
  cozumler: "/images/legacy/magellano-kitchen-island.webp",
  projeler: "/images/projects/villa-tigertail-kitchen-wide.jpg",
  koleksiyonlar: "/images/zenith-porcelain-table-1400.jpg",
  profesyoneller: "/images/cafe-restoran-projesi.jpeg",
  "uretim-teknolojileri": "/images/facility/leica-icon-ics50-site-measurement-wide.jpg",
  "yesil-enerji-ve-su-donusumu": "/images/reverse-osmoz-endustriyel-aritma.jpg",
  "bilgi-merkezi": "/images/legacy/calacatta-hermitage-table.webp",
  hakkimizda: "/images/legacy/eskisehir-factory.webp",
  iletisim: "/images/zenith-porcelain-bathroom-1400.jpg",
  "collections/endustriyel-beton": "/images/zenith-porcelain-table-1400.jpg",
  "collections/statuario-mermer": "/images/zenith-hero-kitchen-1800.jpg",
  "collections/antrasit-tas": "/images/zenith-porcelain-bathroom-1400.jpg",
  "cozumler/mutfak-tezgahlari": "/images/zenith-hero-kitchen-1800.jpg",
  "cozumler/banyo-tezgahlari-ve-lavabolar": "/images/zenith-porcelain-bathroom-1400.jpg",
  "cozumler/porselen-masa-ve-sehpalar": "/images/zenith-porcelain-table-1400.jpg",
  "cozumler/porselen-lavabo-cozumleri": "/images/zenith-porcelain-bathroom-1400.jpg",
  "cozumler/mimari-ve-ozel-projeler": "/images/cafe-restoran-projesi.jpeg",
  "cozumler/cnc-su-jeti-fason-uretim": "/images/waterjet-cutting-service.jpeg",
  "cozumler/cam-porselen-laminasyonu": "/images/zenith-porcelain-table-1400.jpg",
  "cozumler/marmox-destekli-porselen-lavabo-ve-tezgahlar": "/images/marmox-porselen-lavabo-tezgah-video.jpg",
  "cozumler/3-mm-porselen-mobilya-kaplama": "/images/projects/3mm-porselen-mobilya-saloni.jpg",
};

const titleKeys: Record<string, string> = {
  "": "home", cozumler: "solutions", projeler: "projects", koleksiyonlar: "collections", profesyoneller: "professionals",
  "uretim-teknolojileri": "technology", "yesil-enerji-ve-su-donusumu": "green",
  "bilgi-merkezi": "knowledge", hakkimizda: "about", iletisim: "contact",
  "collections/endustriyel-beton": "concrete", "collections/statuario-mermer": "statuario",
  "collections/antrasit-tas": "anthracite", "cozumler/mutfak-tezgahlari": "kitchen",
  "cozumler/banyo-tezgahlari-ve-lavabolar": "bathroom", "cozumler/porselen-masa-ve-sehpalar": "tables",
  "cozumler/porselen-lavabo-cozumleri": "basins", "cozumler/mimari-ve-ozel-projeler": "bespoke",
  "cozumler/cnc-su-jeti-fason-uretim": "waterjet", "cozumler/cam-porselen-laminasyonu": "lamination",
  "cozumler/marmox-destekli-porselen-lavabo-ve-tezgahlar": "marmox",
  "cozumler/3-mm-porselen-mobilya-kaplama": "furniture",
};

const copy = {
  en: {
    dir: "ltr", language: "English", nav: ["Solutions", "Projects", "Collections", "Professionals", "Technology", "Sustainability", "About", "Contact"],
    title: {home:"Engineering porcelain from surface to product.",solutions:"Porcelain solutions shaped around every project.",projects:"Porcelain projects and applications.",collections:"Curated porcelain collections.",professionals:"A technical partner for professionals.",technology:"Integrated production under one roof.",green:"Water stays in the cycle.",knowledge:"Porcelain knowledge centre.",about:"Engineering, craft and responsibility.",contact:"Let’s shape your project together.",concrete:"Industrial Concrete",statuario:"Statuario Marble",anthracite:"Anthracite Stone",kitchen:"Porcelain kitchen countertops",bathroom:"Bathroom surfaces and countertops",tables:"Porcelain tables and tabletops",basins:"Bespoke porcelain basins",bespoke:"Architectural and bespoke projects",waterjet:"CNC and waterjet cutting services",lamination:"Glass–porcelain lamination",marmox:"Marmox-supported porcelain basins and countertops",furniture:"3 mm porcelain surfaces for furniture"},
    intro:"From digital measurement and technical detailing to CNC, waterjet, lamination, quality control and installation, Zenith manages the complete process with one technical team.",
    kicker:"Integrated porcelain fabrication · Türkiye", why:"Designed for real projects", features:[["Technical confidence","Every detail is evaluated for use, production and installation."],["Precision production","Digital data becomes repeatable, controlled geometry."],["Project support","A clear technical contact from first drawing to final delivery."]],
    services:"Capabilities", list:["Kitchen and bathroom countertops","Tables, furniture and hospitality projects","CNC and waterjet cutting","Architectural and bespoke surfaces","Glass–porcelain lamination","OEM and export production"], cta:"Send your project", footer:"Designed and manufactured in Türkiye."
  },
  es: {
    dir:"ltr",language:"Español",nav:["Soluciones","Proyectos","Colecciones","Profesionales","Tecnología","Sostenibilidad","Nosotros","Contacto"],
    title:{home:"Ingeniería del porcelánico, de la superficie al producto.",solutions:"Soluciones de porcelánico para cada proyecto.",projects:"Proyectos y aplicaciones de porcelánico.",collections:"Colecciones de porcelánico seleccionadas.",professionals:"Un socio técnico para profesionales.",technology:"Producción integrada bajo un mismo techo.",green:"El agua permanece en el ciclo.",knowledge:"Centro de conocimiento del porcelánico.",about:"Ingeniería, oficio y responsabilidad.",contact:"Demos forma a su proyecto.",concrete:"Hormigón Industrial",statuario:"Mármol Statuario",anthracite:"Piedra Antracita",kitchen:"Encimeras de cocina de porcelánico",bathroom:"Superficies y encimeras de baño",tables:"Mesas y tableros de porcelánico",basins:"Lavabos de porcelánico a medida",bespoke:"Proyectos arquitectónicos y especiales",waterjet:"Servicios CNC y corte por chorro de agua",lamination:"Laminación vidrio–porcelánico",marmox:"Lavabos y encimeras de porcelánico con soporte Marmox",furniture:"Superficies de porcelánico de 3 mm para mobiliario"},
    intro:"Desde la medición digital y el detalle técnico hasta CNC, chorro de agua, laminación, control de calidad e instalación, Zenith gestiona todo el proceso con un único equipo técnico.",kicker:"Fabricación integrada de porcelánico · Turquía",why:"Diseñado para proyectos reales",features:[["Confianza técnica","Cada detalle se evalúa para el uso, la producción y el montaje."],["Producción precisa","Los datos digitales se convierten en geometría controlada y repetible."],["Soporte de proyecto","Un interlocutor técnico claro desde el primer plano hasta la entrega."]],services:"Capacidades",list:["Encimeras de cocina y baño","Mesas, mobiliario y hostelería","Corte CNC y chorro de agua","Superficies arquitectónicas especiales","Laminación vidrio–porcelánico","Producción OEM y exportación"],cta:"Envíe su proyecto",footer:"Diseñado y fabricado en Turquía."
  },
  de: {
    dir:"ltr",language:"Deutsch",nav:["Lösungen","Projekte","Kollektionen","Profis","Technologie","Nachhaltigkeit","Über uns","Kontakt"],
    title:{home:"Porzellan-Engineering von der Fläche zum Produkt.",solutions:"Porzellanlösungen für jedes Projekt.",projects:"Porzellanprojekte und Anwendungen.",collections:"Kuratierte Porzellankollektionen.",professionals:"Technischer Partner für Profis.",technology:"Integrierte Fertigung unter einem Dach.",green:"Wasser bleibt im Kreislauf.",knowledge:"Wissenszentrum für Porzellan.",about:"Engineering, Handwerk und Verantwortung.",contact:"Gestalten wir Ihr Projekt gemeinsam.",concrete:"Industriebeton",statuario:"Statuario-Marmor",anthracite:"Anthrazitstein",kitchen:"Porzellan-Küchenarbeitsplatten",bathroom:"Badoberflächen und Waschtische",tables:"Porzellantische und Tischplatten",basins:"Maßgefertigte Porzellanwaschbecken",bespoke:"Architektur- und Sonderprojekte",waterjet:"CNC- und Wasserstrahlschneiden",lamination:"Glas–Porzellan-Laminierung",marmox:"Marmox-gestützte Porzellanwaschbecken und Arbeitsplatten",furniture:"3-mm-Porzellanoberflächen für Möbel"},
    intro:"Von digitalem Aufmaß und technischer Planung bis zu CNC, Wasserstrahl, Laminierung, Qualitätskontrolle und Montage steuert Zenith den gesamten Prozess mit einem technischen Team.",kicker:"Integrierte Porzellanfertigung · Türkei",why:"Für reale Projekte entwickelt",features:[["Technische Sicherheit","Jedes Detail wird für Nutzung, Fertigung und Montage geprüft."],["Präzise Fertigung","Digitale Daten werden zu kontrollierter, wiederholbarer Geometrie."],["Projektbegleitung","Ein klarer technischer Ansprechpartner vom Entwurf bis zur Lieferung."]],services:"Kompetenzen",list:["Küchen- und Badarbeitsplatten","Tische, Möbel und Gastronomieprojekte","CNC- und Wasserstrahlschneiden","Architektonische Sonderflächen","Glas–Porzellan-Laminierung","OEM- und Exportfertigung"],cta:"Projekt senden",footer:"Entworfen und hergestellt in der Türkei."
  },
  ar: {
    dir:"rtl",language:"العربية",nav:["الحلول","المشاريع","المجموعات","للمحترفين","التقنيات","الاستدامة","من نحن","اتصل بنا"],
    title:{home:"هندسة البورسلان من السطح إلى المنتج.",solutions:"حلول بورسلان مصممة لكل مشروع.",projects:"مشاريع وتطبيقات البورسلان.",collections:"مجموعات بورسلان منتقاة.",professionals:"شريك تقني للمحترفين.",technology:"إنتاج متكامل تحت سقف واحد.",green:"نُبقي المياه داخل الدورة.",knowledge:"مركز معرفة البورسلان.",about:"هندسة وحِرفة ومسؤولية.",contact:"لنصمم مشروعكم معاً.",concrete:"الخرسانة الصناعية",statuario:"رخام ستاتواريو",anthracite:"حجر أنثراسيت",kitchen:"أسطح مطابخ من البورسلان",bathroom:"أسطح وحمامات بورسلان",tables:"طاولات وأسطح بورسلان",basins:"أحواض بورسلان حسب الطلب",bespoke:"مشاريع معمارية وخاصة",waterjet:"خدمات CNC والقطع بنفث الماء",lamination:"تصفيح الزجاج والبورسلان",marmox:"أحواض وأسطح بورسلان مدعومة بألواح مارموكس",furniture:"أسطح بورسلان 3 مم للأثاث"},
    intro:"من القياس الرقمي والتفاصيل التقنية إلى CNC والقطع بنفث الماء والتصفيح وضبط الجودة والتركيب، تدير Zenith العملية كاملة من خلال فريق تقني واحد.",kicker:"تصنيع بورسلان متكامل · تركيا",why:"مصمم للمشاريع الحقيقية",features:[["ثقة تقنية","يتم تقييم كل تفصيل وفق الاستخدام والإنتاج والتركيب."],["إنتاج دقيق","تتحول البيانات الرقمية إلى هندسة دقيقة قابلة للتكرار."],["دعم المشروع","جهة تقنية واضحة من الرسم الأول حتى التسليم النهائي."]],services:"القدرات",list:["أسطح المطابخ والحمامات","الطاولات والأثاث ومشاريع الضيافة","القطع بتقنية CNC ونفث الماء","الأسطح المعمارية والخاصة","تصفيح الزجاج والبورسلان","إنتاج OEM والتصدير"],cta:"أرسل مشروعك",footer:"مصمم ومصنع في تركيا."
  },
  it: {
    dir:"ltr",language:"Italiano",nav:["Soluzioni","Progetti","Collezioni","Professionisti","Tecnologia","Sostenibilità","Chi siamo","Contatti"],
    title:{home:"Ingegneria della porcellana, dalla superficie al prodotto.",solutions:"Soluzioni in porcellana per ogni progetto.",projects:"Progetti e applicazioni in porcellana.",collections:"Collezioni di porcellana selezionate.",professionals:"Un partner tecnico per i professionisti.",technology:"Produzione integrata sotto lo stesso tetto.",green:"L’acqua rimane nel ciclo.",knowledge:"Centro di conoscenza della porcellana.",about:"Ingegneria, artigianalità e responsabilità.",contact:"Diamo forma al vostro progetto.",concrete:"Cemento Industriale",statuario:"Marmo Statuario",anthracite:"Pietra Antracita",kitchen:"Piani cucina in porcellana",bathroom:"Superfici e piani bagno",tables:"Tavoli e piani in porcellana",basins:"Lavabi in porcellana su misura",bespoke:"Progetti architettonici e speciali",waterjet:"Servizi CNC e taglio waterjet",lamination:"Laminazione vetro–porcellana",marmox:"Lavabi e piani in porcellana con supporto Marmox",furniture:"Superfici in porcellana da 3 mm per mobili"},
    intro:"Dal rilievo digitale e dettaglio tecnico a CNC, waterjet, laminazione, controllo qualità e posa, Zenith gestisce l’intero processo con un unico team tecnico.",kicker:"Produzione integrata di porcellana · Turchia",why:"Pensato per progetti reali",features:[["Sicurezza tecnica","Ogni dettaglio è valutato per uso, produzione e installazione."],["Produzione precisa","I dati digitali diventano geometrie controllate e ripetibili."],["Supporto al progetto","Un referente tecnico chiaro dal primo disegno alla consegna."]],services:"Competenze",list:["Piani cucina e bagno","Tavoli, arredi e progetti hospitality","Taglio CNC e waterjet","Superfici architettoniche speciali","Laminazione vetro–porcellana","Produzione OEM ed export"],cta:"Invia il progetto",footer:"Progettato e prodotto in Turchia."
  }
} as const;

const navPaths = ["cozumler","projeler","koleksiyonlar","profesyoneller","uretim-teknolojileri","yesil-enerji-ve-su-donusumu","hakkimizda","iletisim"];

export function generateStaticParams() {
  return locales.flatMap(locale => paths.map(path => ({ locale, path: path ? path.split("/") : [] })));
}

export async function generateMetadata({params}:{params:Promise<{locale:string;path?:string[]}>}):Promise<Metadata>{
  const {locale,path=[]}=await params; if(!locales.includes(locale as Locale)) return {};
  const p=path.join("/"); const c=copy[locale as Locale]; const key=titleKeys[p] as keyof typeof c.title;
  const title=c.title[key] || c.title.home;
  const translatedPath=p?`/${p}`:"";
  const description=c.intro.slice(0,158);
  return {title,description,alternates:{canonical:`/${locale}${translatedPath}`,languages:{"x-default":translatedPath||"/","tr-TR":translatedPath||"/",...Object.fromEntries(locales.map(l=>[l,`/${l}${translatedPath}`]))}},openGraph:{title,description,locale:openGraphLocales[locale as Locale],images:[pageImages[p]||pageImages[""]]}};
}

export default async function LocalizedPage({params}:{params:Promise<{locale:string;path?:string[]}>}){
  const {locale,path=[]}=await params; const p=path.join("/");
  if(!locales.includes(locale as Locale)||!paths.includes(p as typeof paths[number])) notFound();
  const c=copy[locale as Locale]; const key=titleKeys[p] as keyof typeof c.title; const title=c.title[key]||c.title.home;
  return <div className="locale-site" lang={locale} dir={c.dir}>
    <header className="locale-header"><a href={`/${locale}`}><img src="/images/zenith-porcelain-logo-clean.png" alt="Zenith Porcelain"/></a><nav>{c.nav.map((n,i)=><a key={n} href={`/${locale}/${navPaths[i]}`}>{n}</a>)}</nav><div className="locale-language-switcher" role="navigation" aria-label={c.language}><a href={p?`/${p}`:"/"}>TR</a>{locales.map(l=><a key={l} className={l===locale?"is-active":undefined} aria-current={l===locale?"page":undefined} href={`/${l}${p?`/${p}`:""}`}>{l.toUpperCase()}</a>)}</div></header>
    <main><section className="locale-hero"><ResilientImage src={pageImages[p]||pageImages[""]} alt={`${title} — Zenith Porcelain`} loading="eager" fetchPriority="high"/><div className="locale-shade"/><div><p>{c.kicker}</p><h1>{title}</h1><span>{c.intro}</span><a href={`/${locale}/iletisim`}>{c.cta} ↗</a></div></section>
    <section className="locale-features"><div><p>{c.why}</p><h2>{title}</h2></div>{c.features.map((f,i)=><article key={f[0]}><span>0{i+1}</span><h3>{f[0]}</h3><p>{f[1]}</p></article>)}</section>
    <section className="locale-services"><div><p>{c.services}</p><h2>Zenith Porcelain</h2></div><ul>{c.list.map(x=><li key={x}>{x}</li>)}</ul></section>
    <section className="locale-cta"><h2>{c.cta}</h2><a href="mailto:info@zenithporcelain.com">info@zenithporcelain.com ↗</a></section></main>
    <footer className="locale-footer"><img src="/images/zenith-porcelain-logo-clean.png" alt="Zenith Porcelain"/><p>{c.footer}</p><a href="tel:+902222555400">+90 222 255 54 00</a></footer>
  </div>
}
