import { type NextRequest, NextResponse } from "next/server";
import { retiredLegacyPaths } from "./legacy-url-map";

export function proxy(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  const normalizedPath = pathname === "/" ? "/" : pathname.replace(/\/+$/, "");
  if (retiredLegacyPaths.has(normalizedPath)) {
    return new NextResponse(
      '<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>İçerik kaldırıldı | Zenith Porcelain</title><body style="font-family:Arial,sans-serif;max-width:680px;margin:12vh auto;padding:24px;line-height:1.7"><h1>Bu eski içerik kalıcı olarak kaldırıldı.</h1><p>Eski web sitesinin örnek içeriği artık yayında değildir.</p><p>This legacy sample content has been permanently removed.</p><p><a href="/bilgi-merkezi">Güncel bilgi merkezi</a> · <a href="/en/bilgi-merkezi">English knowledge centre</a></p></body></html>',
      { status: 410, headers: { "Content-Type": "text/html; charset=utf-8", "X-Robots-Tag": "noindex", "Cache-Control": "public, max-age=3600" } },
    );
  }
  const directRedirects: Record<string, string> = {
    "/about": "/hakkimizda",
    "/services": "/cozumler",
    "/contact": "/iletisim",
  };
  const destination = directRedirects[normalizedPath] ?? normalizedPath;

  if (destination !== pathname) {
    // NextURL klonu gelen isteğin `trailingSlash` durumunu koruyup
    // `/hakkimizda` atamasını tekrar `/hakkimizda/` biçimine çevirebilir.
    // Yerleşik URL nesnesi hedefi aynen seri hale getirir.
    const url = new URL(request.url);
    url.pathname = destination;
    return NextResponse.redirect(url, 308);
  }

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-zenith-pathname", pathname);
  return NextResponse.next({ request: { headers: requestHeaders } });
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.svg).*)"],
};
