// Adapted from Zenith's existing Turkish pricing and comparison guides.
// No live prices, unverified performance figures, or warranty promises.
export const recoveredGuides = [
  {
    slug: "porcelain-countertop-cost-factors",
    title: "Porcelain Countertop Cost: What Shapes Your Quote?",
    description: "Understand how slabs, thickness, cutting, edge details, transport and installation affect the total cost of a porcelain countertop.",
    intro: "A price per square metre cannot describe every porcelain countertop project. Two kitchens with the same surface area can require different slab quantities, edge work and installation plans. A useful quote explains both the material and the work needed to turn it into a finished countertop. Before comparing prices, agree on the dimensions, finish, appliance cut-outs and installation scope. This guide sets out the main questions to ask, without quoting a fixed price that may not apply to your project.",
    sections: [
      { title: "Slab selection and thickness", text: "Brand, collection, finish, slab size and availability affect the starting cost. The visible edge thickness is not necessarily the slab thickness: a built-up edge, mitred joint or supporting structure can add fabrication work. Ask the supplier to identify the exact material and construction detail in the quote." },
      { title: "Layout, veining and waste", text: "Net countertop area does not determine slab quantity on its own. Long pieces, an island, the direction of the pattern and matched corners can change the cutting layout. A slab plan helps explain how much material is needed and why two layouts with similar usable area may have different costs." },
      { title: "Cut-outs, edges and joints", text: "Sink and hob openings, tap holes, polished edges, splashbacks and corner joints each require defined operations. An undermount sink detail is not the same scope as a simple straight cut. Compare quotes using the same opening sizes, edge lengths and joint positions, and confirm which operations are included." },
      { title: "Measurement, delivery and installation", text: "Technical drawings and site measurement establish the fabrication dimensions. Floor level, lift or stair access, door openings, delivery distance and site readiness affect the installation plan. Clarify whether supports, transport, fitting and additional site work are included before accepting a quote." },
      { title: "Request a comparable proposal", text: "Share a plan or approximate measurements, project location, preferred surface, sink and hob models, edge detail and intended installation date. Ask for exclusions and warranty terms in writing. Approximate dimensions can support an initial budget discussion; final pricing depends on the confirmed project details. Zenith can review the fabrication and installation scope with you so that the proposal reflects the finished work, rather than a material-only figure." },
    ],
    turkishSource: "/bilgi-merkezi/porselen-tezgah-fiyatlari",
  },
  {
    slug: "porcelain-quartz-granite-comparison",
    title: "Porcelain, Quartz or Granite: A Countertop Checklist",
    description: "Compare porcelain, quartz and granite countertop proposals by product specifications, detailing, maintenance and total project scope.",
    intro: "Choosing a countertop involves more than matching a colour sample. Porcelain, quartz and granite proposals should be compared using the exact products, finishes and construction details offered for your project. There is no single material that is automatically the best choice for every kitchen or bathroom. Intended use, slab layout, supports, edge details and maintenance expectations all matter. Use this checklist to ask consistent questions and assess the complete installed solution, rather than relying on a broad claim that one material is always stronger or cheaper.",
    sections: [
      { title: "Compare the selected products, not just labels", text: "Request the technical data and care instructions for each proposed surface. Heat, sunlight, staining and impact are separate considerations, and suitability should be checked against the intended location and use. Do not treat the performance of one collection as a guarantee for every product in the same material category." },
      { title: "Plan the appearance and edge detail", text: "Review slab dimensions, pattern direction, joints and the finished edge on the actual production drawing. Ask how the desired visual thickness will be achieved and where supports are required. Large surfaces, islands and wall returns may involve different cutting and installation decisions even when the colours look similar in a showroom." },
      { title: "Check installation and everyday care", text: "Confirm the cabinet or support structure, sink and hob models, opening positions and access route before fabrication. Follow the selected manufacturer's guidance for cleaning, protection and any surface treatment. Ask specifically whether sealing or other periodic maintenance is required. Trivets and cutting boards are sensible everyday precautions; no proposal should be read as a promise of damage-free use under all conditions." },
      { title: "Compare the whole quotation", text: "A fair cost comparison includes slabs, layout waste, measurement, cutting, edge finishing, openings, supports, delivery and fitting. Check that competing proposals include the same scope, exclusions and warranty terms. A lower material price alone does not establish a lower installed project cost." },
      { title: "Make the decision around your project", text: "Bring the plans, chosen samples and equipment details together before ordering. Identify which requirements are essential and which are preferences, then ask each supplier to explain how the proposed surface and detailing meet them. Zenith can assess the porcelain fabrication option against your project requirements. For quartz or granite alternatives, use the selected supplier's product documentation and installation guidance to complete the comparison." },
    ],
    turkishSource: "/bilgi-merkezi/porselen-tezgah-mi-kuvars-mi",
  },
];
