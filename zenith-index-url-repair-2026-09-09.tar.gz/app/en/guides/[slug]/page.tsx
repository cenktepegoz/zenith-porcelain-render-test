import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { recoveredGuides } from "../guide-data";

export function generateStaticParams() { return recoveredGuides.map(({ slug }) => ({ slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = recoveredGuides.find(a => a.slug === slug);
  if (!article) return {};
  return {
    title: article.title, description: article.description,
    alternates: { canonical: `/en/guides/${slug}` },
    openGraph: { type: "article", title: article.title, description: article.description, locale: "en_GB", url: `/en/guides/${slug}`, images: ["/images/zenith-hero-kitchen-1800.jpg"] },
  };
}

export default async function RecoveredGuide({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = recoveredGuides.find(a => a.slug === slug);
  if (!article) notFound();
  return <div className="locale-site" lang="en">
    <header className="locale-header"><a href="/en"><img src="/images/zenith-porcelain-logo-clean.png" alt="Zenith Porcelain" /></a><nav aria-label="Main navigation"><a href="/en/bilgi-merkezi">Knowledge centre</a><a href="/en/cozumler/mutfak-tezgahlari">Kitchen countertops</a><a href="/en/iletisim">Contact</a></nav></header>
    <main style={{ maxWidth: 850, margin: "0 auto", padding: "64px 24px", lineHeight: 1.85 }}>
      <article><p>ZENITH PORCELAIN · BUYING GUIDE</p><h1 style={{ fontSize: "clamp(2rem, 4vw, 3.2rem)", lineHeight: 1.2 }}>{article.title}</h1><p>{article.intro}</p>
        <img src="/images/zenith-hero-kitchen-1800.jpg" alt="Porcelain kitchen countertop and island" style={{ width: "100%", height: "auto", borderRadius: 8, margin: "24px 0" }} />
        {article.sections.map(s => <section key={s.title} style={{ margin: "32px 0" }}><h2>{s.title}</h2><p>{s.text}</p></section>)}
        <p><a href="/en/iletisim">Discuss your project with Zenith →</a></p>
        <aside aria-label="Related reading"><h2>Related reading</h2><ul>{recoveredGuides.filter(a => a.slug !== slug).map(a => <li key={a.slug}><a href={`/en/guides/${a.slug}`}>{a.title}</a></li>)}<li><a href="/en/cozumler/mutfak-tezgahlari">Porcelain kitchen countertops</a></li><li><a href={article.turkishSource} hrefLang="tr">Related Turkish guide</a></li></ul></aside>
      </article>
    </main>
    <footer className="locale-footer"><a href="/en">Zenith Porcelain</a><a href="mailto:info@zenithporcelain.com">info@zenithporcelain.com</a><a href="tel:+908502425900">+90 850 242 59 00</a></footer>
  </div>;
}
