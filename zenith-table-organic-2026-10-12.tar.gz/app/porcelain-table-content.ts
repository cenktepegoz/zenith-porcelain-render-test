import type { Solution } from './site-data';
import type { ExportPage } from './english-export-data';

/** Commercial facts confirmed by Zenith; no stock, certification or export-market claims. */
export const trTableEnhancement: Partial<Solution> = {
  title: 'Porselen masa ve masa tablası üretimi',
  eyebrow: 'Tamamlanmış masa · Özel ölçü tabla · Proje üretimi',
  intro: 'Zenith Porcelain, Eskişehir’de porselen masa ve masa tablası üretimi yapar. Tamamlanmış masa, yalnızca tabla ve açılır-kapanır masa seçeneklerini; evler, mobilya üreticileri, mimarlar, otel, kafe ve restoran projeleri için değerlendiriyoruz. Ortalama üretim süresi yaklaşık üç haftadır; Türkiye genelinde teslimat, yer ve adede göre ayrıca planlanır.',
  seo: {
    title: 'Porselen Masa ve Masa Tablası Üretimi | Zenith Porcelain',
    description: 'Özel ölçü porselen masa, masa tablası ve açılır masa üretimi. Yaklaşık 3 hafta üretim, Türkiye geneline teslimat. Projeniz için teklif alın.',
    keywords: ['porselen masa üretimi', 'porselen masa tablası', 'açılır porselen masa', 'özel ölçü porselen masa'],
  },
  primaryCta: 'Masa projem için teklif al',
  process: ['Ürün kapsamı, ölçü ve adet bilgilerinin alınması', 'Taşıyıcı ve mekanizma detaylarının değerlendirilmesi', 'Malzeme ve üretim çiziminin netleştirilmesi', 'Proje yapısına uygun kesim, gerekliyse laminasyon ve kenar işleme', 'Kalite kontrol, paketleme ve teslimat planı'],
  benefits: [
    { title: 'Masa veya yalnızca tabla', text: 'Tamamlanmış ürün ile mevcut ayağa uygulanacak tabla farklı kapsamlardır. Teklifinizi ihtiyaç duyduğunuz ürün ve bağlantı detaylarına göre hazırlıyoruz.' },
    { title: 'Sabit ve açılır masa seçenekleri', text: 'Mekân yerleşimi, kullanım biçimi ve mekanizma birlikte değerlendirilir. Açık ve kapalı ölçüler üretim öncesinde netleştirilir.' },
    { title: 'Projeye özel üretim teklifi', text: 'Konut, mobilya üretimi ve otel, kafe, restoran projelerinde ölçü, adet, seçilen yüzey ve teslimat kapsamı üzerinden fiyatlandırma yapılır.' },
  ],
  decisions: [
    { number: '01', title: 'Ürün kapsamı ve kullanım', text: 'Tamamlanmış masa mı, yalnızca tabla mı? Yemek masası, sehpa, toplantı masası veya ticari kullanım için istenen form ve adet belirlenir.' },
    { number: '02', title: 'Porselen ve kenar detayı', text: 'Marka/model, yüzey bitişi, desen yönü ve kenar görünümü seçilir. Porselen katman kalınlığı ile bitmiş tabla kalınlığı aynı bilgi değildir.' },
    { number: '03', title: 'Taşıyıcı ve mekanizma', text: 'Ayak çizimi, destek aralıkları, bağlantılar ve varsa açılır mekanizma incelenir. Uygunluk yalnızca tablanın dış ölçüsünden belirlenemez.' },
    { number: '04', title: 'Üretim ve teslimat', text: 'Yaklaşık üç haftalık ortalama üretim süresi, sipariş detaylarıyla teyit edilir. Nakliye bedeli ve organizasyonu varış yeri ve adede göre belirlenir.' },
  ],
  sections: [
    { eyebrow: 'Ürün seçimi', title: 'Tamamlanmış porselen masa mı, masa tablası mı?', paragraphs: ['Tamamlanmış masa arayan müşteriler için tabla, ayak ve varsa mekanizma bir ürün olarak değerlendirilir. Mobilya üreticileri veya kendi ayağını kullanacak müşteriler ise yalnızca porselen masa tablası için teklif isteyebilir.', 'Mevcut ayağa uygunluk için ayak fotoğrafının yanında ölçülü çizim, destek noktaları ve bağlantı detayları gerekir. Malzeme, taşıyıcı ve kullanım koşulları birlikte değerlendirilmeden taşıma kapasitesi veya montaj uygunluğu taahhüt edilmez.'] },
    { eyebrow: 'Tasarım ve uygulama', title: 'Açılır-kapanır porselen masa ve özel ölçü seçenekleri', paragraphs: ['Açılır-kapanır masa seçeneklerimiz bulunur. Teklifte kapalı ve açık ölçülerin, mekanizma tipinin, hareket boşluklarının ve ayak yerleşiminin belirtilmesi önemlidir.', 'Dikdörtgen, oval, yuvarlak veya projeye özel bir form talebinde nihai ölçü ve üretilebilirlik teknik değerlendirmeyle netleşir. Desen yönü ve birleşim görünümü, özellikle hareketli parçalar arasında ayrıca ele alınır.'] },
    { eyebrow: 'Üretici ve proje ekipleri', title: 'Mobilya, otel, kafe ve restoran projeleri için porselen masa', paragraphs: ['Mimarlar, mobilya ve masa üreticileri ile otel, kafe ve restoran projelerine ölçü ve adet bazlı üretim teklifi hazırlıyoruz. Proje fiyatını tek bir yüzey fotoğrafı değil, ürünün tamamlanmış kapsamı belirler.'], items: ['Ürün tipi, form, bitmiş ölçüler ve adet listesi', 'Porselen marka/model tercihi ve kenar görünümü', 'Ayak, destek, bağlantı ve varsa mekanizma çizimleri', 'Teslimat şehri, erişim koşulları ve hedef takvim'] },
    { eyebrow: 'Malzeme bilgisi', title: 'Porselen, seramik masa ve laminasyon arasında seçim', paragraphs: ['Masa aramalarında porselen masa ve seramik masa ifadeleri birlikte kullanılabilir. Teklifte genel adlandırma yerine seçilen üreticinin ürün adı, kalınlığı ve teknik dokümanı esas alınmalıdır.', 'Cam-porselen laminasyonu, uygun projelerde tablanın katman yapısının bir parçası olarak değerlendirilir; her porselen masanın aynı yapıda olduğu varsayılmaz. Cam, ara katman, kenarlar, bağlantılar ve taşıyıcı birlikte incelenir. Zenith, hazır levhaları işler; ham porselen levha üreticisi değildir.'] },
    { eyebrow: 'Teslimat ve ihracat talebi', title: 'Türkiye geneline teslimat, yurtdışı için proje bazlı değerlendirme', paragraphs: ['Türkiye geneline teslimat yapılır. Ortalama üretim süresi yaklaşık üç haftadır; bu süre nakliye süresiyle aynı değildir. Kesin takvim, seçilen model, malzeme ve adet üzerinden teyit edilir.', 'Yurtdışı taleplerinde ülke/şehir, adet, ambalaj, taşıma, sigorta, gümrük ve yerel montaj sorumlulukları ayrıca netleştirilir. Nakliye dahil sabit fiyat, her ülkeye hazır teslimat veya belirli bir ihracat süresi varsayılmamalıdır. İngilizce proje talebinizi ihracat bölümünden iletebilirsiniz.'] },
  ],
  relatedLinks: [
    { title: 'Cam-porselen laminasyonu', href: '/cozumler/cam-porselen-laminasyonu', description: 'Katman yapısı, kenar ve bağlantı kararlarını değerlendirin.' },
    { title: 'Mobilyada 3 mm porselen', href: '/cozumler/3-mm-porselen-mobilya-kaplama', description: 'Masa dışındaki mobilya yüzeylerini aynı tasarım diliyle ele alın.' },
    { title: 'International table enquiries', href: '/en/solutions/porcelain-tables-and-tabletops', description: 'Discuss table and tabletop fabrication in English.' },
  ],
  faqs: [
    { q: 'Tamamlanmış masa mı, yalnızca porselen masa tablası mı satıyorsunuz?', a: 'Her ikisini de sunuyoruz. Tamamlanmış masa veya yalnızca masa tablası için ölçü, model, adet ve teslimat yeriyle teklif alabilirsiniz.' },
    { q: 'Açılır-kapanır porselen masa üretiyor musunuz?', a: 'Açılır-kapanır masa seçeneklerimiz bulunuyor. Açık ve kapalı ölçüler, ayak ve mekanizma seçimi sipariş öncesinde birlikte netleştirilir.' },
    { q: 'Porselen masa üretimi kaç hafta sürer?', a: 'Ortalama üretim süresi yaklaşık üç haftadır. Kesin süre seçilen model, malzeme ve adede göre sipariş sırasında teyit edilir; taşıma süresi ayrıca planlanır.' },
    { q: 'Porselen masa fiyatına nakliye dahil mi?', a: 'Nakliye bedeli ve teslimat organizasyonu varış yeri ve sipariş adedine göre belirlenir. Teklifte ürün ve teslimat kapsamını birlikte teyit edin.' },
    { q: 'Mevcut masa ayağı için tabla siparişi verebilir miyim?', a: 'Yalnızca tabla talebinizi değerlendirebiliriz. Ayak ölçüleri, destek noktaları ve bağlantı detayları teknik inceleme için gereklidir; uygunluk inceleme sonrasında teyit edilir.' },
    { q: 'Türkiye geneline teslimat yapıyor musunuz?', a: 'Evet, Türkiye geneline teslimat yapıyoruz. Teslimat yeri ve adet, nakliye fiyatını ve organizasyonunu belirler.' },
    { q: 'Yurtdışından porselen masa veya tabla teklifi isteyebilir miyim?', a: 'Evet. Ülke, şehir, ürün kapsamı, ölçü ve adedi paylaşarak teklif talep edebilirsiniz. Üretilebilirlik, ambalaj, taşıma, gümrük ve montaj sorumlulukları siparişten önce ayrıca teyit edilir.' },
  ],
};

export const englishTableMetadata = {
  title: 'Porcelain Table Manufacturer in Türkiye | Zenith Porcelain',
  description: 'Custom porcelain tables, tabletops and extendable tables made in Türkiye. Send dimensions, quantities and destination for a project-specific quotation.',
  heading: 'Porcelain tables and tabletops made in Türkiye.',
  intro: 'Zenith Porcelain fabricates complete porcelain tables and standalone tabletops in Eskişehir, Türkiye. We also offer extendable table options for residential interiors, furniture manufacturers and hospitality projects. Production averages approximately three weeks; delivery arrangements depend on the destination and quantity.',
};

export const enTableEnhancement: Partial<ExportPage> = {
  title: englishTableMetadata.heading,
  seoTitle: englishTableMetadata.title,
  description: englishTableMetadata.description,
  intro: englishTableMetadata.intro,
  sections: [
    { title: 'Table production for your interior or furniture project', text: 'Choose a complete porcelain table, a standalone tabletop or an extendable table option. We review residential, furniture manufacturing and hospitality enquiries against the actual product dimensions and supporting structure.' },
    { title: 'Project-specific supply from Eskişehir', text: 'A quotation starts with your product scope, quantity and destination. Technical feasibility and commercial terms are confirmed before the order. International buyers can use our English export enquiry form to share a fabrication brief.' },
  ],
};

export const englishTableFaqs = [
  { q: 'Do you supply complete porcelain tables or tabletops only?', a: 'Both. Specify whether you need a complete table or a standalone tabletop, together with dimensions, quantity and delivery destination. Base compatibility is reviewed for tabletop-only enquiries.' },
  { q: 'Do you offer extendable porcelain tables?', a: 'Yes. Closed and extended dimensions, base design and mechanism details are confirmed before ordering. The suitability of a particular design requires technical review.' },
  { q: 'What is the production lead time?', a: 'Average production time is approximately three weeks. The confirmed schedule depends on the model, material and quantity. Transit time is separate and must be agreed for the destination.' },
  { q: 'Is delivery included in the table price?', a: 'Delivery cost and organisation depend on destination and quantity. Ask for the product, packing, transport and any installation responsibilities to be stated in the quotation.' },
  { q: 'Can international buyers request a quotation?', a: 'Yes. Send the destination country and city, product scope, drawings and quantity. Feasibility, packaging, transport, insurance, customs responsibilities and local assembly must be agreed before an order is confirmed.' },
];
