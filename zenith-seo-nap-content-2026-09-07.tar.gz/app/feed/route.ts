export function GET() {
  return new Response("Bu WordPress akışı kalıcı olarak kaldırıldı.", {
    status: 410,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "public, max-age=86400",
      "X-Robots-Tag": "noindex",
    },
  });
}
