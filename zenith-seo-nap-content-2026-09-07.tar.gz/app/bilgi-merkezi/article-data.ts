export type KnowledgeArticle = {
  slug: string;
  title: string;
  description: string;
  eyebrow: string;
  intro: string;
  published: string;
  updated: string;
  image?: string;
  imageAlt?: string;
  gallery?: { src: string; alt: string; caption: string }[];
  keywords?: string[];
  sections: { heading: string; paragraphs: string[]; bullets?: string[] }[];
  comparison?: { criterion: string; glass: string; wood: string }[];
  references?: { label: string; url: string }[];
  relatedLinks?: { label: string; url: string }[];
  faqs: { question: string; answer: string }[];
};

export const knowledgeArticles: KnowledgeArticle[] = [
  {
    slug: "cam-laminasyonlu-dusakabin-guvenligi",
    title: "Cam Laminasyonlu Duşakabin Neden Daha Güvenlidir?",
    description: "Cam laminasyonlu duşakabinde kırılma sonrası parça tutma avantajını, temperli cam farkını ve yarı transparan mesh tasarımını keşfedin.",
    eyebrow: "Duşakabin güvenlik rehberi",
    intro: "Duş alanında güvenlik yalnız camın ne kadar güçlü olduğuyla değil, kırıldığında nasıl davrandığıyla ölçülür. Laminasyon, kırılmayı imkânsız kılmaz; kırılma sonrasında parçaların dağılıp yaralanmaya yol açma riskini azaltmaya ve süreci daha kontrollü hâle getirmeye yardımcı olur. Bu nedenle cam laminasyonu, duşakabinlerde standart olarak değerlendirilmesi gereken önemli bir güvenlik yaklaşımıdır.",
    published: "2026-08-27",
    updated: "2026-08-27",
    image: "/images/cam-laminasyonlu-mesh-dusakabin-guvenligi.png",
    imageAlt: "Yarı transparan bronz mesh ara katmanlı cam laminasyonlu modern duşakabin",
    keywords: ["cam laminasyonlu duşakabin", "lamine güvenlik camı", "temperli lamine cam", "mesh laminasyonlu cam", "güvenli duşakabin camı"],
    sections: [
      {
        heading: "Önce doğru bilgi: Temperli cam güvenlik camıdır",
        paragraphs: [
          "Temperli camı tehlikeli veya güvensiz bir ürün olarak tanımlamak doğru değildir. Temperleme işlemi camın mekanik ve ısıl dayanımını artırır. Cam kırıldığında çok sayıda küçük, taneli parçaya ayrılacak şekilde tasarlanır; böylece sıradan tavlı camda görülebilen büyük ve keskin parçaların oluşturduğu kesilme ve saplanma riski azaltılır.",
          "Bununla birlikte temperli cam kırıldığında panel bütünlüğünü kaybeder. Küçük parçalar duş teknesine veya ıslak zemine dökülebilir; çıplak ayakla temas, düşme, tahliye ve temizlik sırasında yaralanma riski tamamen ortadan kalkmaz. Bu nedenle duşakabin güvenliğinde yalnız ‘cam ne kadar güçlü?’ değil, ‘kırılırsa ne olur?’ sorusu da değerlendirilmelidir.",
        ],
      },
      {
        heading: "Cam laminasyonu kırılma sonrasında neyi değiştirir?",
        paragraphs: [
          "Lamine güvenlik camı, iki veya daha fazla cam katmanının uyumlu bir ara katmanla kalıcı biçimde birleştirilmesiyle üretilir. Kırılma gerçekleştiğinde ara katman, cam parçalarının önemli bölümünü yüzeyde tutmaya ve panelin dağılmasını sınırlandırmaya yardımcı olur.",
          "Bu davranış duş alanında değerlidir: parçaların aniden kullanıcıya ve zemine yayılması azaltılabilir, kırık panel belirli bir süre bariyer etkisini koruyabilir ve alan daha kontrollü biçimde boşaltılabilir. Sonuç; cam kalınlığına, ara katmana, panel ölçüsüne, kenar kalitesine ve bağlantı sistemine bağlıdır. Lamine cam da kırılabilir ve hiçbir sistem ‘kırılmaz’ olarak sunulmamalıdır.",
        ],
      },
      {
        heading: "Temperli ve lamine özellikler birlikte kullanılabilir",
        paragraphs: [
          "Projeye uygun olduğunda temperlenmiş cam katmanları lamine edilerek iki farklı güvenlik yaklaşımı aynı panelde bir araya getirilebilir: temperleme günlük kullanım ve darbe dayanımına katkı sağlarken, laminasyon kırılma sonrası parçaların tutulmasına yardımcı olur.",
          "Ancak ‘temperli + lamine’ ifadesi tek başına yeterli bir teknik şartname değildir. Toplam kalınlık, cam katmanlarının yapısı, delik ve menteşe konumları, ara katman tipi, panelin sabitlenmesi ve istenen darbe sınıfı proje özelinde belirlenmelidir. Nihai ürün, kullanım ülkesinin mevzuatı ve ilgili test sınıflarıyla doğrulanmalıdır.",
        ],
      },
      {
        heading: "Mesh laminasyon: Mahremiyet ile ışık arasında mimari denge",
        paragraphs: [
          "Dekoratif metal mesh, uygun laminasyon yapısı içinde cam katmanlarının arasına yerleştirilebilir. İnce dokuma; görüşü tamamen kapatmadan yumuşatır, ışığı süzer ve cam yüzeye derinlik kazandırır. Böylece duş alanı gün ışığını kaybetmeden daha mahrem, sıcak ve özgün bir karakter kazanabilir.",
          "Bronz, bakır, şampanya, siyah veya paslanmaz çelik tonlarındaki farklı örgü açıklıkları; otel, spa, konut ve özel banyo projelerine göre seçilebilir. Mesh yüzeyde olmadığı için doğrudan su ve temizlik temasından korunur. Bununla birlikte dekoratif mesh kendi başına güvenlik sınıfı oluşturmaz; mesh, ara katman ve cam kombinasyonunun uyumu numune ve test üzerinden değerlendirilmelidir.",
        ],
      },
      {
        heading: "Duşakabinde güvenliği belirleyen yalnızca cam değildir",
        paragraphs: [
          "En iyi cam bile yanlış ölçü, zayıf kenar, hatalı delik, uygunsuz menteşe veya yetersiz sabitlemeyle güvenli bir duşakabin oluşturmaz. Panel ve donanım tek bir sistem olarak ele alınmalıdır.",
        ],
        bullets: [
          "Panel ölçüsü, toplam kalınlık ve destek aralıklarının birlikte hesaplanması",
          "Delik, çentik ve menteşe bölgelerinin temperleme ve laminasyondan önce planlanması",
          "Kenarların hassas işlenmesi ve hasara karşı üretim boyunca korunması",
          "Ara katmanın ıslak hacim, sıcaklık ve kenar koşullarıyla uyumlu seçilmesi",
          "Kapı ağırlığına uygun menteşe, profil, conta ve sabitleme kullanılması",
          "Ürünün ilgili darbe ve güvenlik sınıfının belge veya testle doğrulanması",
          "Montajın yetkin ekip tarafından, üretici talimatlarına uygun yapılması",
        ],
      },
      {
        heading: "Zenith Porcelain bu çözümü nasıl geliştirir?",
        paragraphs: [
          "Zenith Porcelain; cam işleme ve kontrollü laminasyon bilgisini mimari yüzey üretimiyle bir araya getirir. Proje; duş alanının ölçüsü, kapı tipi, sabit panel düzeni, menteşe ve profil sistemi, cam rengi, mesh dokusu ve mahremiyet beklentisi üzerinden teknik olarak değerlendirilir.",
          "Kesim, delik, kanal ve kenar işlemleri üretim sırasına göre planlanır; yüzey temizliği, katman yerleşimi, kontrollü laminasyon çevrimi ve kenar kontrolü standart bir iş akışı içinde yönetilir. Özel mesh seçeneklerinde önce görünüm ve malzeme uyumu için numune hazırlanması önerilir. Amaç; yalnız etkileyici bir cam panel değil, ölçüsü, bağlantısı, ışık geçirgenliği ve kullanım senaryosu birlikte çözülmüş bir duşakabin sistemi oluşturmaktır.",
        ],
      },
      {
        heading: "Teknik şartnamede hangi standartlar aranmalıdır?",
        paragraphs: [
          "Temperli güvenlik camının ürün ve kırılma özellikleri ISO 12540 ve EN 12150 ailesinde; lamine güvenlik camının performans gereklilikleri ISO 12543-2 / EN ISO 12543-2 kapsamında ele alınır. EN 12600 ise düz camı sarkaç darbesi altındaki performansı ve kırılma biçimine göre sınıflandırır. Duş kapıları ve kabinleri ayrıca kullanılacağı ülkenin yapı, ürün ve montaj mevzuatına tabidir.",
          "Şartnamede yalnız ‘temperli’ veya ‘lamine’ yazılması yerine cam bileşimi, toplam kalınlık, ara katman, darbe sınıfı, panel ölçüsü, donanım ve montaj koşulları birlikte tanımlanmalıdır. Bu sayfa genel bilgilendirmedir; nihai güvenlik kararı yetkili tasarımcı, üretici, test kuruluşu ve montaj ekibi tarafından proje özelinde verilmelidir.",
        ],
      },
    ],
    references: [
      { label: "CPSC — 16 CFR Part 1201: Duş kapıları ve kabinlerinde güvenlik camı kapsamı", url: "https://www.cpsc.gov/Newsroom/News-Releases/2016/CPSC-Amends-Mandatory-Safety-Standard-for-Architectural-Glazing-Materials" },
      { label: "ISO 12540:2017 — Temperli soda-kireç-silikat güvenlik camı", url: "https://www.iso.org/standard/62574.html" },
      { label: "ISO 12543-2:2021 — Lamine güvenlik camı performans gerekleri", url: "https://www.iso.org/standard/75497.html" },
      { label: "BSI — EN 12600 sarkaç darbe testi ve sınıflandırma", url: "https://knowledge.bsigroup.com/products/glass-in-building-pendulum-test-impact-test-method-and-classification-for-flat-glass" },
      { label: "NIST — Temperli ve lamine güvenlik camının kırılma davranışı", url: "https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir5779.pdf" },
      { label: "NPSA — Lamine cam, ara katman ve kırılma sonrası tutunma", url: "https://www.npsa.gov.uk/building-protection/windows-glazed-facades/laminated-glass" },
    ],
    relatedLinks: [
      { label: "Cam-porselen laminasyonu çözümümüzü inceleyin", url: "/cozumler/cam-porselen-laminasyonu" },
      { label: "CNC, su jeti ve cam işleme kapasitemizi inceleyin", url: "/cozumler/cnc-su-jeti-fason-uretim" },
      { label: "Üretim teknolojilerimizi keşfedin", url: "/uretim-teknolojileri" },
    ],
    faqs: [
      { question: "Temperli duşakabin camı güvensiz midir?", answer: "Hayır. Temperli cam, büyük ve sivri parçalar yerine çoğunlukla küçük taneli parçalar oluşturacak şekilde tasarlanan bir güvenlik camıdır. Laminasyonun ek avantajı, kırılma sonrasında parçaların ara katmanda tutulmasına yardımcı olmasıdır." },
      { question: "Cam laminasyonlu duşakabin kırılmaz mı?", answer: "Hayır. Lamine cam da yeterli darbe veya hatalı uygulama sonucunda kırılabilir. Güvenlik avantajı, kırık parçaların dağılmasını sınırlandırması ve panelin bir süre bir arada kalmasına yardımcı olmasıdır." },
      { question: "Mesh ara katman camı otomatik olarak daha güvenli yapar mı?", answer: "Hayır. Mesh öncelikle dekoratif bir katmandır. Güvenlik performansı; cam, ara katman, mesh, kenar ve bağlantı sisteminin birlikte test edilmesiyle doğrulanmalıdır." },
      { question: "Mesh laminasyon duş alanını tamamen kapatır mı?", answer: "Örgü açıklığına göre değişir. İnce ve açık dokular yarı transparan bir görünüm sunarken daha sık dokular mahremiyeti artırır. Işık, renk ve görüş etkisi numune üzerinde değerlendirilmelidir." },
      { question: "Lamine duşakabin çerçevesiz yapılabilir mi?", answer: "Panel ölçüsü, toplam kalınlık, kapı ağırlığı, menteşe ve sabitleme sistemi uygunsa değerlendirilebilir. Çerçevesiz görünüm tek başına karar ölçütü değildir; tüm sistem mühendislik ve montaj açısından kontrol edilmelidir." },
    ],
  },
  {
    slug: "cam-laminasyonlu-porselen-ve-ahsap-altlik-farklari",
    title: "Porselen Masalarda Cam Laminasyon Neden Önemlidir?",
    description: "Cam laminasyonun porselen masa tablasında rijitlik, düzlemsellik, güvenli bağlantı ve ince kenar görünümüne nasıl katkı sağladığını öğrenin.",
    eyebrow: "Cam laminasyon rehberi",
    intro: "Porselen masa tablası güzel ve dayanıklı bir yüzey sunar. Ancak özellikle ince ve büyük tablalarda, porselenin altında onu sürekli destekleyen doğru bir sistem gerekir. Cam laminasyonda porselen, uygun bir ara katmanla cam yüzeye birleştirilir. Böylece masa daha dengeli, daha düz ve daha güvenli kullanılabilen bütün bir yapıya dönüşür.",
    published: "2026-08-26",
    updated: "2026-08-26",
    image: "/images/cam-laminasyonlu-porselen-masa-01.jpg",
    imageAlt: "Cam laminasyonlu oval porselen masa tablasında ince kenar ve bütünleşik yüzey görünümü",
    gallery: [
      {
        src: "/images/cam-laminasyonlu-porselen-masa-detay.jpg",
        alt: "Cam laminasyonlu porselen masa tablasının ince kesitini gösteren yandan görünüm",
        caption: "Cam laminasyonun desteklediği ince ve bütünleşik tabla kesiti.",
      },
      {
        src: "/images/cam-laminasyonlu-porselen-masa-mekan.jpg",
        alt: "Cam laminasyonlu oval porselen masa tablasının iç mekândaki kullanımı",
        caption: "Geniş ebatlı porselen masada düzlemsellik ve zarif kenar görünümü.",
      },
    ],
    keywords: ["cam laminasyonlu porselen masa", "porselen masa altlığı", "cam porselen laminasyon", "ahşap altlık", "porselen masa sehim"],
    sections: [
      {
        heading: "Cam laminasyon nedir?",
        paragraphs: [
          "Cam laminasyon, porselen tabla ile cam altlığın özel bir ara katman kullanılarak birbirine bağlanmasıdır. Bu ara katman iki yüzeyi yalnızca yapıştırmaz; yükün küçük bir noktada toplanmak yerine daha geniş bir alana yayılmasına yardımcı olur.",
          "Basitçe anlatmak gerekirse, porselen güzel ve güçlü üst yüzeyi oluşturur; cam ise alttan sürekli destek verir. İki malzeme doğru biçimde birleştirildiğinde tek parça gibi çalışan daha dengeli bir masa tablası elde edilir.",
        ],
      },
      {
        heading: "Masayı neden daha sağlam ve kullanışlı hâle getirir?",
        paragraphs: [
          "İnce ve büyük bir porselen tabla, altında yeterli destek olmadığında esneyebilir veya darbeyi küçük bir bölgede hissedebilir. Cam altlık porseleni geniş bir yüzey boyunca destekler. Bu destek, tablanın daha tok ve dengeli hissetmesine katkı sağlar.",
          "Cam laminasyon masayı ‘kırılmaz’ yapmaz. Fakat doğru cam kalınlığı, doğru ara katman ve doğru ayak yerleşimiyle hazırlanan sistem; tek başına bırakılmış ince porselene göre günlük kullanım ve taşıma sırasında daha güvenli davranabilir.",
        ],
      },
      {
        heading: "Ayak bağlantısı neden daha güvenli kurulabilir?",
        paragraphs: [
          "Masa ayağı doğrudan porselene vidalanmamalıdır. Çünkü küçük bir vida veya bağlantı noktası, yükü porselenin dar bir bölgesine bindirebilir.",
          "Cam destekli tablaya uygun bir metal plaka veya bağlantı parçası eklenebilir. Böylece ayağın taşıdığı yük daha geniş bir yüzeye yayılır. Sonuçta bağlantı daha dengeli olur ve porselen üzerindeki noktasal baskı azalır.",
        ],
      },
      {
        heading: "Masanın daha düz kalmasına nasıl yardımcı olur?",
        paragraphs: [
          "Büyük porselen levhalarda üretimden gelen küçük eğrilikler olabilir. Düz bir cam üzerinde kontrollü laminasyon yapılması, tablanın düzlüğünü iyileştirmeye ve formunu korumasına yardımcı olabilir.",
          "Burada masa ölçüsü ve ayakların yeri yine önemlidir. Çok uzun açıklık veya yanlış yerleştirilmiş ayaklar varsa cam tek başına bütün sorunları çözmez. En iyi sonuç, tabla ve ayak sistemi birlikte tasarlandığında alınır.",
        ],
      },
      {
        heading: "Neden daha ince ve şık görünür?",
        paragraphs: [
          "Cam ve porselen birlikte birleştirildikten sonra kenarları aynı hizada işlenebilir. Böylece iki ayrı parça yerine tek ve düzenli bir tabla görünümü oluşur.",
          "Cam altlık ince tutulabildiği için masa gereğinden kalın ve ağır görünmez. Özellikle modern mobilyalarda aranan zarif kenar çizgisi bu yöntemle daha kolay elde edilir.",
        ],
      },
      {
        heading: "Ahşap altlıktan farkı nedir?",
        paragraphs: [
          "Ahşap, havadaki neme göre az da olsa genişleyip daralabilen bir malzemedir. Porselen ise aynı şekilde hareket etmez. Bu iki farklı malzeme yanlış yapıştırıldığında zamanla kenarlarda açıklık veya bağlantılarda gevşeme görülebilir.",
          "Ahşap altlık bazı projelerde doğru malzeme ve doğru bağlantıyla kullanılabilir. Ancak cam; neme bağlı şişme yapmaması, sürekli ve düz bir destek yüzeyi oluşturması ve porselenle birlikte ince işlenebilmesi sayesinde cam laminasyonlu masalarda önemli avantajlar sağlar.",
        ],
      },
      {
        heading: "İyi bir cam laminasyon için neler doğru yapılmalıdır?",
        paragraphs: [
          "Başarılı sonuç yalnızca porseleni cama yapıştırmakla elde edilmez. Porselen ve camın kalınlığı, ara katmanın türü, masa ölçüsü, ayakların yeri ve kenar işlemi birbiriyle uyumlu olmalıdır.",
          "Bu ayrıntılar doğru çözüldüğünde cam laminasyon; ince porselen masayı daha dengeli, daha düzgün ve daha kullanışlı bir ürüne dönüştüren güçlü bir üretim yöntemidir.",
        ],
        bullets: [
          "Masanın ölçüsü ve taşıyacağı yük",
          "Porselen ile camın kalınlığı",
          "Kullanıma uygun ara katman veya yapıştırıcı",
          "Ayakların yeri ve bağlantı plakası",
          "Kenarların birlikte ve aynı hizada işlenmesi",
          "Taşıma, paketleme ve montaj şekli",
        ],
      },
    ],
    comparison: [
      { criterion: "Tabla desteği", glass: "Porseleni geniş ve sürekli bir yüzey boyunca destekler.", wood: "Sonuç, kullanılan ahşabın türüne ve kalitesine daha çok bağlıdır." },
      { criterion: "Düz görünüm", glass: "Doğru laminasyon, tablanın düzlüğünü iyileştirebilir.", wood: "Ahşabın kendi eğriliği veya nem hareketi tablaya yansıyabilir." },
      { criterion: "Ayak bağlantısı", glass: "Uygun metal plaka ile yük daha geniş alana yayılabilir.", wood: "Vida ve bağlantılar zamanla gevşemeye karşı doğru tasarlanmalıdır." },
      { criterion: "Kenar görünümü", glass: "Cam ve porselen birlikte işlenerek ince ve düzgün görünebilir.", wood: "Ayrı işleme gerektiği için altlık daha kalın veya uyumsuz görünebilir." },
      { criterion: "Nem", glass: "Nem alarak şişmez veya daralmaz.", wood: "Ortam nemine göre boyut değiştirebilir." },
      { criterion: "Genel görünüm", glass: "Porselenin desenini öne çıkaran sade bir bütünlük sağlar.", wood: "Renk ve kalınlık farkı kenardan görülebilir." },
    ],
    references: [
      { label: "USDA Forest Service — Wood Handbook: Moisture Relations and Physical Properties of Wood", url: "https://research.fs.usda.gov/treesearch/62243" },
      { label: "3M — Joint Design with Structural Adhesives", url: "https://multimedia.3m.com/mws/media/1586280O/iatd-joining-and-bonding-structural-adhesives-white-paper.pdf" },
      { label: "Kuraray — Advanced Interlayers for Laminated Glass", url: "https://www.kuraray.com/global-en/products/interlayers/" },
    ],
    relatedLinks: [
      { label: "Cam-porselen laminasyonu çözümünü inceleyin", url: "/cozumler/cam-porselen-laminasyonu" },
      { label: "Porselen masa ve sehpa üretimini inceleyin", url: "/cozumler/porselen-masa-ve-sehpalar" },
      { label: "Porselen kalınlık seçim rehberini okuyun", url: "/bilgi-merkezi/porselen-kalinlik-secimi" },
    ],
    faqs: [
      { question: "Cam laminasyonlu porselen masa kırılmaz mı?", answer: "Hayır. Cam destek masayı daha dengeli ve dayanıklı bir sisteme dönüştürmeye yardımcı olur; ancak yanlış taşıma, sert kenar darbesi veya hatalı bağlantı yine hasara yol açabilir." },
      { question: "Ara katman ne işe yarar?", answer: "Ara katman cam ile porseleni birbirine bağlar ve oluşan yükün daha geniş bir yüzeye yayılmasına yardımcı olur. Kullanılacak ürün masa ölçüsüne ve kullanım yerine uygun seçilmelidir." },
      { question: "Masa ayağı doğrudan porselene vidalanabilir mi?", answer: "Önerilmez. Ayak bağlantısı uygun bir metal plaka veya bağlantı parçasıyla yapılmalı ve yük geniş bir alana aktarılmalıdır." },
      { question: "Cam laminasyon masayı tamamen düz yapar mı?", answer: "Doğru uygulama tablanın düzlüğünü önemli ölçüde iyileştirebilir. Ancak masa ölçüsü, ayak aralığı ve katman kalınlıkları da sonucu etkiler." },
      { question: "Ahşap altlık her zaman yanlış mıdır?", answer: "Hayır. Doğru ahşap ve doğru bağlantıyla kullanılabilir. Fakat nem hareketi, kalınlık ve kenar uyumu açısından cam destek çoğu ince porselen masa projesinde daha kontrollü bir çözüm sunar." },
    ],
  },
  {
    slug: "porselen-tezgah-mi-kuvars-mi",
    title: "Porselen tezgâh mı kuvars mı? Tarafsız karşılaştırma",
    description: "Porselen ve kuvars tezgâhları ısı, leke, UV, bakım, tasarım, üretim ve montaj açısından karşılaştırın; projeniz için doğru seçimi yapın.",
    eyebrow: "Malzeme karşılaştırması",
    intro: "Porselen ve kuvars, iyi projelendirildiğinde mutfak ve banyo tezgâhlarında güçlü seçeneklerdir. Doğru karar yalnız renk veya fiyatla değil; kullanım biçimi, plaka ölçüsü, birleşim planı, kenar detayı ve uygulama koşulları birlikte değerlendirilerek verilir.",
    published: "2026-08-24",
    updated: "2026-08-24",
    sections: [
      {
        heading: "Kısa cevap: tek bir malzeme her proje için en iyi değildir",
        paragraphs: [
          "Büyük ebat, ince kesit, dış mekân veya güçlü damar sürekliliği aranan projelerde porselen öne çıkabilir. Daha kalın ve homojen kesit, belirli kenar profilleri veya yerel kuvars koleksiyonlarına erişim önemliyse kuvars uygun olabilir.",
          "Her iki malzemede de başarılı sonuç; doğru plaka seçimi kadar ölçüm, taşıyıcı altyapı, kesim, boşaltma, birleşim ve montaj kalitesine bağlıdır.",
        ],
      },
      {
        heading: "Isı, güneş ve leke davranışı",
        paragraphs: [
          "Porselen yüksek sıcaklıkta pişirilen mineral esaslı bir yüzeydir. Ürünün teknik föyünde belirtilen koşullar içinde ısıya ve UV etkisine karşı kararlı seçenekler sunar. Kuvars yüzeylerde reçine içeriği bulunduğundan sıcak cisimler ve yoğun UV için üretici kullanım talimatları özellikle dikkate alınmalıdır.",
          "İki malzemede de günlük kullanımda nihale, kesme tahtası ve uygun temizlik ürünü kullanmak yüzeyin uzun süre iyi görünmesine yardımcı olur. Leke dayanımı marka, yüzey bitişi ve kimyasal temas türüne göre teknik föyden doğrulanmalıdır.",
        ],
      },
      {
        heading: "Tasarım, plaka ölçüsü ve kenar detayı",
        paragraphs: [
          "Porselenin ince ve büyük ebatlı seçenekleri tezgâh, tezgâh arası ve yan dönüşlerde aynı yüzey dilini kurmayı kolaylaştırabilir. Damar yönü ve birleşim noktaları üretim çiziminde plaka görseli üzerinde planlanmalıdır.",
          "Kuvars daha homojen desenli koleksiyonlarda parça eşleştirmeyi kolaylaştırabilir. Her iki yüzeyde görünür kalınlık; gerçek plaka kalınlığından, kalınlaştırılmış ön alın detayından ve taşıyıcı sistemden farklı olabilir.",
        ],
        bullets: [
          "Plaka ölçüsü ve kullanılabilir alan",
          "Damar yönü ve kitap eşleme beklentisi",
          "Evye ve ocak boşaltmalarının konumu",
          "Kenar profili ve görünür kalınlık",
          "Taşıma güzergâhı ve montaj sırası",
        ],
      },
      {
        heading: "Fiyatı yalnız metrekare üzerinden karşılaştırmayın",
        paragraphs: [
          "Nihai maliyet; plaka, fire, ölçüm, teknik çizim, kesim, kenar, evye-ocak boşaltması, taşıyıcı, sevkiyat ve montajdan oluşur. Aynı metrekarede iki projenin parça sayısı ve işleme yoğunluğu farklı olabilir.",
          "Sağlıklı karşılaştırma için iki teklifin aynı plaka, kalınlık, kenar, kesim, montaj ve garanti kapsamını içerdiğinden emin olun.",
        ],
      },
      {
        heading: "Karar vermeden önce teknik kontrol",
        paragraphs: [
          "Malzemeyi seçmeden önce dolap veya taşıyıcı sistem, duvar geometrisi, evye ve ocak modeli, armatür, birleşim tercihleri ve montaj erişimi netleştirilmelidir. Zenith teknik ekip bu verileri üretim çiziminde bir araya getirerek malzeme ve detay kararını proje özelinde değerlendirir.",
        ],
      },
    ],
    faqs: [
      { question: "Porselen tezgâh kuvarstan daha mı dayanıklıdır?", answer: "Dayanım tek bir özellik değildir. Isı, UV, çizilme, darbe, kenar ve taşıyıcı davranışı ayrı değerlendirilmelidir. Karşılaştırma, seçilen ürünlerin resmî teknik verileri ve proje detayı üzerinden yapılmalıdır." },
      { question: "Porselen veya kuvars tezgâhta sıcak tencere kullanılabilir mi?", answer: "Üretici talimatları esas alınmalıdır. Termal şok ve yüzey hasarı riskini azaltmak için her iki yüzeyde de nihale kullanmak güvenli uygulamadır." },
      { question: "Hangi malzeme daha ekonomiktir?", answer: "Fiyat; marka, desen, plaka verimi, kalınlık, işleme ve montaj kapsamına göre değişir. Yalnız metrekare fiyatı toplam proje maliyetini göstermez." },
    ],
  },
  {
    slug: "porselen-tezgah-fiyatlari",
    title: "Porselen tezgâh fiyatını belirleyen 9 unsur",
    description: "Porselen tezgâh fiyatını plaka, kalınlık, metraj, fire, kenar, kesim, ölçüm, sevkiyat ve montajın nasıl etkilediğini öğrenin.",
    eyebrow: "Satın alma rehberi",
    intro: "Porselen tezgâh için tek bir metrekare fiyatı vermek çoğu projede yanıltıcıdır. Toplam maliyet, kullanılan yüzey kadar o yüzeyin projeye nasıl yerleştirildiği ve işlendiğiyle belirlenir.",
    published: "2026-08-24",
    updated: "2026-08-24",
    sections: [
      {
        heading: "1. Plaka markası, seri ve yüzey bitişi",
        paragraphs: ["Koleksiyon, desen, yüzey bitişi ve plaka tedariği başlangıç maliyetini etkiler. Aynı görsel ailedeki iki ürünün ebat, kalınlık ve teknik özellikleri farklı olabilir."],
      },
      {
        heading: "2. Kalınlık ve görünür kenar",
        paragraphs: ["Plakanın gerçek kalınlığı ile tezgâhın görünür kalınlığı aynı değildir. İnce plaka, taşıyıcı veya kalınlaştırılmış ön alın gerektirebilir; 45 derece birleşim ve özel kenar işçiliği maliyeti değiştirir."],
      },
      {
        heading: "3. Net metraj değil, plaka yerleşimi ve fire",
        paragraphs: ["Tezgâhın net alanı plaka ihtiyacını tek başına belirlemez. Parça boyları, damar yönü, ada ölçüsü, kitap eşleme ve kusurlu alanlardan kaçınma fire oranını etkiler."],
      },
      {
        heading: "4–6. Kesimler, kenarlar ve birleşimler",
        paragraphs: ["Evye, ocak, batarya, priz ve tesisat boşaltmaları; düz kesimden farklı makine ve işçilik gerektirir. Görünür kenar uzunluğu, köşe sayısı ve birleşim tipi de fiyatı etkiler."],
        bullets: ["Evye ve ocak boşaltmaları", "Alttan veya üstten evye detayı", "Damlalık, süpürgelik ve duvar dönüşü", "45 derece kenar ve kalınlaştırma", "Damar eşleme ve köşe devamlılığı"],
      },
      {
        heading: "7–9. Ölçüm, taşıma ve montaj koşulları",
        paragraphs: ["Dijital ölçüm, teknik çizim ve onay süreci üretim riskini azaltır. Kat, asansör, merdiven, giriş açıklıkları, şehir dışı sevkiyat ve şantiye çalışma saatleri lojistik planı değiştirir. Montaj kapsamı ve saha hazırlığı da teklifte açıkça yazılmalıdır."],
      },
      {
        heading: "Karşılaştırılabilir teklif için gerekli bilgiler",
        paragraphs: ["Teklif isterken plan veya yaklaşık ölçü, proje şehri, seçilen yüzey, evye ve ocak modeli, kenar beklentisi, montaj tarihi ve saha erişimi paylaşılmalıdır. Böylece fiyat yalnız malzemeyi değil gerçek iş kapsamını gösterir."],
      },
    ],
    faqs: [
      { question: "Porselen tezgâh neden yalnız m² üzerinden fiyatlanmaz?", answer: "Plaka yerleşimi, fire, parça sayısı, kenar uzunluğu, boşaltmalar, taşıma ve montaj koşulları aynı metrekarede farklı iş yükü oluşturur." },
      { question: "Ölçü olmadan yaklaşık fiyat alınabilir mi?", answer: "Plan veya yaklaşık ölçüyle bütçe aralığı oluşturulabilir. Bağlayıcı teklif için saha, donanım ve üretim detaylarının doğrulanması gerekir." },
      { question: "Fiyata montaj dahil midir?", answer: "Bu, teklif kapsamına bağlıdır. Ölçüm, sevkiyat, montaj, taşıyıcı ve ek saha işlemleri ayrı ayrı belirtilmelidir." },
    ],
  },
  {
    slug: "porselen-kalinlik-secimi",
    title: "6, 12 ve 20 mm porselen: kalınlık seçim rehberi",
    description: "6, 12 ve 20 mm porselen yüzeyleri tezgâh, masa, duvar ve mobilya uygulamalarında taşıyıcı, kenar ve kullanım açısından karşılaştırın.",
    eyebrow: "Teknik seçim rehberi",
    intro: "Porselen kalınlığı yalnız estetik bir tercih değildir. Kullanım alanı, parça ölçüsü, açıklık, taşıyıcı sistem, kenar görünümü, donanım ve montaj koşulları birlikte değerlendirilmelidir.",
    published: "2026-08-24",
    updated: "2026-08-24",
    sections: [
      {
        heading: "6 mm: hafif görünüm ve kaplama senaryoları",
        paragraphs: ["6 mm plakalar duvar, mobilya kaplama ve uygun taşıyıcıyla tasarlanan bazı yüzeylerde ince bir dil kurabilir. Tezgâh veya masa kullanımında plaka tek başına değerlendirilmez; sürekli destek, laminasyon veya projeye uygun taşıyıcı gerekebilir."],
      },
      {
        heading: "12 mm: tezgâh ve masa projelerinde yaygın denge",
        paragraphs: ["12 mm seçenekler birçok mutfak tezgâhı, banyo ve masa projesinde estetik ile üretim seçenekleri arasında dengeli bir başlangıç sunar. Açıklık, boşaltma ve kenar detayı yine teknik çizimde kontrol edilmelidir."],
      },
      {
        heading: "20 mm: masif görünüm ve koleksiyon koşulları",
        paragraphs: ["20 mm ürünler daha masif bir kenar görünümü sağlayabilir. Her desen ve markada bulunmayabilir; ağırlık, taşıma, kesim ve donanım uyumu proje planına dahil edilmelidir."],
      },
      {
        heading: "Görünür kalınlık gerçek plaka kalınlığından farklı olabilir",
        paragraphs: ["45 derece birleştirilmiş ön alınla daha kalın bir görünüm oluşturulabilir. Bu detay malzemenin tamamını kalınlaştırmaz; kenar üretimi, iç destek ve birleşim kalitesi belirleyicidir."],
      },
      {
        heading: "Kalınlık kararında kontrol listesi",
        paragraphs: ["Nihai seçim, üretici teknik föyü ve üretim ekibinin proje değerlendirmesiyle yapılmalıdır."],
        bullets: ["Kullanım alanı ve beklenen yük", "Parça boyu, açıklık ve destek aralıkları", "Evye, ocak, gider ve donanım boşaltmaları", "Kenar görünümü ve birleşim tercihi", "Taşıma güzergâhı ve montaj erişimi", "Seçilen markanın teknik sınırları"],
      },
    ],
    faqs: [
      { question: "Mutfak tezgâhı için kaç mm porselen seçilmelidir?", answer: "Tek bir kalınlık bütün projeler için doğru değildir. Plaka markası, taşıyıcı, açıklık, evye-ocak kesileri ve kenar detayı birlikte değerlendirilmelidir." },
      { question: "6 mm porselen masa veya tezgâhta kullanılabilir mi?", answer: "Uygun taşıyıcı veya laminasyon tasarımıyla bazı projelerde kullanılabilir. Plakanın tek başına yük taşıdığı varsayılmamalı; sistem proje bazında mühendislik kontrolünden geçmelidir." },
      { question: "Kalın plaka her zaman daha mı güvenlidir?", answer: "Hayır. Parça geometrisi, boşaltmalar, destek, taşıma ve montaj kalınlık kadar önemlidir. Daha kalın ürün yanlış detaylandırılırsa risk devam eder." },
    ],
  },
  {
    slug: "3-mm-porselenden-mobilyaya",
    title: "3 mm Porselenden Mobilyaya: Porselen Artık Sadece Mutfak ve Banyoda Değil",
    description: "3 mm porselen ve cam laminasyonunun masa, sehpa ve mobilyalara kattığı estetik, dayanıklılık ve uzun ömürlü kullanım avantajlarını keşfedin.",
    eyebrow: "Mobilya ve tasarım",
    intro: "Porseleni çoğu zaman mutfak tezgâhı, banyo yüzeyi veya duvar kaplaması olarak düşünüyoruz. Oysa yeni nesil üretim teknikleri, bu güçlü malzemeyi mobilyanın da doğal bir parçasına dönüştürüyor. Özellikle 3 mm porselenin camla lamine edilmesi; masa, sehpa, TV ünitesi, konsol, komodin ve özel tasarım mobilyalarda ince, hafif görünümlü ve güven veren yüzeylerin önünü açıyor.",
    published: "2026-09-07",
    updated: "2026-09-07",
    image: "/images/saloni-heritage-modular-sofa-porselen-mobilya.jpg",
    imageAlt: "Saloni modern oturma odasında porselen yüzeyli TV ünitesi ve orta sehpalar",
    keywords: ["3 mm porselen", "porselen mobilya", "cam porselen laminasyonu", "porselen masa", "porselen sehpa"],
    sections: [
      {
        heading: "3 mm porselen neden mobilya için önemli?",
        paragraphs: [
          "Mobilyada yüzey malzemesinin kalınlığı yalnızca teknik bir ölçü değildir; tasarımın algısını doğrudan etkiler. 3 mm porselen, geleneksel kalın plakaların ağır görüntüsü olmadan doğal taş, mermer veya beton etkisi sunar. İnce kesiti sayesinde zarif kenar detayları, kesintisiz yüzeyler ve daha rafine oranlar oluşturulabilir.",
          "Saloni’nin mobilya uygulamalarında görülen yaklaşım bunun güçlü bir örneğidir. Porselen, mobilyanın üzerine sonradan eklenmiş dekoratif bir parça gibi durmak yerine tasarımın çizgisine, oranına ve malzeme diline katılır.",
        ],
        bullets: ["Orta sehpa ve yan sehpa tablaları", "Yemek ve toplantı masaları", "TV ünitesi ve medya konsolu üstleri", "Konsol, şifonyer ve komodin yüzeyleri", "Dolap kapakları ve dekoratif mobilya panelleri", "Otel, restoran ve mağazalara özel sabit mobilyalar"],
      },
      {
        heading: "Cam laminasyonu ne kazandırır?",
        paragraphs: [
          "3 mm porselenin mobilyada doğru performans göstermesi, yalnızca yüzeyin seçilmesine değil, arkasındaki taşıyıcı sistemin doğru tasarlanmasına bağlıdır. Zenith Porcelain’in cam laminasyon çözümünde ince porselen, projeye uygun camla kontrollü biçimde birleştirilir.",
          "Bu yapı porselenin estetik yüzünü korurken yüzeye rijitlik ve ölçü kararlılığı kazandırmaya yardımcı olur. Bağlantı noktalarının, kenarların ve taşıyıcı konstrüksiyonun doğru planlanmasıyla daha güvenli ve dengeli bir mobilya bileşeni elde edilir.",
        ],
      },
      {
        heading: "Estetik kadar günlük kullanım da önemli",
        paragraphs: [
          "Bir mobilya ilk gün güzel görünmekle yetinmemeli; günlük hayata da uyum sağlamalıdır. Porselen yüzeyler leke, ısı, UV ışığı ve günlük kullanımda oluşabilecek çizilme etkilerine karşı yüksek direnç gösterir. Düşük bakım ihtiyacı ve kolay temizlenebilir yapısı, özellikle sehpa ve masa gibi sık temas edilen mobilyalarda önemli bir avantajdır.",
          "Uzun ömürlü sonuç; doğru porselenin seçilmesi, laminasyon tekniği, taşıyıcı tasarımı, kenar işçiliği ve montajın birlikte ele alınmasıyla ortaya çıkar.",
        ],
      },
      {
        heading: "Saloni uygulamasında bütüncül tasarım",
        paragraphs: [
          "Saloni’nin yaşam alanı kurgusunda porselen yüzeyler, mobilyaların sade geometrisini bozmadan mekâna güçlü bir malzeme karakteri katıyor. TV ünitesindeki uzun ve kesintisiz yüzey, duvar paneliyle uyumlu bir yatay hat oluştururken orta sehpalardaki porselen tablalar aynı malzeme dilini oturma alanına taşıyor.",
          "Sonuç, tek tek dikkat çekmeye çalışan parçalar yerine birbiriyle konuşan mobilyalardan oluşan dengeli bir kompozisyon. Porselen burada yalnızca kaplama değil; renk, doku ve oran kararlarını bir araya getiren tasarım öğesi olarak görev yapıyor.",
        ],
      },
      {
        heading: "Zenith Porcelain ile projeye özel üretim",
        paragraphs: [
          "Zenith Porcelain, 3 mm porseleni camla lamine ederek mobilya üreticileri, mimarlar ve tasarımcılar için projeye özel yüzey bileşenleri üretir. Süreç; malzeme ve desen seçimi, ölçülendirme, damar yönü planlaması, kesim, kenar işlemleri, delik ve bağlantı detayları ile laminasyonun birlikte değerlendirilmesini kapsar.",
          "İster tek bir özel üretim sehpa ister adetli bir mobilya koleksiyonu olsun, amaç aynıdır: porselenin estetik gücünü mobilyanın kullanım senaryosuna uygun, güvenilir ve üretilebilir bir çözüme dönüştürmek.",
        ],
      },
    ],
    relatedLinks: [
      { label: "Cam-porselen laminasyonu çözümünü inceleyin", url: "/cozumler/cam-porselen-laminasyonu" },
      { label: "Porselen masa ve sehpa çözümlerini inceleyin", url: "/cozumler/porselen-masa-ve-sehpalar" },
      { label: "Üretim teknolojilerimizi keşfedin", url: "/uretim-teknolojileri" },
    ],
    faqs: [
      { question: "3 mm porselen mobilyada tek başına kullanılabilir mi?", answer: "Uygulama ölçüsü ve kullanım senaryosuna göre uygun taşıyıcı veya cam laminasyonu gerekir. Sistem; açıklık, bağlantı, kenar ve beklenen yüklerle birlikte projelendirilmelidir." },
      { question: "Cam laminasyonu porselen mobilyaya ne kazandırır?", answer: "Yüzeyin rijitliğine, düzlemselliğine ve ölçü kararlılığına katkı sağlar; bağlantı ve kenar detaylarının daha kontrollü çözülmesine yardımcı olur." },
      { question: "Porselen mobilya yüzeylerinin bakımı zor mudur?", answer: "Genellikle hayır. Günlük temizlikte yumuşak bir bez, ılık su ve uygun nötr temizleyici yeterlidir. Nihai bakım seçilen porselen üreticisinin teknik talimatına göre yapılmalıdır." },
    ],
  },
];

export function knowledgeArticleBySlug(slug: string) {
  return knowledgeArticles.find((article) => article.slug === slug);
}
