import type { Metadata } from "next";
import Link from "next/link";
import SubpageShell from "../components/subpage-shell";
import ResilientImage from "../components/resilient-image";
import { regions } from "../region-data";

export const metadata: Metadata = {
  title: "Porselen Mutfak Tezgâhı Hizmet Bölgeleri",
  description: "Ankara, Bursa, Eskişehir ve Kütahya için ölçüye özel porselen mutfak tezgâhı üretim, sevkiyat ve proje planlama kapsamını inceleyin.",
  alternates: { canonical: "/bolge" },
};

export default function Page() {
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      { "@type": "CollectionPage", "@id": "https://zenithporcelain.com/bolge#webpage", url: "https://zenithporcelain.com/bolge", name: "Zenith Porcelain Hizmet Bölgeleri", description: "Ankara, Bursa, Eskişehir ve Kütahya porselen mutfak tezgâhı hizmet sayfaları.", inLanguage: "tr-TR" },
      { "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Ana Sayfa", item: "https://zenithporcelain.com" }, { "@type": "ListItem", position: 2, name: "Hizmet Bölgeleri", item: "https://zenithporcelain.com/bolge" }] },
      { "@type": "ItemList", name: "Porselen mutfak tezgâhı hizmet bölgeleri", itemListElement: regions.map((region, index) => ({ "@type": "ListItem", position: index + 1, name: `${region.city} Porselen Mutfak Tezgâhı`, url: `https://zenithporcelain.com/bolge/${region.slug}` })) },
    ],
  };

  return <SubpageShell><article className="region-hub">
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
    <section className="sub-hero section-shell"><p className="eyebrow">Hizmet bölgeleri</p><h1>Yerel proje bilgisi,<br />tek üretim disiplini.</h1><p>Ankara, Bursa, Eskişehir ve Kütahya projelerinde kapsamı şehir adıyla değil; ölçü, çizim, lojistik, saha koşulları ve sorumluluk sınırlarıyla tanımlıyoruz.</p></section>
    <section className="region-hub-grid section-shell" aria-label="Hizmet bölgeleri">{regions.map((region, index) => <Link href={`/bolge/${region.slug}`} key={region.slug}>
      <figure><ResilientImage src={region.heroImage} alt={region.heroAlt} loading={index < 2 ? "eager" : "lazy"} /></figure>
      <div><p className="eyebrow">{region.city}</p><h2>{region.city} porselen mutfak tezgâhı</h2><p>{region.metaDescription}</p><span>Yerel kapsamı inceleyin ↗</span></div>
    </Link>)}</section>
    <section className="region-transparency section-shell"><div><p className="eyebrow">Şeffaf hizmet modeli</p><h2>Gerçek konum, doğrulanmış kapsam.</h2></div><div><p>Üretim tesisimiz Eskişehir 75. Yıl OSB’dedir. Ankara Siteler’de showroomumuz bulunur. Bursa ve Kütahya talepleri Eskişehir üretim tesisinden proje bazlı planlanır; bu şehirlerde fiziksel Zenith şubesi bulunduğu iddia edilmez.</p><p>Keşif, ölçüm, teslimat ve montajın dahil olduğu işler her proje için yazılı teklifte açıkça belirtilir.</p><Link className="text-link" href="/iletisim">Doğrulanmış adresleri görün</Link></div></section>
    <section className="sub-cta"><div><p className="eyebrow light">Projenizi konuşalım</p><h2>Şehrinizden bağımsız, üretilebilir bir detay dosyası oluşturalım.</h2></div><a className="button button-light" href="/#quote">Projenizi gönderin</a></section>
  </article></SubpageShell>;
}
