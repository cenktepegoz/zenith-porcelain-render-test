import type { Metadata } from "next";
import { notFound } from "next/navigation";
import RegionPage from "../../components/region-page";
import { regionBySlug, regions } from "../../region-data";

export function generateStaticParams() {
  return regions.map((region) => ({ slug: region.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const region = regionBySlug.get(slug);
  if (!region) return {};
  return {
    title: region.metaTitle,
    description: region.metaDescription,
    keywords: [`${region.city} porselen mutfak tezgâhı`, `${region.city} porselen tezgâh`, "ölçüye özel porselen tezgâh"],
    alternates: { canonical: `/bolge/${region.slug}` },
    openGraph: { title: region.metaTitle, description: region.metaDescription, type: "website", url: `/bolge/${region.slug}`, images: [{ url: region.heroImage, alt: region.heroAlt }] },
    twitter: { card: "summary_large_image", title: region.metaTitle, description: region.metaDescription, images: [region.heroImage] },
  };
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const region = regionBySlug.get(slug);
  if (!region) notFound();
  return <RegionPage region={region} regions={regions} />;
}
