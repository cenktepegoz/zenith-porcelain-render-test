export type RegionFAQ = { q: string; a: string };

export type Region = {
  slug: string;
  city: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
  lead: string;
  heroImage: string;
  heroAlt: string;
  localTitle: string;
  intro: string;
  paragraphs: string[];
  facts: string[];
  process: { n: string; title: string; text: string }[];
  applications: string[];
  coverageTitle: string;
  coverageText: string;
  coveragePlaces: string[];
  faqs: RegionFAQ[];
};

export const regions: Region[] = [
  {
    slug: "ankara-porselen-mutfak-tezgahi",
    city: "Ankara",
    title: "Ankara porselen mutfak tezgâhı: ölçüden montaja kontrollü üretim.",
    metaTitle: "Ankara Porselen Mutfak Tezgâhı | Ölçü ve Montaj",
    metaDescription: "Ankara projeleri için ölçüye özel porselen mutfak tezgâhı; teknik planlama, CNC üretim, kontrollü sevkiyat ve montaj kapsamını görüşün.",
    lead: "Zenith Porcelain, Ankara’daki konut ve proje mutfakları için porselen tezgâhı Eskişehir’deki tesisinde ölçüye özel üretir. Siteler’deki Ankara showroomumuzda yüzey ve proje görüşmesi yapılabilir; çizim, evye–ocak bilgisi, kenar detayı, sevkiyat ve saha gereksinimleri üretimden önce tek teknik kapsamda netleştirilir.",
    heroImage: "/images/zenith-hero-kitchen-1800.jpg",
    heroAlt: "Ankara porselen mutfak tezgâhı sayfası için temsili porselen mutfak uygulaması",
    localTitle: "Ankara projelerinde yüzey seçimini üretilebilir bir tezgâha dönüştürüyoruz.",
    intro: "Ankara’da porselen mutfak tezgâhı kararı yalnızca renk ve desen seçimi değildir. Dolap planı, duvar geometrisi, evye ve ocak modelleri, birleşim noktaları, taşıyıcı detay ve saha takvimi birlikte ele alınmalıdır.",
    paragraphs: [
      "Ankara’daki villa, rezidans, nitelikli konut ve ticari mutfak projelerinde tezgâh; mekânın en yoğun kullanılan yüzeylerinden biridir. Büyük ebat porselen plakalar, doğru parça yerleşimiyle daha bütüncül bir görünüm sağlayabilir. Düşük su emme, kolay temizlenme ve günlük aşınma etkilerine karşı yüksek direnç önemli avantajlardır. Bununla birlikte hiçbir yüzey koşulsuz biçimde çizilmez veya kırılmaz değildir; performans seçilen plakanın teknik değerleri, doğru destekleme, kenar çözümü ve kullanım biçimiyle birlikte değerlendirilir.",
      "İlk teknik inceleme için mutfak planı, yaklaşık ölçüler, alan fotoğrafları, tercih edilen yüzey, evye ve ocak modelleri ile hedef tarih yeterlidir. Saha ölçümü gerekiyorsa kapsam ve program yazılı teklifte belirlenir. Duvar açıları, kotlar, sabit elemanlar ve cihaz boşlukları üretim verisine dönüştürülür; damar yönü, ek yerleri, ön etek ve süpürgelik gibi görünümü etkileyen kararlar kesimden önce onaya sunulur.",
      "Onaylanan parçalar Eskişehir üretim tesisinde proje gereksinimine göre kesim, CNC veya su jeti işleme, kenar hazırlığı ve kalite kontrol aşamalarından geçer. Ankara’ya sevkiyat; parça ölçüsü, erişim koşulları ve saha takvimi dikkate alınarak planlanır. Montajın Zenith ekibi, proje yüklenicisi veya yerel uygulama ekibi tarafından yürütülüp yürütülmeyeceği teklif aşamasında açıkça yazılır; böylece sorumluluk sınırları üretim başlamadan bilinir.",
      "Çankaya, Gölbaşı, İncek, Çayyolu, Ümitköy, Yenimahalle ve Etimesgut çevresinden gelen talepler proje bilgileri üzerinden değerlendirilebilir. Siteler, Koçak Sokak No: 4 adresindeki Ankara showroomunda yüzey ve proje görüşmesi yapılabilir; güncel numune bulunurluğu ve görüşme saati için gelmeden önce teyit alınmalıdır. Keşif, teslimat ve montaj uygunluğu ise proje ölçeği, tarih ve lojistik koşullar görüldükten sonra netleşir.",
    ],
    facts: ["Ankara Siteler’de showroom", "Eskişehir’de entegre üretim", "CNC & su jeti işleme", "Ankara’ya proje bazlı planlama"],
    process: [
      { n: "01", title: "Proje bilgisi", text: "Plan, yaklaşık ölçü, fotoğraf, evye–ocak modeli ve hedef tarih birlikte değerlendirilir." },
      { n: "02", title: "Teknik netleştirme", text: "Ölçüm ihtiyacı, birleşimler, damar yönü, kenar ve taşıyıcı kararları yazılı kapsama alınır." },
      { n: "03", title: "Üretim & kontrol", text: "Onaylı çizim; uygun kesim, işleme ve kalite kontrol adımlarıyla ürüne dönüştürülür." },
      { n: "04", title: "Sevkiyat & saha", text: "Paketleme, Ankara sevkiyatı ve montaj sorumluluğu proje programına göre teyit edilir." },
    ],
    applications: ["Villa ve müstakil konut mutfakları", "Rezidans ve nitelikli konut projeleri", "Ada ve yarımada tezgâhları", "Evye, ocak ve armatür boşlukları", "Mutfak mobilyası üreticileri için proje üretimi", "Duvar paneli ve süpürgelik parçaları"],
    coverageTitle: "Ankara’da hangi bölgelere hizmet veriliyor?",
    coverageText: "Aşağıdaki bölgelerden gelen projeler teknik dosya ve lojistik koşullar üzerinden değerlendirilir. Zenith’in Ankara showroomu Siteler, Koçak Sk. No: 4, 06160 Altındağ adresindedir; üretim Eskişehir’de yapılır. Keşif ve montaj kapsamı her proje için ayrıca teyit edilir.",
    coveragePlaces: ["Çankaya", "Gölbaşı & İncek", "Çayyolu & Ümitköy", "Yenimahalle", "Etimesgut", "Ankara geneli proje talepleri"],
    faqs: [
      { q: "Ankara’da porselen mutfak tezgâhı için nasıl teklif alınır?", a: "Yaklaşık ölçü, plan veya alan fotoğrafı, evye–ocak modeli, yüzey tercihi ve hedef tarihi paylaşın. Teknik ekip üretim, sevkiyat ve varsa montaj kapsamını yazılı olarak netleştirir." },
      { q: "Zenith Porcelain’ın Ankara’da showroomu var mı?", a: "Evet. Ankara showroomumuz Siteler, Koçak Sk. No: 4, 06160 Altındağ / Ankara adresindedir. Üretim tesisimiz Eskişehir’dedir; numune ve proje görüşmesi için gelmeden önce uygunluk teyidi alınmasını öneririz." },
      { q: "Porselen tezgâh çizilmez mi?", a: "Porselen yüzeyler günlük aşınma ve çizilme etkilerine karşı yüksek direnç gösterir; ancak hiçbir yüzey koşulsuz biçimde çizilmez değildir. Kesin performans seçilen plakanın teknik föyü ve doğru kullanımla birlikte değerlendirilmelidir." },
      { q: "Ankara’da ölçüm ve montaj yapılıyor mu?", a: "Ölçüm ve montaj ihtiyacı; konum, proje ölçeği, takvim ve saha koşullarına göre değerlendirilir. Hangi ekibin hangi işi yapacağı üretimden önce teklifte belirtilir." },
      { q: "Üretim süresi ne zaman netleşir?", a: "Plaka seçimi, onaylı ölçü veya çizim, parça sayısı, kenar detayları ve üretim yoğunluğu belli olduğunda proje takvimi yazılı olarak oluşturulur." },
    ],
  },
  {
    slug: "bursa-porselen-mutfak-tezgahi",
    city: "Bursa",
    title: "Bursa porselen mutfak tezgâhı: projeye özel üretim ve saha planı.",
    metaTitle: "Bursa Porselen Mutfak Tezgâhı | Özel Üretim",
    metaDescription: "Bursa’da villa, konut ve ticari projeler için porselen mutfak tezgâhı; teknik çizim, özel üretim, kontrollü sevkiyat ve montaj planı.",
    lead: "Bursa’daki villa, konut ve ticari projeler için porselen tezgâh; yüzey seçiminden daha fazlasını gerektirir. Zenith Porcelain, ölçü, damar yönü, cihaz boşlukları, üretim, lojistik ve saha sorumluluklarını proje başlamadan teknik kapsamda birleştirir.",
    heroImage: "/images/projects/travertino-trilogy-kitchen.webp",
    heroAlt: "Bursa porselen mutfak tezgâhı sayfası için Rosso desenli temsili ada mutfak",
    localTitle: "Bursa’nın nitelikli konut ve proje mutfaklarına teknik üretim disiplini.",
    intro: "Bursa’da bir mutfak tezgâhının başarısı; plaka estetiği kadar mobilya, ankastre, birleşim, erişim ve saha programının doğru eşleşmesine bağlıdır. Her projeyi üretim ve uygulama sınırlarıyla birlikte ele alıyoruz.",
    paragraphs: [
      "Bursa’daki villa, müstakil konut, rezidans ve ticari projelerde porselen; rafine görünümü, düşük su emmesi ve kolay bakım özellikleri nedeniyle güçlü bir yüzey seçeneğidir. Büyük ebat plakalar, yerleşim doğru planlandığında desen akışını korumaya ve birleşim sayısını azaltmaya yardımcı olabilir. Isı, leke ve günlük aşınma etkilerine karşı performans yüksek olsa da kesin değerler seçilen plakanın üretici teknik föyünden kontrol edilmelidir. Sert darbe, yetersiz alt destek ve hatalı montaj bütün tezgâh malzemelerinde risk oluşturur.",
      "Bursa projesi için ilk adım; mutfak planı, yaklaşık ölçü, dolap yerleşimi, evye ve ocak bilgisi, tercih edilen desen ve teslim hedefinin paylaşılmasıdır. Mutfak henüz üretilmediyse mobilya firmasıyla kritik ölçüler ve destek noktaları birlikte değerlendirilebilir. Saha hazırsa ölçüm gereksinimi, erişim koşulları ve montaj kapsamı belirlenir. Üretim çiziminde damar yönü, ek yerleri, ön kenar, yan dönüşler ve duvar paneli ilişkisi görünür hale getirilir.",
      "Üretim Eskişehir’deki Zenith tesisinde, onaylanan teknik verilere göre yürütülür. Kesim yönteminin CNC, su jeti veya farklı bir proses olması malzeme, geometri ve kalite hedefi üzerinden seçilir. Parçalar sevkiyat öncesinde ölçü, yüzey, kenar ve proje kodu açısından kontrol edilir. Bursa’ya taşıma ve saha teslimi; parça boyutları, bina erişimi, kat, asansör, istif alanı ve montaj günü gibi pratik koşullarla birlikte planlanır.",
      "Nilüfer, Osmangazi, Mudanya, Balat, Özlüce ve Görükle çevresindeki proje talepleri teknik dosya üzerinden incelenebilir. Bu bölgelerin sayfada yer alması Bursa’da Zenith şubesi bulunduğu anlamına gelmez. Keşif ve montaj organizasyonu her işin kapsamına, takvimine ve lojistiğine göre yazılı olarak teyit edilir. Mimarlar, yükleniciler ve mutfak üreticileri; çizim, adet ve etap bilgisini paylaşarak tekrarlanabilir üretim veya tekil proje için uygun çalışma modelini belirleyebilir.",
    ],
    facts: ["Eskişehir’de ölçüye özel üretim", "Villa & proje mutfakları", "Desen ve birleşim planı", "Bursa’ya kontrollü lojistik"],
    process: [
      { n: "01", title: "Brief & koordinasyon", text: "Mutfak planı, mobilya durumu, cihazlar, yüzey ve hedef teslim programı alınır." },
      { n: "02", title: "Üretim çizimi", text: "Damar yönü, birleşimler, kenar, dönüş ve boşluklar kesimden önce netleştirilir." },
      { n: "03", title: "Hassas üretim", text: "Parçalar uygun prosesle işlenir; ölçü, yüzey ve kenar kontrolleri tamamlanır." },
      { n: "04", title: "Bursa saha planı", text: "Paketleme, taşıma, bina erişimi ve montaj sorumlulukları yazılı programa bağlanır." },
    ],
    applications: ["Villa ve müstakil konut mutfakları", "Rezidans ve toplu proje mutfakları", "Otel, restoran ve ticari mutfaklar", "Mutfak mobilyası firmalarıyla koordineli üretim", "Ada, yarımada ve duvar hattı tezgâhları", "Tezgâh arası panel ve tamamlayıcı parçalar"],
    coverageTitle: "Bursa projeleri nasıl programlanıyor?",
    coverageText: "Bursa’daki talepler üretim dosyası, saha hazırlığı ve lojistik gereksinimlerle birlikte ele alınır. Zenith’in Bursa’da fiziksel şubesi yoktur. Üretim Eskişehir’de, keşif ve montaj organizasyonu ise teyit edilen proje kapsamına göre yürütülür.",
    coveragePlaces: ["Nilüfer", "Osmangazi", "Mudanya", "Balat & Özlüce", "Görükle", "Bursa geneli proje talepleri"],
    faqs: [
      { q: "Bursa’da porselen mutfak tezgâhı siparişi nasıl başlatılır?", a: "Mutfak planını, yaklaşık ölçüleri, alan fotoğraflarını, evye–ocak modellerini ve teslim hedefini paylaşın. Teknik kapsam ve sonraki adımlar proje verisine göre hazırlanır." },
      { q: "Zenith Porcelain Bursa’da üretim yapıyor mu?", a: "Üretim Zenith’in Eskişehir tesisinde yapılır. Bursa projeleri için sevkiyat, keşif ve montaj gereksinimleri işin ölçeği ve saha programına göre ayrıca planlanır." },
      { q: "Porselen tezgâh villa mutfakları için uygun mu?", a: "Doğru plaka, destek, kenar ve uygulama detayı seçildiğinde porselen villa mutfaklarında ada, duvar hattı ve panel uygulamalarında kullanılabilir. Uygunluk proje özelinde kontrol edilmelidir." },
      { q: "Mutfak firmalarıyla birlikte çalışıyor musunuz?", a: "Evet. Dolap planı, cihaz ölçüleri, destek noktaları ve montaj sırası mutfak üreticisinin teknik ekibiyle koordine edilebilir. Sorumluluklar teklif ve onay çiziminde tanımlanır." },
      { q: "Bursa’ya sevkiyat sırasında büyük parçalar nasıl planlanır?", a: "Parça ölçüsü, paketleme, bina erişimi, kat ve taşıma rotası üretimden önce değerlendirilir. Gerektiğinde parça bölünmesi veya birleşim yeri teknik ve estetik kriterlerle belirlenir." },
    ],
  },
  {
    slug: "eskisehir-porselen-mutfak-tezgahi",
    city: "Eskişehir",
    title: "Eskişehir porselen mutfak tezgâhı: doğrudan üretim tesisinden.",
    metaTitle: "Eskişehir Porselen Mutfak Tezgâhı | Fabrikadan",
    metaDescription: "Eskişehir’de fabrikadan porselen mutfak tezgâhı; proje değerlendirme, CNC ve su jeti işleme, kalite kontrol ve montaj kapsamını görüşün.",
    lead: "Zenith Porcelain’ın Eskişehir 75. Yıl OSB’deki tesisi; mutfak tezgâhı projesini çizim, kesim, hassas işleme ve kalite kontrol adımlarıyla tek teknik akışta yönetir. Yerel projelerde numune, keşif ve montaj gereksinimleri doğrudan üretim ekibiyle değerlendirilebilir.",
    heroImage: "/images/legacy/zenith-porcelain-eskisehir-fabrika.webp",
    heroAlt: "Zenith Porcelain Eskişehir 75. Yıl OSB üretim tesisinin dış cephesi",
    localTitle: "Eskişehir’de malzeme kararını üretim bilgisiyle aynı yerde buluşturuyoruz.",
    intro: "Yerel bir tezgâh projesinde numuneyi görmek, ölçüyü üretim ekibiyle konuşmak ve teknik kararları aynı organizasyonda toplamak belirsizliği azaltır. Eskişehir tesisimiz bu sürecin merkezidir.",
    paragraphs: [
      "Eskişehir’de porselen mutfak tezgâhı arayan kullanıcılar için Zenith’in temel farkı, projenin doğrudan yerel üretim tesisinde değerlendirilmesidir. Büyük ebat porselen plakalar; mutfak planı, kullanım beklentisi ve estetik kararlarla birlikte ele alınır. Porselenin düşük su emmesi, kolay temizlenmesi, geniş desen seçeneği ve günlük aşınmaya karşı yüksek direnci mutfaklarda önemli avantajlar sunar. Yine de yüzeyin nihai performansı plakanın teknik özellikleri, doğru alt destek, işleme kalitesi ve kullanım biçimine bağlıdır.",
      "Süreç mevcut çizim veya keşif ihtiyacının belirlenmesiyle başlar. Duvar geometrisi, dolap kotları, evye, batarya, ocak ve diğer ankastre cihazlar üretim verisine dönüştürülür. Ada ve yarımada parçalarında taşıyıcı düzeni, çıkmalar ve görünen kenarlar ayrıca değerlendirilir. Damar yönü, ek yerleri, 45 derece kenar, ön etek ve duvar paneli gibi görünümü belirleyen detaylar kesimden önce onaylanır; bu sayede sahada çözülmeye çalışılan belirsizlikler azaltılır.",
      "Onaylanan parçalar proje geometrisine uygun kesim ve işleme adımlarından geçer. CNC ve su jeti, her işte otomatik olarak kullanılan etiketler değil; malzeme, boşluk ve form gereksinimine göre seçilen üretim kabiliyetleridir. Üretim sonunda ölçü, yüzey, kenar, parça kodu ve proje bütünlüğü kontrol edilir. Sevkiyat ile montaj sırası mutfağın hazır oluşuna ve diğer ekiplerin programına göre planlanır. Eski tezgâh sökümü veya tesisat işleri gerekiyorsa kapsamda olup olmadığı baştan belirtilir.",
      "Odunpazarı, Tepebaşı, Batıkent, Çamlıca, Sultandere ve çevre yerleşimlerden gelen konut veya ticari proje talepleri yerel planlamayla değerlendirilebilir. Fabrika ya da numune ziyareti, ekibin uygunluğu ve iş güvenliği koşulları doğrultusunda randevuyla organize edilir. Mimarlar, iç mimarlar, yükleniciler, mutfak firmaları ve bireysel kullanıcılar; PDF, DWG, DXF, ölçü veya fotoğraf paylaşarak üretilebilirlik ve kapsam incelemesini başlatabilir.",
    ],
    facts: ["75. Yıl OSB’de gerçek tesis", "Yerel teknik değerlendirme", "CNC & su jeti kabiliyeti", "Numune ve proje görüşmesi"],
    process: [
      { n: "01", title: "Yerel ön görüşme", text: "Çizim, ölçü, fotoğraf, cihaz modeli ve kullanım beklentisi teknik ekiple değerlendirilir." },
      { n: "02", title: "Ölçü & onay", text: "Gerekli saha verisi üretim çizimine çevrilir; kenar, birleşim ve desen kararları onaylanır." },
      { n: "03", title: "Eskişehir’de üretim", text: "Kesim, uygun hassas işleme ve kalite kontrol aynı üretim organizasyonunda yürütülür." },
      { n: "04", title: "Teslim & montaj", text: "Saha hazırlığı, diğer ekipler ve sorumluluk sınırları netleştirilerek program oluşturulur." },
    ],
    applications: ["Eskişehir konut ve villa mutfakları", "Ada ve yarımada tezgâhları", "Evye, ocak ve armatür detayları", "Mutfak firmaları için proje bazlı üretim", "Kafe, restoran ve ticari mutfaklar", "Duvar paneli, süpürgelik ve tamamlayıcı parçalar"],
    coverageTitle: "Eskişehir’de yerel proje avantajı nedir?",
    coverageText: "Üretim tesisi Eskişehir’dedir. Numune, teknik görüşme, keşif ve montaj adımları ekip uygunluğu ile proje kapsamına göre daha doğrudan planlanabilir. Fabrika ziyaretleri randevuyla gerçekleştirilir.",
    coveragePlaces: ["Odunpazarı", "Tepebaşı", "Batıkent", "Çamlıca", "Sultandere", "Eskişehir çevre yerleşimleri"],
    faqs: [
      { q: "Eskişehir’de porselen mutfak tezgâhı nerede üretiliyor?", a: "Zenith Porcelain’ın üretim tesisi 75. Yıl OSB, Osmangazi Caddesi No. 48, Odunpazarı / Eskişehir adresindedir. Proje ve ziyaret görüşmeleri randevuyla planlanır." },
      { q: "Fabrikada numune veya yüzey görülebilir mi?", a: "Numune ve proje görüşmesi ekip uygunluğu, seçili yüzeylerin bulunurluğu ve iş güvenliği koşullarına göre randevuyla organize edilir. Gelmeden önce telefonla teyit edilmesi gerekir." },
      { q: "Porselen tezgâh ısıya dayanıklı mı?", a: "Porselen yüzeylerin ısı direnci yüksektir; ancak kesin değer seçilen plakanın teknik föyüne bağlıdır. Çok sıcak ekipman için koruyucu kullanmak ve üretici talimatlarına uymak en güvenli yaklaşımdır." },
      { q: "Eskişehir’de keşif ve montaj yapılıyor mu?", a: "Keşif ve montaj ihtiyacı mutfağın hazırlık durumu, proje takvimi ve kapsam üzerinden değerlendirilir. Söküm, tesisat ve diğer işler dahilse veya hariçse teklif üzerinde açıkça belirtilir." },
      { q: "Teklif için hangi dosyalar gönderilebilir?", a: "PDF, DWG, DXF, ölçülü kroki veya alan fotoğrafları ilk inceleme için kullanılabilir. Nihai üretim formatı ve ölçü doğrulama yöntemi teknik değerlendirmede belirlenir." },
    ],
  },
  {
    slug: "kutahya-porselen-mutfak-tezgahi",
    city: "Kütahya",
    title: "Kütahya porselen mutfak tezgâhı: yakın üretim, net teknik kapsam.",
    metaTitle: "Kütahya Porselen Mutfak Tezgâhı | Özel Ölçü",
    metaDescription: "Kütahya’da ölçüye özel porselen mutfak tezgâhı; teknik planlama, Eskişehir’de hassas üretim, kontrollü sevkiyat ve montaj kapsamı.",
    lead: "Kütahya’daki konut ve proje mutfakları için porselen tezgâh, Eskişehir’deki Zenith tesisinde ölçüye özel hazırlanır. Yakın bölgesel üretim; çizim, numune, sevkiyat ve saha gereksinimlerinin tek teknik kapsamda planlanmasını destekler.",
    heroImage: "/images/projects/rosso-elazig-kitchen-paris.webp",
    heroAlt: "Kütahya porselen mutfak tezgâhı sayfası için traverten desenli temsili mutfak uygulaması",
    localTitle: "Kütahya’ya yakın üretim altyapısıyla ölçüyü, yüzeyi ve uygulamayı birlikte planlıyoruz.",
    intro: "Porselen tezgâhın doğru sonuç vermesi plaka seçiminden ibaret değildir. Ölçü, destek, kenar, cihaz boşluğu, taşıma ve montaj kararlarının aynı teknik dosyada birleşmesi gerekir.",
    paragraphs: [
      "Kütahya’daki konut, villa ve ticari projelerde porselen tezgâh; kolay bakım, düşük su emme ve güçlü mimari görünüm arayan kullanıcılar için değerlendirilir. Mermer, beton, doğal taş veya daha sade yüzey etkileri sunan plakalar mobilya, zemin ve duvar renkleriyle birlikte seçilebilir. Porselen günlük çizilme ve aşınma etkilerine karşı yüksek direnç gösterir; ancak kenara sert darbe, yetersiz destek, hatalı taşıma veya uygunsuz montaj her yüzeyde hasar riski yaratabilir.",
      "İlk incelemede mutfak planı, yaklaşık ölçüler, evye ve ocak modelleri, kenar tercihi, duvar paneli ihtiyacı ve hedef teslim tarihi alınır. Saha ölçümü gerekiyorsa Kütahya’daki konum, proje büyüklüğü ve program üzerinden uygunluk teyit edilir. Duvar açıları, kotlar, dolap yerleşimi ve tesisat noktaları üretim çizimine aktarılır. Birleşim yeri, damar yönü, ön etek, süpürgelik ve yan dönüşler kesim başlamadan önce netleştirilir.",
      "Üretim, Kütahya’ya yakın Eskişehir tesisinde onaylı teknik veriye göre yapılır. Büyük parçaların ölçüsü yalnızca görsel tercih üzerinden değil, plaka sınırı, taşıma rotası ve bina erişimi dikkate alınarak belirlenir. Uygun kesim ve işleme yönteminin ardından ölçü, yüzey ve kenar kontrolleri tamamlanır. Paketleme, sevkiyat ve montaj sorumluluğu yazılı kapsamda tanımlanır; saha hazır değilse üretim veya teslim programı diğer ekiplerle koordine edilir.",
      "Kütahya Merkez, Tavşanlı ve yakın ilçelerden gelen proje talepleri çizim, keşif ihtiyacı ve lojistik koşullara göre değerlendirilebilir. Sayfada ilçe adlarının bulunması bu noktalarda fiziksel Zenith şubesi olduğu anlamına gelmez. Mimarlar, yapı firmaları, mutfak üreticileri ve bireysel kullanıcılar; proje dosyasını, ölçüyü veya fotoğrafları paylaşarak yüzey, üretilebilirlik, yaklaşık kapsam ve sonraki adımlar için teknik ön değerlendirme talep edebilir.",
    ],
    facts: ["Eskişehir’de yakın bölgesel üretim", "Ölçü ve üretim çizimi", "Kontrollü sevkiyat", "Kütahya’ya proje bazlı saha planı"],
    process: [
      { n: "01", title: "Talep & veri", text: "Plan, ölçü, fotoğraf, cihaz bilgisi ve hedef tarih ilk teknik değerlendirmede toplanır." },
      { n: "02", title: "Detay & onay", text: "Birleşim, desen, kenar, panel ve ölçü doğrulama yöntemi üretim öncesinde belirlenir." },
      { n: "03", title: "Yakın bölgesel üretim", text: "Parçalar Eskişehir’de işlenir; ölçü, yüzey ve kenar kalite kontrollerinden geçirilir." },
      { n: "04", title: "Kütahya teslim planı", text: "Paketleme, taşıma, saha hazırlığı ve montaj sorumluluğu proje takvimine bağlanır." },
    ],
    applications: ["Kütahya konut ve villa mutfakları", "Ada, yarımada ve duvar hattı tezgâhları", "Evye ve ocak boşlukları", "Mutfak üreticileri için ölçülü parçalar", "Kafe ve ticari mutfak projeleri", "Duvar paneli ve süpürgelik uygulamaları"],
    coverageTitle: "Kütahya’ya hizmet kapsamı nasıl belirleniyor?",
    coverageText: "Üretim Eskişehir’de yapılır. Kütahya’daki keşif, teslimat ve montaj uygunluğu; proje ölçeği, tarih, konum ve saha koşulları görüldükten sonra yazılı olarak teyit edilir. Zenith’in Kütahya’da fiziksel şubesi yoktur.",
    coveragePlaces: ["Kütahya Merkez", "Tavşanlı", "Yakın ilçeler", "Villa ve konut projeleri", "Mutfak üreticileri", "Kütahya geneli proje talepleri"],
    faqs: [
      { q: "Kütahya’da porselen mutfak tezgâhı için nasıl başvurulur?", a: "Yaklaşık ölçü, plan veya fotoğraf, evye–ocak modeli, yüzey tercihi ve hedef tarihi paylaşın. Üretim, sevkiyat ve varsa saha hizmeti için teknik kapsam hazırlanır." },
      { q: "Zenith Porcelain’ın Kütahya’da şubesi var mı?", a: "Hayır. Zenith Porcelain’ın üretim tesisi Eskişehir’dedir. Kütahya projeleri yakın bölgesel üretim ve proje bazlı lojistik modeliyle değerlendirilir." },
      { q: "Kütahya’ya ölçüm ve montaj ekibi geliyor mu?", a: "Ölçüm ve montaj uygunluğu konum, proje ölçeği, takvim ve saha koşullarına göre teyit edilir. Dahil edilen işler ve sorumluluklar üretim öncesinde yazılı teklifte belirtilir." },
      { q: "Porselen tezgâhta damar devamlılığı sağlanabilir mi?", a: "Plaka görseli, parça ölçüleri ve yerleşim izin verdiğinde damar yönü ve devamlılığı üretim çiziminde planlanabilir. Sonuç doğal desen, kesim payı ve birleşim noktalarına bağlıdır." },
      { q: "Tezgâh fiyatını hangi unsurlar belirler?", a: "Plaka markası ve deseni, metraj, parça sayısı, kenar ve boşluk işlemleri, panel detayları, taşıma, keşif ve montaj kapsamı toplam teklifi etkiler." },
    ],
  },
];

export const regionBySlug = new Map(regions.map((region) => [region.slug, region]));
