import { ArrowUpRight } from "lucide-react";

export default function Footer() {
  return (
    <footer className="zp-footer">
      <div className="zp-footer-top"><a className="zp-footer-brand" href="/"><img src="/images/zenith-porcelain-logo-clean.png" alt="Zenith Porcelain" /></a><p>Porseleni yüzeyden ürüne dönüştüren<br />mühendislik ve üretim kültürü.</p></div>
      <div className="zp-footer-grid">
        <div><h3>Eskişehir Fabrika</h3><address>75. Yıl OSB, Osmangazi Caddesi<br />No: 48, Odunpazarı / Eskişehir</address><a href="tel:+902222555400">+90 222 255 54 00</a><a href="https://wa.me/908502425900?text=Merhaba%20Zenith%20Porcelain%2C%20projem%20hakk%C4%B1nda%20bilgi%20almak%20istiyorum." target="_blank" rel="noreferrer">WhatsApp · +90 850 242 59 00</a></div>
        <div><h3>İstanbul Merkez & Showroom</h3><address>Levent 199, Büyükdere Caddesi<br />No: 199, Esentepe, Şişli / İstanbul</address><a href="mailto:info@zenithporcelain.com">info@zenithporcelain.com</a></div>
        <div><h3>Keşfedin</h3><a href="/cozumler">Uygulamalar</a><a href="/projeler">Proje Galerisi</a><a href="/koleksiyonlar">Koleksiyonlar</a><a href="/profesyoneller">Profesyoneller</a></div>
        <div><h3>Kurumsal</h3><a href="/hakkimizda">Hakkımızda</a><a href="/bolge">Hizmet Bölgeleri</a><a href="/uretim-teknolojileri">Üretim Teknolojileri</a><a href="/yesil-enerji-ve-su-donusumu">Yeşil Enerji ve Su Dönüşümü</a><a href="/bilgi-merkezi">Bilgi Merkezi</a><a href="/iletisim">İletişim</a></div>
      </div>
      <div className="zp-footer-legal"><a href="/hukuki/kvkk-aydinlatma-metni">KVKK</a><a href="/hukuki/gizlilik-politikasi">Gizlilik</a><a href="/hukuki/cerez-politikasi">Çerezler</a><a href="/hukuki/kullanim-kosullari">Kullanım Koşulları</a></div>
      <div className="zp-footer-bottom"><span>© 2026 Zenith Porcelain. Tüm hakları saklıdır.</span><div><a className="zp-footer-social" href="https://www.instagram.com/zenith_porcelain/" target="_blank" rel="noreferrer" aria-label="Zenith Porcelain Instagram hesabı" title="Instagram"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect width="20" height="20" x="2" y="2" rx="5" /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" /><path d="M17.5 6.5h.01" /></svg></a><a className="zp-footer-social" href="https://www.linkedin.com/company/zenith-porcelain" target="_blank" rel="noreferrer" aria-label="Zenith Porcelain LinkedIn sayfası" title="LinkedIn"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z" /><rect width="4" height="12" x="2" y="9" /><circle cx="4" cy="4" r="2" /></svg></a><a href="#top">Yukarı <ArrowUpRight size={15} /></a></div></div>
    </footer>
  );
}
