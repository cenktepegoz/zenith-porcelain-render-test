import Link from "next/link";
import type { Region } from "../region-data";
import ResilientImage from "./resilient-image";
import SubpageShell from "./subpage-shell";

const baseUrl = "https://zenithporcelain.com";

function regionSchema(region: Region) {
  const pageUrl = `${baseUrl}/bolge/${region.slug}`;
  const city = { "@type": "City", name: region.city };
  const providerLocation = region.city === "Ankara"
    ? { "@id": `${baseUrl}/#ankara-showroom` }
    : region.city === "Eskişehir"
      ? { "@id": `${baseUrl}/#eskisehir-factory` }
      : undefined;

  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebPage",
        "@id": `${pageUrl}#webpage`,
        url: pageUrl,
        name: region.metaTitle,
        description: region.metaDescription,
        inLanguage: "tr-TR",
        isPartOf: { "@id": `${baseUrl}/#website` },
        about: { "@id": `${pageUrl}#service` },
        primaryImageOfPage: { "@type": "ImageObject", url: `${baseUrl}${region.heroImage}` },
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Ana Sayfa", item: baseUrl },
          { "@type": "ListItem", position: 2, name: "Hizmet Bölgeleri", item: `${baseUrl}/bolge` },
          { "@type": "ListItem", position: 3, name: `${region.city} Porselen Mutfak Tezgâhı`, item: pageUrl },
        ],
      },
      {
        "@type": "Product",
        "@id": `${pageUrl}#product`,
        name: `${region.city} Ölçüye Özel Porselen Mutfak Tezgâhı`,
        description: region.metaDescription,
        image: `${baseUrl}${region.heroImage}`,
        brand: { "@type": "Brand", name: "Zenith Porcelain" },
        manufacturer: { "@id": `${baseUrl}/#organization` },
        category: "Porselen mutfak tezgâhı",
      },
      {
        "@type": "Service",
        "@id": `${pageUrl}#service`,
        name: `${region.city} Porselen Mutfak Tezgâhı Projelendirme ve Üretim Hizmeti`,
        description: region.lead,
        url: pageUrl,
        serviceType: "Ölçüye özel porselen mutfak tezgâhı üretimi",
        provider: { "@id": `${baseUrl}/#organization` },
        areaServed: city,
        ...(providerLocation ? { serviceOutput: { "@id": `${pageUrl}#product` }, providerMobility: "dynamic", availableChannel: { "@type": "ServiceChannel", serviceLocation: providerLocation } } : {}),
      },
      {
        "@type": "FAQPage",
        mainEntity: region.faqs.map((item) => ({
          "@type": "Question",
          name: item.q,
          acceptedAnswer: { "@type": "Answer", text: item.a },
        })),
      },
    ],
  };
}

export default function RegionPage({ region, regions }: { region: Region; regions: Region[] }) {
  const imageLabel = region.city === "Eskişehir"
    ? "Gerçek tesis · Eskişehir 75. Yıl OSB"
    : "Uygulama ilhamı · temsili görsel";

  return (
    <SubpageShell>
      <article className="region-page">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(regionSchema(region)) }} />
        <nav className="region-breadcrumb section-shell" aria-label="Sayfa yolu">
          <Link href="/">Ana Sayfa</Link><span aria-hidden="true">/</span>
          <Link href="/bolge">Hizmet Bölgeleri</Link><span aria-hidden="true">/</span>
          <span aria-current="page">{region.city}</span>
        </nav>

        <section className="region-hero">
          <ResilientImage src={region.heroImage} alt={region.heroAlt} loading="eager" fetchPriority="high" />
          <div className="region-hero-shade" />
          <div className="region-hero-copy section-shell">
            <p className="eyebrow light">{region.city} · Porselen yüzey mühendisliği</p>
            <h1>{region.title}</h1>
            <p>{region.lead}</p>
            <div className="region-hero-actions">
              <a className="button button-light" href="/#quote">Projenizi gönderin</a>
              <a className="button button-ghost" href="/iletisim">İletişim ve adresler</a>
            </div>
          </div>
          <span className="region-image-label">{imageLabel}</span>
        </section>

        <section className="region-facts" aria-label={`${region.city} hizmet özeti`}>
          <div className="section-shell">{region.facts.map((fact, index) => <div key={fact}><span>{String(index + 1).padStart(2, "0")}</span><strong>{fact}</strong></div>)}</div>
        </section>

        <section className="region-intro section-shell">
          <header><p className="eyebrow">Yerel proje yaklaşımı</p><h2>{region.localTitle}</h2></header>
          <div><p className="region-lead">{region.intro}</p>{region.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div>
        </section>

        <section className="region-process">
          <div className="section-shell">
            <div className="section-heading"><div><p className="eyebrow light">Ölçüden sahaya</p><h2>Dört kontrollü adım.</h2></div><p>Her işte gerçek kapsam; onaylı çizim, plaka seçimi, saha koşulları ve yazılı teklif üzerinden belirlenir.</p></div>
            <ol>{region.process.map((step) => <li key={step.n}><span>{step.n}</span><h3>{step.title}</h3><p>{step.text}</p></li>)}</ol>
          </div>
        </section>

        <section className="region-applications section-shell">
          <div><p className="eyebrow">Uygulama alanları</p><h2>Projeye göre şekillenen üretim.</h2><p>Porselen yüzeyi; mobilya, cihaz, taşıyıcı, erişim ve montaj gerçekliğiyle birlikte ele alıyoruz.</p></div>
          <ul>{region.applications.map((item) => <li key={item}>{item}</li>)}</ul>
        </section>

        <section className="region-coverage section-shell">
          <div><p className="eyebrow">Hizmet kapsamı</p><h2>{region.coverageTitle}</h2><p>{region.coverageText}</p></div>
          <ul>{region.coveragePlaces.map((place) => <li key={place}>{place}</li>)}</ul>
        </section>

        <section className="region-related section-shell" aria-labelledby="region-related-title">
          <header><p className="eyebrow">Diğer hizmet bölgeleri</p><h2 id="region-related-title">Aynı üretim disiplini, bölgesel proje planı.</h2></header>
          <div>{regions.filter((item) => item.slug !== region.slug).map((item) => <Link href={`/bolge/${item.slug}`} key={item.slug}><span>{item.city}</span><strong>Porselen mutfak tezgâhı</strong><small>Sayfayı inceleyin ↗</small></Link>)}</div>
        </section>

        <section className="faq section-shell"><div><p className="eyebrow">Sık sorulanlar</p><h2>{region.city} projeniz için karar vermeden önce.</h2></div><div>{region.faqs.map((item) => <details key={item.q}><summary>{item.q}<span>+</span></summary><p>{item.a}</p></details>)}</div></section>

        <section className="sub-cta"><div><p className="eyebrow light">{region.city} projeniz için</p><h2>Çiziminizi, ölçünüzü veya alan fotoğraflarınızı teknik ekibimizle paylaşın.</h2></div><a className="button button-light" href="/#quote">Teknik değerlendirme isteyin</a></section>
      </article>
    </SubpageShell>
  );
}
